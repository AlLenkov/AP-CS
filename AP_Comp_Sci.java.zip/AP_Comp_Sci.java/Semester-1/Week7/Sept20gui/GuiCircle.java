import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;

//(5) What is imported to get Graphics to work?
public class GuiCircle extends JPanel {
	private int x, y;

	public GuiCircle() {

		x = 400;
		y = 200;
	}

	@Override
	public Dimension getPreferredSize() {
		// Sets the size of the panel
		return new Dimension(800, 600);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Color colorBlue = new Color(50, 216, 230);
		g.setColor(colorBlue);
		g.fillRect(0, 0, 4000, 4000);
		Color colorBrown = new Color(165, 42, 42);
		g.setColor(colorBrown);
		g.fillRect(x + 50, y + 50, 100, 400);

		// (6) What is being drawn?
		Color colorGreen = new Color(0, 128, 0);
		g.setColor(colorGreen);
		g.fillOval(x, y, 200, 200);

	}
}