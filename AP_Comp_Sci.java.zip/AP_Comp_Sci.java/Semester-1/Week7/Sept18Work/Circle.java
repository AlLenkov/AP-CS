
public class Circle {
    private double pi, radius, volume, area, height;

    public Circle() {

    }

    Circle(double radius) {
        this.radius = radius;
        pi = 3.14;
    }

    public void calcVol() {
        volume = 1.33 * radius * radius * radius * pi;
    }

    public void printVol() {
        calcVol();
        System.out.println("Volume = " + volume);
    }

    public void printArea() {
        area = pi * radius * radius;
        System.out.println("area = " + area);
    }

    public void printArea(double radius) {
        this.radius = radius;
        area = pi * radius * radius;
        System.out.println("area = " + area);
    }

    public void printVol(double radius, double height) {
        this.radius = radius;
        this.height = height;
        double vol = pi * radius * radius * height;
        System.out.println("volume = " + vol);
    }
}
