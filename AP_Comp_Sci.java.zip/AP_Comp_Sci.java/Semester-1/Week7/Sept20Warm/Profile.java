
public class Profile {
    private String name;
    private int age, id;

    public Profile() {
        name = "john";
        age = 15;
    }

    public Profile(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public void printInfo(){
        System.out.println(" name = "+ name);
        System.out.println(" age = "+ age);
    }

        public void printInfo(int id){
        this.id = id;
        System.out.println("id#"+id);
        printInfo();
    }

}
