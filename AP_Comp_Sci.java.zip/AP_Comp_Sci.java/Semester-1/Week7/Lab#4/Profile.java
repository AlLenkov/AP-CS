
public class Profile {
    private String name, subject, hobby, food;
    private int age;

    public Profile(String name, int age, String subject, String hobby, String food) {
        // declares input as local variables
        this.name = name;
        this.age = age;
        this.subject = subject;
        this.hobby = hobby;
        this.food = food;
    }

    public void printInfo() {
        // prints hobbys and other information about them.
        System.out.println("thier name is " + name);
        System.out.println("thier age is " + age);
        System.out.println("thier subject is " + subject);
        System.out.println("thier hobby is " + hobby);
        System.out.println("thier food is " + food);
        // calls printCareer()
        printCareer();
    }

    private void printCareer() {
        // subject~~~~~~~~~~~~math~~~~~~~~~~~~~
        // hobby movies

        // food pizza
        if (subject.equals("Math") && hobby.equals("movies") && food.equals("pizza")) {
            System.out.println("Thier future career is a programmer.");
        }
        // food pasta
        if (subject.equals("Math") && hobby.equals("movies") && food.equals("pasta")) {
            System.out.println("Thier future career is a Accountant.");
        }
        // hobby hiking

        // food pasta
        if (subject.equals("Math") && hobby.equals("hiking") && food.equals("pizza")) {
            System.out.println("Thier future career is a Copywriter.");
        }
        // food pasta
        if (subject.equals("Math") && hobby.equals("hiking") && food.equals("pasta")) {
            System.out.println("Thier future career is a Astronomer.");
        }
        
        // subject ~~~~~~~~~~~~~History~~~~~~~~~~~~~

        // hobby movies

        // food pizza
        if (subject.equals("History") && hobby.equals("movies") && food.equals("pizza")) {
            System.out.println("Thier future career is a Chef.");
        }
        // food pasta
        if (subject.equals("History") && hobby.equals("movies") && food.equals("pasta")) {
            System.out.println("Thier future career is a Pharmacist.");
        }
        // hobby hiking

        // food pasta
        if (subject.equals("History") && hobby.equals("hiking") && food.equals("pizza")) {
            System.out.println("Thier future career is a Geologist.");
        }
        // food pasta
        if (subject.equals("History") && hobby.equals("hiking") && food.equals("pasta")) {
            System.out.println("Thier future career is a Human Resources Manager.");
        }
        // subject ~~~~~~~~~~~~~English~~~~~~~~~~~~~

        // hobby movies

        // food pizza
        if (subject.equals("English") && hobby.equals("movies") && food.equals("pizza")) {
            System.out.println("Thier future career is a Interior Designer.");
        }
        // food pasta
        if (subject.equals("English") && hobby.equals("movies") && food.equals("pasta")) {
            System.out.println("Thier future career is a Paramedic.");
        }
        // hobby hiking

        // food pasta
        if (subject.equals("English") && hobby.equals("hiking") && food.equals("pizza")) {
            System.out.println("Thier future career is a Social Media Manager.");
        }
        // food pasta
        if (subject.equals("English") && hobby.equals("hiking") && food.equals("pasta")) {
            System.out.println("Thier future career is a Physical Therapist.");
        }
        System.out.print("\n\n");
    }
    // updateProfile(String, int, String, String, String) : void method that updates
    // the instance variables (name, age, subject, hobby, food).

    public void updateProfile(String name, int age, String subject, String hobby, String food) {
        // updates the instance variables
        this.name = name;
        this.age = age;
        this.subject = subject;
        this.hobby = hobby;
        this.food = food;
    
    }
}