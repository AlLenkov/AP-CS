import java.util.Scanner;

public class Runner {

    public static void main(String[] args) {
        String subject, hobby, food, answer;
        subject ="";
        hobby = "";
        food = "";
        // Instantiate three profiles
        Profile p1 = new Profile("John", 15, "Math", "movies", "pasta");
        Profile p2 = new Profile("Bob", 19, "History", "hiking", "pizza");
        Profile p3 = new Profile("Jeff", 13, "English", "movies", "pizza");

        p1.printInfo();
        p2.printInfo();
        p3.printInfo();
        Scanner scan = new Scanner(System.in);
        //
        boolean done = false;
        System.out.print(
                    "What Name would you like to use --> ");
        String name = scan.next();

        System.out.print(
                    "What age would you like to use --> ");
        int age = scan.nextInt();


        while (done == false) {
            System.out.print(
                    "\n\n\nWhat subject would you like to use?\n1:math\n2:history\n3:english\n--> ");
            answer = scan.next();

            if (answer.equals("1")) {
                done = true;
                subject = "Math";
            } else if (answer.equals("2")) {
                done = true;
                subject = "History";
            } else if (answer.equals("3")) {
                done = true;
                subject = "English";
            } else {
                System.out.println("Enter a valid option\n");
            }
        }
        done = false;


        while (done == false) {
            System.out.print(
                    "\n\n\nWhat hobby would you like to use?\n1:movies\n2:hiking\n--> ");
            answer = scan.next();

            if (answer.equals("1")) {
                done = true;
                hobby = "movies";
            } else if (answer.equals("2")) {
                done = true;
                hobby = "hiking";

            } else {
                System.out.println("Enter a valid option\n");
            }
        }
        done = false;

        while (done == false) {
            System.out.print(
                    "\n\n\nWhat Food would you like to use?\n1:pizza\n2:pasta\n--> ");
            answer = scan.next();

            if (answer.equals("1")) {
                done = true;
                food = "pizza";
            } else if (answer.equals("2")) {
                done = true;
                food = "pasta";

            } else {
                System.out.println("Enter a valid option\n");
            }

            p3.updateProfile(name, age, subject,hobby ,food );
            p3.printInfo();
        }
    }
}

