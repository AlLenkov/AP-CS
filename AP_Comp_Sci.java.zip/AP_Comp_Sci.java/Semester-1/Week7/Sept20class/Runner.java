
public class Runner {
    public static void main(String[] args) {
        // Instantiate Rect with the variable obj1 and the default constructor
        Rect obj1 = new Rect();

        // Call calcArea() from obj1
        obj1.calcArea();

        // Instantiate Rect with the variable obj2 and the initialization constructor
        // passing in the value 5 and 2.
        Rect obj2 = new Rect(5, 2);

        // Call calcArea() from obj2
        obj2.calcArea();

        // Call calcArea(int,int) from obj2 passing in 6 and 2.
        obj2.calcArea(6, 2);
    }
}

    

