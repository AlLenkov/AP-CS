public class Rect {
    // Instance Variables
    private int length;
    private int width;
    private int area;

    // Constructors
    public Rect() {
        length = 0;
        width = 0;
    }

    public Rect(int length, int width) {
        this.length = length;
        this.width = width;
    }

    // Methods
    public void printArea() {
        System.out.println("Area: " + area);
    }

    public void calcArea() {
        area = length * width;
        printArea();
    }

    public void calcArea(int length, int width) {
        this.length = length;
        this.width = width;
        calcArea();
    }
}
