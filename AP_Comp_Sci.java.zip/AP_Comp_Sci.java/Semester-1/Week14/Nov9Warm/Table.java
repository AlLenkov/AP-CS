class Table{
    private int row, col;

    public Table (int row, int col){
        this.row = row;
        this.col = col;

    }

    public void printDrawBox(){
        for(int i=0;i<row;i++){
        System.out.println("");
            for(int q=0;q<col;q++)
             System.out.print("x ");
        }
    }
}