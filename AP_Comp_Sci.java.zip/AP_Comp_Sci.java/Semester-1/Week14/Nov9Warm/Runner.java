public class Runner {
    public static void main(String[] args) {
        int row = (int) (Math.random()*9+1);
        int col = (int) (Math.random()*9+1);
        Table obj = new Table(row, col);
        obj.printDrawBox();
    }
}
