public class ForPractice {

    public void printEven(int num){
        for(int i=0;i<num;i+=2){
            System.out.print(" "+i);
        }
        System.out.println("");
    }

        public int findNum(int n0, int n1, int n3){
        int val = -1;
            for(int i = n0;i<n1;i++){
                if (i%n3==0){
                    val = i;
                    break;
                }
            
            }
        return val;
        }
    
}
