public class Runner {
    public static void main(String[] args) {
        ForPractice obj = new ForPractice();

        obj.printEven(25);
        System.out.println(obj.findNum(9,20,7));
        System.out.println(obj.findNum(12,21,11));        
    }
}
