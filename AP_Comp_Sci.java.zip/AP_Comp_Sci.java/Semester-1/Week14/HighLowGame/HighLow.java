import java.util.Scanner;

public class HighLow {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to high low game");
        boolean win = false;
        int guess;
        int max = 100;
        int min = 0;
        int scann = 0;
        int guesses = 0;
        while(win == false){
            guess = (int)(Math.random() * (max-min+1) + min);
            System.out.print("I guess " + guess+"\n1.is it higher?\n2.is it lower?\n3.is it right?\n");
            scann = scan.nextInt();
                if (scann == 1){
                    min = guess;
                    guesses ++;
                }
                else if (scann == 2){
                    max = guess;
                    guesses++;
                }
                else if (scann == 3){
                    System.out.print("horray you have " + guesses + " guesses");
                    win = true;
                }
        }


    }
}
