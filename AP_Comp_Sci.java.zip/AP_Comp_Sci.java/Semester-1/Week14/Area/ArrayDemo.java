

class ArrayDemo {
  public static void main(String[] args) {
 int[] Demo1 = new int[5];
     Demo1[0] = (int)(Math.random()*15 + 1);
 Demo1[1] = (int)(Math.random()*15 + 1);
 Demo1[2] = (int)(Math.random()*15 + 1);
 Demo1[3] = (int)(Math.random()*15 + 1);
 Demo1[4] = (int)(Math.random()*15 + 1);
 System.out.print(Demo1[0] +" "+Demo1[1]+" "+Demo1[2]+" "+Demo1[3]+" "+Demo1[4]);
 System.out.println();
 int[] Demo2 = new int[25];
   for(int i=0; i<Demo2.length; i++){
Demo2[i] = (int)(Math.random()*9 + 1);
   }
 for(int i=0; i<Demo2.length; i++){
 System.out.print(Demo2[i]+" ");
 }
 String[] Demo3 = new String[5];
 Demo3[0]="HI";
 Demo3[1]="No";
 Demo3[2]="Yes";
 Demo3[3]="Why";
 Demo3[4]="Alex";
   for(int i=0; i<Demo3.length; i++){
   System.out.print("\n"+Demo3[i]);
   }
  }
}
