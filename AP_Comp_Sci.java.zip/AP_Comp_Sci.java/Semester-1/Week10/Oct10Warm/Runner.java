public class Runner {
    public static void main(String[] args) {

        Pythagorean obj = new Pythagorean();

        double answer = obj.findC(5, 12);
        System.out.print("answwer is " + answer);
    }
}
