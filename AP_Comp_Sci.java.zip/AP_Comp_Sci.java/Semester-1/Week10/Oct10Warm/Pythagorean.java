public class Pythagorean {
    public Pythagorean(){

    }

    public double findC(double a, double b){
        double c = Math.pow(a, 2) + Math.pow(b, 2);
        return(Math.pow(c, .5));
    }
}
