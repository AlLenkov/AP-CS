
public class Bunny {
    public static void main(String[] args) {
        System.out.println("  (\\/)\n  (..)\no (__)");
    };
}
//OUTPUT:
//  (\/)
//  (..)
//o (__)

