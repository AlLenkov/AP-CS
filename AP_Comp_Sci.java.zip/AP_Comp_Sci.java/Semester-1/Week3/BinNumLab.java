
import java.util.Scanner;


public class BinNumLab { 
public static void main(String[]args){
    //get User Input
    System.out.println("What integer do you want to convert to binary?");
    Scanner scan = new Scanner(System.in);
    double userInput = scan.nextDouble();
    scan.close();

//Calculate the largest 2^n that fits inside of user input
int digits =0;
    while(userInput - Math.pow(2,digits) >= 0){
digits++;
    }
digits--;


    //Subtracts largest 2^n it can from user input and prints a 1, if it cannot it prints a 0 and moves on
if(digits==3){
System.out.print("");

}else if (digits==2){
System.out.print("0");
} else if (digits == 1){
    System.out.print("00");
}else if (digits==0){
    System.out.print("000");
}




    while(digits>=0){
    if(userInput >= Math.pow(2,digits)){
        userInput = userInput - Math.pow(2,digits); 
        System.out.print("1");
        }
        else
        {
        System.out.print("0");
        }

    digits--;
    }
    }
}


