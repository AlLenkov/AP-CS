package Week3;

public class Cone {
    public static void main(String[] args) {
    double volume;
    int radius = 3;
    double pi = 3.14;
    int hieght = 6;
    volume = pi * radius * radius * hieght * .33333333;
    System.out.print("the volume of a cone with the height 6 and radius 3 is " + volume);

    };
}
