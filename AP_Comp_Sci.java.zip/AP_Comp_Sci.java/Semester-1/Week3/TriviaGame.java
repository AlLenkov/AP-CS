
import java.util.Scanner;

public class TriviaGame {
    public static void main(String[] args) {
    String answer;
    System.out.print("What language is this writen in ");
    Scanner scan = new Scanner(System.in);
    answer = scan.next();
    if(answer.equals("java")){
        System.out.print("correct\n");
    }else{
        System.out.print("incorrect\n");
    }
    //void Scanner
//void Scanner


    System.out.print("what is the last name of the current US president ");
    answer = scan.next();
    if(answer.equals("Biden")){
        System.out.print("correct\n");
    }else{
        System.out.print("incorrect\n");
    }


    scan.nextLine();
    System.out.print("what is the name of this file in two words ");
    answer = scan.nextLine();
    if(answer.equals("Trivia Game")){
        System.out.print("correct\n");
    }else{
        System.out.print("incorrect\n");
    }


        System.out.print("Is a appple a vegtable ");
    answer = scan.next();
    if(answer.equals("no")){
        System.out.print("correct\n");
    }else{
        System.out.print("incorrect\n");
    }


    scan.nextLine();
    System.out.print("what is the name of the school I go to ");
    answer = scan.nextLine();
    if(answer.equals("Mountain View High School")){
        System.out.print("correct\n");
    }else{
        System.out.print("incorrect\n");
    }


    };
}