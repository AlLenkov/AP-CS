package Week3;
import java.util.Scanner;

public class Age {
    public static void main(String[] args) {
    int age;
    System.out.print("How old are you? ");
    Scanner scan = new Scanner(System.in);
    age = scan.nextInt();
    int year = 2023-age;
    System.out.print("you were born in the year" + year);
    };
}
