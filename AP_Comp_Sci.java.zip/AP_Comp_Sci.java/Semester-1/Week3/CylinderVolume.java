package Week3;

public class CylinderVolume {
    public static void main(String[] args) {
      

    
    int radius = 5;
    int height = 12;
    double volume = Math.PI *height*radius*radius;
    System.out.println("The volume of a cylinder with radius 5 and height 12 is "+ volume );

    };
}
