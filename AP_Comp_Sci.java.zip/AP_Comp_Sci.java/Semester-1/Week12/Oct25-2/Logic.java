import java.util.Scanner;

public class Logic {

    public static void main(String[] args) {
        
    
    String Valid = "False";
    boolean anyelse = false;
    int random0, random1;
    Scanner scan = new Scanner(System.in);
    int points = 20;
    
    while(true){

        anyelse = false;
        System.out.print("do you want to exit?, yes or no \n-->");
        Valid = scan.next();
        if (Valid == "yes") {
            break;
        }
        random0 = (int)(Math.random()*5+1);

        random1 = (int)(Math.random()*5+1);

        if (random0 == 5 && random1 == 5) {
            points +=5;
            anyelse = true;
            System.out.println("you win 5");
        }

        if (random0 == random1) {
            points +=3;
            anyelse = true;
            System.out.println("you win 3");
        }

        if (random0 > 3 || random1 > 3) {
            points +=1;
            anyelse = true;
            System.out.println("you win 1");
        }

        if (anyelse = false) {
            System.out.println("you lose 1");
            points -=1;
        }

        System.out.println("you have " + points + " points");
    
    }
    }
}