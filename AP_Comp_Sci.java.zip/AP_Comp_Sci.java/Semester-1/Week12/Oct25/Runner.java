public class Runner {
    public static void main(String[] args) {

        Selection obj = new Selection();

        obj.zipCode(94115);
        obj.zipCode(94040);
        obj.zipCode(95051);
        obj.zipCode(94025);
    }
}
