public class Selection {

    public Selection() {
        // 404
    }

    public void zipCode(int zip) {
        switch (zip) {
            case 94040:
                System.out.println("Mountain View");
                break;
            case 94115:
                System.out.println("San Fransisco");
                break;
            case 95051:
                System.out.println("Santa Clara");
                break;
            default:
                System.out.println("Error:422");
                break;

        }
    }
}
