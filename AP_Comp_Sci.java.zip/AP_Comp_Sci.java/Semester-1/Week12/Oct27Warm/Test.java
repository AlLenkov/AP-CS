public class Test {
    // Instance Variables
    private int num1;
    private int num2;

    // Constructor
    public Test(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    // Methods
    public String check1() {
        if (num1 == 7 && num2 == 7) {
            return "Jackpot";
        } else if (num1 == num2) {
            return "Same";
        } else {
            return "No Luck";
        }
    }

    public void check2() {
        switch (num1) {
            case 1:
                System.out.println("one");
                break;
            case 2:
                System.out.println("two");
                break;
            default:
                System.out.println("Other");
        }
    }


}
