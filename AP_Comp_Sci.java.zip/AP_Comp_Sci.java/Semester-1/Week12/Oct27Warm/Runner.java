public class Runner {
    public static void main(String[] args) {

        Test test1 = new Test(2, 2);
        System.out.println(test1.check1());
        test1.check2();
        Test test2 = new Test(7, 7);
        System.out.println(test2.check1());
        test2.check2();
    }
}
