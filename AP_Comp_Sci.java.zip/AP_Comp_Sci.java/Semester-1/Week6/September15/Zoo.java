
public class Zoo {

    private String AnimalType;
    private int age;
    private String name;

    public Zoo() {
        AnimalType = "Blank";
        age = 0;
        name = "no name";
    }

    public Zoo(String str, int ageVar, String nameVar) {
        AnimalType = str;
        age = ageVar;
        name = nameVar;
    }

    public void printInfo() {
        System.out.println("animal is a " + AnimalType);
        System.out.println("age is " + age);
        System.out.println("age is a " + name);
    }
    public void updateage(int newAge){
        age = newAge;
    }

}
