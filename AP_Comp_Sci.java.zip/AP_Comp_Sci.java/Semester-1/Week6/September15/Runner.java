import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        Zoo zoo = new Zoo();
        zoo.printInfo();
        zoo.updateage(7);
        zoo.printInfo();

        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a animal --> ");
        String animal = scan.next();
        System.out.print("Enter a age --> ");
        int age = scan.nextInt();
        System.out.print("Enter a name --> ");
        String name = scan.next();

        Zoo zoo1 = new Zoo(animal, age, name);
        zoo1.printInfo();
    
        
    }
}
