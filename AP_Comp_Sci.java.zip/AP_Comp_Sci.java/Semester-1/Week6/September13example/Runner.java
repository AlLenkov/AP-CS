import java.util.Scanner;


public class Runner {
    public static void main(String[] args) {
        Animal OBJ = new Animal();
        Animal OBJ2 = new Animal();
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a animal --> ");
        String animal = scan.next();
        System.out.print("Enter a age --> ");
        int age = scan.nextInt();
        System.out.print("Enter a name --> ");
        String name = scan.next();
        OBJ2.SetVariables(animal,age, name);
        OBJ2.printInfo();
        System.out.print("\n");
        OBJ2.SetVariables("Horse",7, "bob");
        OBJ2.printInfo();
    }
}
