
public class Animal {

        private String AnimalType;
        private int age;

        public void SetVariables(String str, int ageVar) {
            AnimalType  = str;
            age = ageVar;
        }
        public void printInfo() {
        System.out.println("animal is a " + AnimalType);  
        System.out.println("age is " + age); 
        }
    
}
