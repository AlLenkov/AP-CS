

public class Runner {
    public static void main(String[] args) {
        Rectangle R1 = new Rectangle();
        R1.printInfo();
        Rectangle R2 = new Rectangle(5,3);
        R2.printInfo();

        Triangle T1 = new Triangle();
        T1.printInfo();
        Triangle T2 = new Triangle(5,3);
        T2.printInfo();


    }
}
