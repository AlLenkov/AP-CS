
public class Triangle {

        private int Base;
        private int Height;

        public Triangle(){

        }
        
        public Triangle(int intB, int intH) {
            Base  = intB;
            Height = intH;
        }
        public void printInfo() {
        double area = Base*Height*.5;
        System.out.println("Area of the triangle is " + area);  
        }
    
}
