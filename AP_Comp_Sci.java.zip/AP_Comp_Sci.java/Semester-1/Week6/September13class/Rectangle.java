
public class Rectangle {

        private int Base;
        private int Height;

        public Rectangle(){
            
        }

        public Rectangle(int intB, int intH) {
            Base  = intB;
            Height = intH;
        }
        public void printInfo() {
        double area = Base*Height;
        System.out.println("Area of the rectangle is " + area);  
        }
    
}
