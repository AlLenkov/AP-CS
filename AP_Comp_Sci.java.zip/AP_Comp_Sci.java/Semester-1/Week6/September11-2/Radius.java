

public class Radius {
    private double pi = 3.14;

    public void printArea(double r){
        double radius = r;
        double area =pi*r*r;
        System.out.println("area is" + area);
        
    }
    public void printCir(double r){
        double radius = r;
        double cir =2*pi*r;
        System.out.println("circumference is" + cir);
    }
        public void printConeVol(double h, double r){
        double radius = r;
        double vol =pi*r*r*h/3.0;
        System.out.println("volume is" + vol);
    }
}