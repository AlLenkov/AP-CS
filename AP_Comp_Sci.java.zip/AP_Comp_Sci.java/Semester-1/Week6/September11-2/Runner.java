public class Runner{
    public static void main(String[] args) {
        Radius rad = new Radius();
        rad.printArea(10);
        rad.printCir(10);
        rad.printConeVol(10,5);
    }
}
