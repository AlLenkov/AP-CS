
import java.util.Scanner;

public class Formulas {
    private Scanner scan = new Scanner(System.in);

    private double pi = 3.14;
    private double gravity = 9.8;
    public String answer;

    public Formulas() {

    }

    public void f1() {
        // area of circle
        System.out.print("What radius do you want to use -->");
        double radius = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        String answer = String.valueOf(Math.round(pi * radius * radius * 10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f2() {
        // circumference of circle
        System.out.print("What radius do you want to use -->");
        double radius = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(pi * radius * 2 * 10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f3() {
        // area of sphere
        System.out.print("What radius do you want to use -->");
        double radius = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round((4 / 3 * pi * Math.pow(radius, 3.0)) * 10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f4() {
        // area of triangle
        System.out.print("What base do you want to use -->");
        double base = scan.nextDouble();
        System.out.print("What hight do you want to use -->");
        double hight = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(.5 * hight * base * 10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f5() {
        // area of square
        System.out.print("What side length do you want to use -->");
        double side = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(Math.pow(side, 2.0) * 10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f6() {
        // eclipse
        System.out.print("What value of a do you want to use -->");
        double a = scan.nextDouble();
        System.out.print("What value of b do you want to use -->");
        double b = scan.nextDouble();

        answer = String.valueOf(Math.round(a * b * pi*10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f7() {
        // area of trapazoid
        System.out.print("What height do you want to use -->");
        double height = scan.nextDouble();
        System.out.print("What sum of bases do you want to use -->");
        double SOB = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(.5 * SOB * height * 10) / 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f8() {
        // volume of a cube
        System.out.print("What side length do you want to use -->");
        double length = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(Math.pow(length, 3.0) / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f9() {
        // volume of rectangular prism
        System.out.print("What length do you want to use -->");
        double length = scan.nextDouble();
        System.out.print("What width do you want to use -->");
        double width = scan.nextDouble();
        System.out.print("What hight do you want to use -->");
        double hight = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(length * width * hight / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f10() {
        // volume of cylinder
        System.out.print("What radius do you want to use -->");
        double radius = scan.nextDouble();
        System.out.print("What height do you want to use -->");
        double height = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(pi * radius * radius * height / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f11() {
        // Ohms law finding voltage --> V
        System.out.print("What Current do you want to use -->");
        double I = scan.nextDouble();
        System.out.print("What Resistance do you want to use -->");
        double R = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(I * R / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f12() {
        // density
        System.out.print("What mass do you want to use -->");
        double mass = scan.nextDouble();
        System.out.print("What volume do you want to use -->");
        double volume = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(mass / volume / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f13() {
        // force
        System.out.print("What mass do you want to use -->");
        double mass = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(mass * gravity / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f14() {
        // Gravitational Force
        System.out.print("What mass do you want to use -->");
        double mass = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(mass * gravity / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

    public void f15() {
        // Escape Velocity: v = √(2 * g * R)
        System.out.print("What radius do you want to use -->");
        double R = scan.nextDouble();
        System.out.print("What Gravitational ecceleration do you want to use do you want to use -->");
        double G = scan.nextDouble();
        // calculates area and circumference of the circle then prints it
        answer = String.valueOf(Math.round(Math.sqrt(2 * R * G) / 10) * 10);
        System.out.print("With the values you provided, the answer is " + answer);
    }

}
