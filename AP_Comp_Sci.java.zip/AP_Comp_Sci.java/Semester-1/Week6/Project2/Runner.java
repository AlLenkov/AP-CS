
import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Formulas form = new Formulas();
        boolean done = false;
    

        while (done == false) {
        System.out.print(
                "\n\n\nWhat formula would you like to use?\n0: Stop the program\nf1:Area of a circle\nf2:circumference of circle\nf3:area of sphere\nf4:area of triangle\nf5:area of square\nf6:eclipse\nf7:area of trapazoid\nf8:volume of a cube\nf9:rectanular prism\nf10:volume of cylinder\nf11:Ohms law\nf12:density\nf13:force\nf14:Gravitational Force\nf15:Escape Velocity\n--> ");
        String Formula = scan.next();

            if (Formula.equals("f1")) {
                form.f1();
            } else if (Formula.equals("f2")) {
                form.f2();
            } else if (Formula.equals("f3")) {
                form.f3();
            } else if (Formula.equals("f4")) {
                form.f4();
            } else if (Formula.equals("f5")) {
                form.f5();
            } else if (Formula.equals("f6")) {
                form.f6();
            } else if (Formula.equals("f7")) {
                form.f7();
            } else if (Formula.equals("f8")) {
                form.f8();
            } else if (Formula.equals("f9")) {
                form.f9();
            } else if (Formula.equals("f10")) {
                form.f10();
            } else if (Formula.equals("f11")) {
                form.f11();
            } else if (Formula.equals("f12")) {
                form.f12();
            } else if (Formula.equals("f13")) {
                form.f13();
            } else if (Formula.equals("f14")) {
                form.f14();
            } else if (Formula.equals("f15")) {
                form.f15();
            } else if (Formula.equals("0")) {
                done = true;
            } else {
                System.out.print("Please enter a valid question example; f15 \n");
            }
        }
    }
}