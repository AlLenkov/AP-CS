
public class Runner {
    public static void main(String[] args) {
        // Instantiate MethodQuiz
        MethodQuiz mQuiz = new MethodQuiz();
        // call methods required
        mQuiz.printSurfaceArea();
        mQuiz.setVariables();
        mQuiz.printSurfaceArea();
        mQuiz.printVolume();
    }
}
