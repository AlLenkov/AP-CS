
public class MethodQuiz {
    // initialize variables
    private double pi;
    private int radius;

    public MethodQuiz() {
        // -- //
    }

    // makeing a method that sets variables
    public void setVariables() {

        pi = 3.14;
        radius = 5;
    }

    // makeing a method that sets prints surface area of a sphere
    public void printSurfaceArea() {
        double sa = Math.round(4 * pi * radius * radius * 10) / 10;
        System.out.println("the rounded surface area of a sphere with the radius " + radius + " is equal to " + sa);
    }

    // makeing a method that prints volume of a sphere
    public void printVolume() {
        double vol = Math.round(1.33 * pi * radius * radius * radius * 10) / 10;
        System.out.println("the rounded volume of a sphere with the radius " + radius + " is equal to " + vol);
    }

}
