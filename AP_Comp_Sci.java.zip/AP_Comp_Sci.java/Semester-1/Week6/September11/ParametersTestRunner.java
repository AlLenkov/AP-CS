
public class ParametersTestRunner{
	public static void main(String[] args){
	   ParametersTest testObj = new ParametersTest();
	   
	   //(1) Describe what is happening with the two lines of code below.
	   testObj.times(5, 7);
	   System.out.println();
	   
	   //(2)  Describe what is happening with the two lines of code below.
	   testObj.divide(3, 2);
	   System.out.println();
	   
	   //(3) Describe what is happening with the two lines of code below.
	   testObj.sayHello("Mrs. Winawer");

	}
}
