
public class ParametersTest{
	
	public void times(int num1, int num2){
		System.out.println(num1 * num2);
	}
	
	public void divide(double num1, double num2){
		System.out.println(num1 / num2);
	}
	
	public void sayHello(String wordInput){
		System.out.println("Hello " + wordInput);
	}
	
	
	
}
