public class Runner {
    public static void main(String[] args) {
        MathLibrary mathLib = new MathLibrary();

        mathLib.volCylinder(10, 15);
        mathLib.volSphere(10);
        mathLib.solvePythagorean(5, 12);
        mathLib.checkOddOrEven(-6);
        mathLib.checkOddOrEven(11);
        mathLib.solveQuadratic(1, 2, 2);
        mathLib.solveQuadratic(1, 2, -3);
    }
}
