public class MathLibrary {
    // Method to calculate the volume of a cylinder
    public void volCylinder(double radius, double height) {
        double volume = Math.PI * Math.pow(radius, 2) * height;
        System.out.println("Volume of the cylinder: " + volume);
    }

    // Method to calculate the volume of a sphere
    public void volSphere(double radius) {
        double volume = (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
        System.out.println("Volume of the sphere: " + volume);
    }

    // Method to check if a number is odd or even
    public void checkOddOrEven(int number) {
        if (number % 2 == 0) {
            System.out.println("Even");
        } else {
            System.out.println("Odd");
        }
    }

    // Method to solve a quadratic equation and print the solutions
    public void solveQuadratic(int a, int b, int c) {
        double discriminant = Math.pow(b, 2) - 4 * a * c;
        if (discriminant > 0) {
            double root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
            double root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
            System.out.println("Root 1: " + root1);
            System.out.println("Root 2: " + root2);
        } else if (discriminant == 0) {
            double root = -b / (2 * a);
            System.out.println("Root: " + root);
        } else {
            System.out.println("No real roots");
        }
    }

    // Method to solve for the hypotenuse using the Pythagorean theorem
    public void solvePythagorean(int a, int b) {
        double c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
        System.out.println("Hypotenuse: " + c);
    }
}
