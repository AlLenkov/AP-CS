public class Bus {
    // Instance variable
    private int numPassengers;  // Max number of passengers that will fit on a bus.

    // Constructors
    public Bus() {
        // Default constructor: Sets numPassengers to 200.
        this.numPassengers = 200;
    }

    public Bus(int numPassengers) {
        // Constructor with a parameter: Sets numPassengers to the number passed in.
        this.numPassengers = numPassengers;
    }

    // Methods
    public void numBuses(int passengers) {
        // Method to calculate and print how many buses are needed to transport the number of passengers passed in.
        double busesNeeded = Math.ceil((double) passengers / numPassengers);
        System.out.println("Number of buses needed: " + (int) busesNeeded);
    }

    public void numBuses(int passengers, int availableBuses) {
        // Method to check if there are enough buses for the passengers and print the result.
        if (passengers <= availableBuses * numPassengers) {
            System.out.println("The passengers will fit.");
        } else {
            System.out.println("Not enough buses for the passengers.");
        }
    }
}
