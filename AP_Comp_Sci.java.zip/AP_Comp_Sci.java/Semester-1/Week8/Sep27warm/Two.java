
public class Two {
    private String name;
    private int age;

    public Two() {
        name = "none";
    }

    public Two(String name) {
        this.name = name;
    }

    public void printName() {
        System.out.println("name is " + name);
    }

    public void printName(int age) {
        this.age = age;
        printName();
        System.out.println("age is " + age);
    }

}
