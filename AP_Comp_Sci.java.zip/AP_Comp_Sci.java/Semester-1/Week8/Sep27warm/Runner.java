
public class Runner {
    public static void main(String[] args) {
        Two obj = new Two();
        Two obj2 = new Two("Maria");
        obj.printName();
        obj.printName(15);
        obj2.printName();
        obj2.printName(15);
    }
}
