
public class Rectangle {
    private double length;
    private double width;

    public Rectangle() {
        length = 0;
        width = 0;
    }

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public void printArea() {
        double Area = length * width;
        System.out.println("Area of the Rectangle with sides " + length + " and " + width + " is " + Area);
    }
}
