
public class Runner {
    public static void main(String[] args) {
        // Inistiates rectangle with both constructors
        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle(5.0, 7.5);
        // Prints area from both constructors
        r1.printArea();
        r2.printArea();
    }
}
