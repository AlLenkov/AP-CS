
import java.util.Random;
import java.util.Scanner;

public class Trivia {
  public static void main(String[] args) {
    Scanner Scan = new Scanner(System.in);
    // declaring variables
    System.out.println("\n\n\n\t\t****Never answer with capital letters****\n\n\n");
    int Score = 0;
    int Questions = 12;
    int valid = 0;
    double ianswer;
    String answer;
    double canswer;
    // declaring rules
    double Randomint;
    double Randomint2;
    double Randomint3;
    Randomint = Math.round(Math.random() * 100);
    Randomint2 = Math.round(Math.random() * 100);

    while (valid == 0) {
      Score = 0;
      System.out.print("Would you like trivia on math or geography? --> ");
      answer = Scan.next();
      if (answer.equals("math")) {
        valid++;
        System.out.print("what is " + Randomint + "*" + Randomint2 + "+4= -->");
        ianswer = Scan.nextInt();
        if (ianswer == Randomint * Randomint2 + 4) {
          System.out.print("correct! ");
          // adds to Score if correct
          Score++;
        } else {
          canswer = Randomint * Randomint2 + 4;
          System.out
              .print("\nincorrect, The awnser was " + canswer + " this is because: " + Randomint + " * " + Randomint2
                  + " = " + Randomint * Randomint2 + "\n" + Randomint * Randomint2 + " + 4 = " + canswer + "\t-->");
          
        }
        Scan.nextLine();
        System.out.println("Your current score is " + Score + "\n\n");

        // Second Math Question
        Double Danswer;
        Randomint = Math.round(Math.random() * 10);
        Randomint2 = Math.round(Math.random() * 10);
        System.out.print("What is area of a right triangle with the length of the two legs being " + Randomint + " and "
            + Randomint2 + "-->");

        Danswer = Scan.nextDouble();
        if (Danswer == Randomint * Randomint2 / 2) {
          System.out.print("correct! ");
          // adds to Score if correct
          Score++;
          // Prints score
        }else{
          canswer = Randomint * Randomint2 / 2;
          System.out
              .print(
                  "\nincorrect, the area of a right triangle is found using the equation leg1*leg2/2, The awnser was "
                      + canswer + " this is because: " + Randomint + " * " + Randomint2 + " = " + Randomint * Randomint2
                      + "\n"
                      + Randomint * Randomint2 + " /2 = " + canswer + "\t-->");
        }
        System.out.println("Your current score is " + Score + "\n\n");
        Scan.nextLine();
        // Third Math Question

        Randomint = Math.round(Math.random() * 10);
        Randomint2 = Math.round(Math.random() * 10);
        Randomint3 = Math.round(Math.random() * 10);
        System.out.print(
            "Solve for x: x" + " - " + Randomint2 + " = " + Randomint3 + "+format x={} --> ");
        ;
        ianswer = Scan.nextInt();
        if (ianswer == Randomint3 + Randomint2) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.println("\nincorrect. ");
          
          canswer = (Randomint3 - Randomint2);
          Double subtractionnoworkinstring = Randomint3 - Randomint2;
          System.out.print("\nincorrect, The awnser was " + canswer + " this is because: " + Randomint3 + " - "
              + Randomint2
              + " = " + Randomint3 + Randomint2 * -1
              + "\nThis brings the intigers to one side, makeing it so we only have to devide it by the leading coefficient,"
              + subtractionnoworkinstring + " / " + Randomint + " = " + canswer + "\t-->");
        }
        System.out.println("Your current score is " + Score + "\n\n");
        // Forth Math Question
        Scan.nextLine();
        double danswer;
        System.out.print(

            " ");

        // danswer = Scan.nextDouble();
        // double roundedAnswer = Math.round(danswer * 10.0) / 10.0;
        Randomint = Math.round(Math.random() * 10);
        Randomint2 = Math.round(Math.random() * 10);
        System.out.print("what is x in " + Randomint + (" x = ") + Randomint2 + " --> ");
        danswer = Scan.nextDouble();
        if (Math.round(danswer * 100) == Math.round(Randomint2 / Randomint * 100)) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          canswer = Math.round(Randomint2 / Randomint * 100) / 100;
          System.out
              .println("\nincorrect. if you divide by" + Randomint + "on both sides you will find x = " + canswer);
          // Prints score
        }
        System.out.println("Your current score is " + Score + "\n\n");
        Scan.nextLine();

        // Fifth Math Question
        Randomint = Math.round(Math.random() * 10);
        Randomint2 = Math.round(Math.random() * 10);
        System.out.print(
            "Solve for x: " + Randomint + "x" + " + " + Randomint2 + " = 0 format x={} --> ");
        ;
        danswer = Scan.nextDouble();
        if (danswer == (Randomint2 * -1) / Randomint) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.println("\nincorrect. ");
          
          canswer = (Randomint2 * -1) / Randomint;
          Double subtractionnoworkinstring = Randomint3 - Randomint2;
          System.out.print("\nincorrect, The awnser was " + canswer + "\t-->");
        }
        System.out.println("Your current score is " + Score + "\n\n");
        // Sixth Math Question
        Scan.nextLine();

        // danswer = Scan.nextDouble();
        // double roundedAnswer = Math.round(danswer * 10.0) / 10.0;
        double Randomint01 = (int) (Math.random() * 10 + 1);
        double Randomint21 = (int) (Math.random() * 10 + 1);
        System.out.print("what is x in " + Randomint01 + ("x = ") + Randomint21 + " --> ");
        danswer = Scan.nextDouble();
        if (Math.round(danswer * 100.0) == Math.round(Randomint21 / Randomint01 * 100.0)) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {

          canswer = Randomint21 / Randomint01;
          System.out
              .println("\nincorrect. if you divide by" + Randomint01 + "on both sides you will find x = " + canswer);
          // Prints score
        }
        System.out.println("Your current score is " + Score + "\n\n");
        Scan.nextLine();
        



      //implementation of more dificult problems





        if (Score == 6) {
          System.out.print("(2x/5) + (3/10) = (x/2) what does x equal to (enter a intiger) --> ");
          danswer = Scan.nextDouble();

          if (danswer == 3) {
            System.out.print("\ncorrect! ");
            // adds to Score if correct
            Score++;
            Score++;

          } else {
            System.out.print("\nincorrect. ");
            // Prints score

          }
          System.out.println("Your current score is " + Score + "\n\n");

          System.out.print("3(x - 2) + 2(2x + 1) = 5x - 4 what does x equal to (enter a intiger) -->");
          danswer = Scan.nextDouble();

          if (danswer == 2) {
            System.out.print("\ncorrect! ");
            // adds to Score if correct
            Score++;
            Score++;
          } else {
            System.out.print("\nincorrect. ");
            // Prints score
          }
          System.out.println("Your current score is " + Score + "\n\n");

          System.out.print("What does 19/9 equal -->");
          danswer = Scan.nextDouble();

          if (Math.round(danswer * 100) == 211) {
            System.out.print("\ncorrect! ");
            // adds to Score if correct
            Score++;
            Score++;
          } else {
            System.out.print("\nincorrect. ");
            // Prints score
          }
          // prints letter grade
          System.out.println("Your current score is " + Score + "\n\n");
          if (Score < 3) {
            System.out.print("You got a F");
          } else if (Score == 3) {
            System.out.print("You got a D");
          } else if (Score == 4) {
            System.out.print("You got a C");
          } else if (Score == 5) {
            System.out.print("You got a B");
          } else if (Score == 6) {
            System.out.print("You got a A");
          } else {
            System.out.print("You got a A+");
          }
        }

      }
      /*
       * 
       * **** Geography ****
       * 
       */
      else if (answer.equals("geography")) {
        Score = 0;
        valid++;
        System.out.println("\n\nNow For The Geography Part");
        System.out.print(" What is the capital of France?\na.Sofia\nb.America\nc.Rome\nd.Paris\n--> ");
        answer = Scan.next();
        if (answer.equals("d")) {
          System.out.print("correct! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.print("\nincorrect.");
          
        }

        Scan.nextLine();
        System.out.println("Your current score is " + Score + "\n\n");

        // Second Geo Question

        System.out.print(
            "Which continent is known as the Land Down Under \na.North America\nb.South America\nc.Australia\nd.Europe\n--> ");

        answer = Scan.nextLine();
        if (answer.equals("c")) {
          System.out.print("correct! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.print("\nincorrect.");
          // Prints score
        }
        Score = Score + Score;
        System.out.println("Your current score is " + Score + "\n\n");
        Scan.nextLine();
        // Third Geo Question

        System.out.print(
            "Which river is the longest in the world?\na.nile river\nb.amazon river\nc.river john\nd.mile river --> ");

        answer = Scan.nextLine();
        if (answer.equals("a")) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.println("\nincorrect. ");

        }

        System.out.println("Your current score is " + Score + "\n\n");
        // Forth Geo Question
        Scan.nextLine();

        System.out.print(
            " Which mountain range spans across several European countries, including France and Italy? \na.Black Mountain\nb.Elephant Mountain\nc.The Alps\nd.Rocky Mountain --> ");
        answer = Scan.nextLine();

        if (answer.equals("c")) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.println("\nincorrect. ");
          // Prints score
        }

        System.out.println("Your current score is " + Score + "\n\n");
        Scan.nextLine();

        // Fifth Geo Question

        System.out.print(
            "The Atacama Desert, one of the driest deserts in the world, is located in which South American country?\na.Argentina\nb.Chile\nc.Brazil\nd.Paraguay --> ");

        answer = Scan.nextLine();
        if (answer.equals("b")) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.println("\nincorrect. ");
          
          // Prints score
        }
        Score = Score + Score;
        System.out.println("Your current score is " + Score + "\n\n");
        // Sixth Geo Question
        Scan.nextLine();

        System.out.print(
            " Which mountain range stretches across the western part of North America?\na.Black Mountains\nb.Elephant Mountain\nc.The Alps\nd.Rocky Mountain--> ");
        answer = Scan.nextLine();

        if (answer.equals("d")) {
          System.out.println("\ncorrect! ");
          // adds to Score if correct
          Score++;
        } else {
          System.out.println("\nincorrect. ");

          // Prints score
        }
        Score = Score + Score;
        System.out.println("Your current score is " + Score + "\n\n");
        Scan.nextLine();
        



      //implementation of more dificult problems





        if (Score == 6) {
          System.out.print("(What is the lowest natural point on Earth's surface, and where is it located?");
          answer = Scan.nextLine();

          if (answer.equals("challenger deep")) {
            System.out.print("\ncorrect! ");
            // adds to Score if correct
            Score++;
            Score++;

          } else {
            System.out.print("\nincorrect. ");
            // Prints score

          }

          System.out.println("Your current score is " + Score + "\n\n");

          System.out.print(
              "What is the largest island in the world that is not a continent.");
          answer = Scan.next();

          if (answer.equals("greenland")) {
            System.out.print("\ncorrect! ");
            // adds to Score if correct
            Score++;
            Score++;
          } else {
            System.out.print("\nincorrect. ");
            // Prints score
          }
          System.out.print(
              " What is the highest point on Earth, and in which mountain range is it located? Mount []-->");
          answer = Scan.next();
          if (answer.equals("Everest")) {
            System.out.print("\ncorrect! ");
            // adds to Score if correct
            Score++;
            Score++;

          } else {
            System.out.print("\nincorrect. ");
            // Prints score

          }

          System.out.println("Your current score is " +Score + "\n\n");
        }


        // prints letter grade
        if (Score < 3) {
          System.out.print("You got a F");
        } else if (Score == 3) {
          System.out.print("You got a D");
        } else if (Score == 4) {
          System.out.print("You got a C");
        } else if (Score == 5) {
          System.out.print("You got a B");
        } else if (Score == 6) {
          System.out.print("You got a A");
        } else {
          System.out.print("You got a A+");
        }
      } else {
        System.out.print("Please type a valid choice remember, no caps\n");
      }
    }
  };
}
