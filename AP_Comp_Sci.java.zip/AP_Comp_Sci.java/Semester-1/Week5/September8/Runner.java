public class Runner {
    public static void main(String[] args) {
        // Instantiate Triangle
        Triangle triangle = new Triangle();
        triangle.printArea();

        // Instantiate Square
        Square square = new Square();
        square.printArea();
        square.changeSide(); // Change the side
        square.printArea();

        // Instantiate Circle
        Circle circle = new Circle();
        circle.printArea();
        circle.setRadius(); // Set the radius
        circle.printArea();
    }
}
