import java.util.Scanner;

public class Circle {
    // Instance Variables
    private double pi = 3.14;
    private double radius;
    private double area;
    // Method to set the radius
    public void setRadius() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the radius of the circle: ");
        radius = scanner.nextDouble();

    }

    // Method to calculate and print the area
    public void printArea() {
        area = radius * radius * pi;
        System.out.println("Area of the circle: " + area);
    }
}
