public class Square {
    // Instance Variable
    private int side = 7;
    private int area;
    // Method to change the side
    public void changeSide() {
        side = 5;
    }

    // Method to print the area
    public void printArea() {
        area = side * side;
        System.out.println("Area of the square: " + area);
    }
}