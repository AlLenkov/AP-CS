

public class Runner{
	public static void main(String[] args){
		//(1) Where is Chicken coming from?
		Cat cat = new Cat();
		Dog dog = new Dog();
		

		cat.speak();
        dog.speak();
           
 	}
 	
}
