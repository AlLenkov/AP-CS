

public class Cat {

    public void speak(){     
    System.out.println("Meow");
        }
    public void sayName(){     
    System.out.println("My name is Felix");
        }
     
     
}
