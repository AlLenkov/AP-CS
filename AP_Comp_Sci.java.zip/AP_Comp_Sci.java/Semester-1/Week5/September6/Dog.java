

public class Dog {

    public void speak(){     
    System.out.println("Woof");
        }
    public void sayName(){     
    System.out.println("My name is not Felix");
        }
     
     
}
