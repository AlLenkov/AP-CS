import java.util.Scanner;

public class BuildSentence {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String verb, noun;
        System.out.print("name a verb ");
        verb = scan.next();
        System.out.print("name a noun ");
        noun = scan.next();
        String Sentance = ("the " + noun + " " + verb + "s");
        System.out.println(Sentance);
    }

}
