import java.util.Scanner;

public class Runner {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.print("what number would you like to calculate the somulation to\n--> ");
        int top = scan.nextInt();
        int count = 0;
        while (top > count) {
            count++;
            System.out.println(count);
        }
    }
}
