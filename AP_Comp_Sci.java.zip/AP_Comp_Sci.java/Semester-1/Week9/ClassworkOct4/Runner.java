import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        // While loop that counts from 1 to 12 inclusive by 1
        int count1 = 1;
        while (count1 <= 12) {
            System.out.print(count1 + " ");
            count1++;
        }
        System.out.println();

        // While loop that counts from 39 to 21 inclusive by 1
        int count2 = 39;
        while (count2 >= 21) {
            System.out.print(count2 + " ");
            count2--;
        }
        System.out.println();

        // While loop that counts from 2 to 20 inclusive by 2
        int count3 = 2;
        while (count3 <= 20) {
            System.out.print(count3 + " ");
            count3 += 2;
        }
        System.out.println();

        // Loop that counts from 15 to -10 inclusive by 5
        int count4 = 15;
        while (count4 >= -10) {
            System.out.print(count4 + " ");
            count4 -= 5;
        }
        System.out.println();

        // Ask the user for a number greater than 1
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number greater than 1: ");
        int userNumber = scanner.nextInt();


        // While loop that counts from 1 to the user's number by 1
        int count5 = 1;
        while (count5 <= userNumber) {
            System.out.print(count5 + " ");
            count5++;
        }
        System.out.println();

        // Ask the user for a number greater than 20 and what to count by

        System.out.print("Enter a number greater than 20: ");
        int userNumber2 = scanner.nextInt();
        System.out.print("Enter the count by number: ");
        int countBy = scanner.nextInt();


        // While loop that counts from 0 to the user's number by the count by number
        int count6 = 0;
        while (count6 <= userNumber2) {
            System.out.print(count6 + " ");
            count6 += countBy;
        }
        System.out.println();
    }
}
