package Week9.Oct4warm;

public class Runner {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(7.5, 4);

        double perimiter, length, width, volume, area;
        length = getLength();
        width = getWidth();
        area = getArea();
        perimiter = getPerimiter();
        volume = getVolume();

        System.out.print("length = "+ length+ "\nwidth = " +width+"\narea = "+area+"\nperimiter = " +perimiter);
        System.out.print("\nvolume = "+volume);
    }
}
