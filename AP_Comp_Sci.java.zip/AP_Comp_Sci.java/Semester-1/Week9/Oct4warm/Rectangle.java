package Week9.Oct4warm;

public class Rectangle {
    private double length, width;

    public Rectangle(double length, double width){
        this.length = length
    }
}
