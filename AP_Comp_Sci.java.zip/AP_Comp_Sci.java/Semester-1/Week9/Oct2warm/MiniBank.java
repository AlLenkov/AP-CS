
public class MiniBank {
    private double balance;
    private int pin;
    private boolean access;

    public MiniBank(double balance, int pin) {
        this.balance = balance;
        this.pin = pin;
    }

    public double getBalence(){
        if (access = true){
            if (balance >= 0){
                return(balance);
            }
        }else {
            return(-1.0);
        }
        
    }

    public void setAccess(int code) {
        if (code == pin) {
            access = true;
        }
    }

    public void withdraw(double withdraw) {
        if (access == true) {
            balance = -withdraw;
            printBalence();
        }
    }

    public void deposit(double deposit) {
        if (access == true) {
            balance = +deposit;
            printBalence();
        }
    }
}
