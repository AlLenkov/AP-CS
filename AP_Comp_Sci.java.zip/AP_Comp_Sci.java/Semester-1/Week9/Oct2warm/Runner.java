
public class Runner {
    public static void main(String[] args) {
        double balance;
        MiniBank m1 = new MiniBank(100, 1234);
        m1.setAccess(1234);
        System.out.println(m1.getBalence());
        m1.deposit(25);
        m1.withdraw(80);
    }
}
