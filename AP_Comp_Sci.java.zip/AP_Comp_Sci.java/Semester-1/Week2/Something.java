package Week2;

public class Something {
    
    public static void main(String args[]){
        int base = 7;
        int hight = 11;
        double arealnt = 0;
        double areaDbl = 0;
        System.out.println("\n base: " +base + "\n hight: " +hight + "\n arealnt: " +arealnt + "\n areaDbl: " +areaDbl);

    }
}
