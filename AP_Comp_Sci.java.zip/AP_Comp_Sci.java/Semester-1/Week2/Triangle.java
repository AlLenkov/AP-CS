package Week2;

public class Triangle {

    public static void main(String[] args) {
      System.out.println("  /\\   \n /  \\ \n/____\\");

    };
   
}
/*OUTPUT:
    /\   
   /  \ 
  /____\
 /      \
/        \*/     
