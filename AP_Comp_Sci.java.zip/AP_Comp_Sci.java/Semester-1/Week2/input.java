package Week2;

import java.util.Scanner;

public class input {
    public static void main(String[] args) {
    //inserting variables
    int num1;
    double num2;
    //scanning for variablese
    Scanner scan = new Scanner(System.in);
    System.out.println("enter integer");
    num1 = scan.nextInt();
    System.out.println("enter double");
    num2 = scan.nextDouble();
    //outputting multiplied variables
    System.out.println(num1 * num2);

    };
}
/*
 ***input***
 4,3
 ***output***
 12.0
 */