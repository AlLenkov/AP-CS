package Week2;

public class Some {

    public static void main(String[] args) {
      System.out.println("  /\\   \n /  \\ \n/____\\");

    };
   
}