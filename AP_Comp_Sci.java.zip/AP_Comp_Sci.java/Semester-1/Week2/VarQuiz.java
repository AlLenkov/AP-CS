package Week2;
/*
  creating code that using the value of pi and a radius
  - to calculate the circumference and area of a circle
 */
public class VarQuiz {
    public static void main(String[] args) {
    // creating variables
    int radius;
    double pi;
    // initializing variables
    pi = 3.14;
    radius = 10;
    // printing values of variables
    System.out.println("pi: " + pi);
    System.out.println("radius: " + radius);
    // creating, initializing and printing area variable
    double area;
    area = pi * radius * radius;
    System.out.println("area: " + area);
    // creating, initializing and printing circumference variable
    double circumference;
    circumference = 2 * pi * radius;
    System.out.println("circumference: " + circumference);
    };
}
/*
 ***CODE-OUTPUT***
    pi: 3.14
    radius: 10
    area: 314.0
    circumference: 62.800000000000004
 */