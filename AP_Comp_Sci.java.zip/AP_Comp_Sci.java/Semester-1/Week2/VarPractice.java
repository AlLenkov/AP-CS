package Week2;
public class VarPractice {
    public static void main(String[] args) {
    int var1 = 5;
    double var2 = 10.5;
    char var3 = 'a';
    boolean var4 = true;
    System.out.println("var1= "+var1);
    System.out.println("var2= "+var2);
    System.out.println("var3= "+var3);
    System.out.println("var4= "+var4);   
    
    int NumOne = 4;
    int NumTwo = 6;

    int Middleone = (NumOne + NumTwo) / 2;
    System.out.println("Middlone= "+Middleone);   
    };
}

