package Week2;
//© A+ Computer Science  -  www.apluscompsci.com

//identifier example

public class Identifiers {
    public static void main(String args[]){
        int bigNum=99;

        double decimal = 8.25;

        double v = 657;

        char littleA = 'a';

        boolean isPrime = false;

        String s = "abc";
    }
}