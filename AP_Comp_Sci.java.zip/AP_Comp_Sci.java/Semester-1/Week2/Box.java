package Week2;

public class Box {
    public static void main(String[] args) {
        //prints box
        System.out.println(" ___ \n|   |\n|___|");

    }; 
}
