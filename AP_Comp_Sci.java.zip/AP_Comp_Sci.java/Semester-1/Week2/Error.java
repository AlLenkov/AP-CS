package Week2;
public class Error {
    public static void main(String[] args){
        System.out.println("0/9 is "+(0/9));
    }
}
