
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;
import java.util.Random;

// This code will move a rectangle across the screen, left to right
public class AnimateScreen extends JPanel {

    // Instance variables

    int cloudx = 0;
    int suny = 160;
    int animalx = 200;

    // Constructor
    public AnimateScreen() {

    }

    // Set the dimension of the JPanel
    @Override
    public Dimension getPreferredSize() {
        // Sets the size of the panel
        return new Dimension(800, 600);
    }

    // Call methods that will draw on the JPanel
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // rObj.drawRectangle(g); // draw the rectangle

        daytime(g);
        int i = 0;
        while (i < 10) {
            drawTree(g, i * 100, 400);
            i++;
        }
        i = 0;
        while (i < 800) {
            grass(g, i);
            i += 5;
        }
        i = 0;
        while (i < 10) {
            flower(g, i * 100, 500);
            i++;
        }

        cloud(g);
        sun(g);
        bee(g);
    }

    private void flower(Graphics g, int x, int y) {

        // changes on season or day

        // sets colors
        Color colorRed = new Color(200, 0, 0);
        Color colorGreen = new Color(1, 50, 1);
        Color colorYellow = new Color(255, 255, 10);
        // draws object(s)
        g.setColor(colorGreen);
        g.fillRect(x, y, 10, 30);
        g.setColor(colorRed);
        g.fillOval(x - 5, y - 5, 20, 20);
        g.setColor(colorYellow);
        g.fillOval(x, y, 10, 10);

    }

    private void cloud(Graphics g) {
        Color colorWhite = new Color(255, 255, 255);
        g.setColor(colorWhite);
        g.fillOval(cloudx, 50, 20, 20);
        g.fillOval(cloudx + 40, 50, 20, 20);
        g.fillOval(cloudx + 15, 50, 20, 20);
        g.fillOval(cloudx + 25, 50, 20, 20);
        g.fillOval(cloudx + 20, 50, 20, 20);
        g.fillOval(cloudx + 30, 50, 20, 20);
        g.fillOval(cloudx + 10, 60, 20, 20);
        g.fillOval(cloudx + 10, 40, 20, 20);
        g.fillOval(cloudx + 30, 60, 20, 20);
        g.fillOval(cloudx + 30, 40, 20, 20);

    }

    private void sun(Graphics g) {
        Color colorYellow = new Color(255, 255, 10);
        g.setColor(colorYellow);
        g.fillOval(500, suny, 40, 40);

    }

    public void bee(Graphics g) {
        // sets colors

        Color colorBrown = new Color(73, 52, 12);
        g.setColor(colorBrown);
        // draws object(s)
        int y = 300;
        // g.fillPolygon(xPoints, yPoints, npoints);
        g.setColor(Color.YELLOW);
        g.fillOval(animalx + 70, y - 10, 40, 30);
        g.setColor(Color.BLACK);
        g.fillOval(animalx + 80, y - 10, 10, 30);
        g.setColor(Color.BLACK);
        g.fillOval(animalx + 90, y - 10, 10, 30);
        g.setColor(Color.BLACK);
        g.fillOval(animalx + 80, y - 30, 15, 20);
        g.setColor(Color.WHITE);
        g.fillOval(animalx + 98, y + 3, 7, 7);
        g.setColor(Color.BLACK);
        g.fillOval(animalx + 100, y + 5, 3, 3);

    }

    private void grass(Graphics g, int grassx) {

        grassx = grassx;
        // sets colors

        Color colorGreen = new Color(20, 98, 30);
        g.setColor(colorGreen);
        int y = 500;
        g.fillOval(grassx, y, 4, 6);

    }

    private void daytime(Graphics g) {

        // changes on season or day
        // sets colors
        Color colorBrown = new Color(179, 132, 85);
        Color colorBlue = new Color(155, 229, 255);
        // draws object(s)
        g.setColor(colorBlue);
        g.fillRect(0, 0, 800, 200);
        g.setColor(Color.GREEN);
        g.fillRect(0, 200, 800, 400);

    }

    private void drawTree(Graphics g, int x, int y) {

        // sets colors
        Color colorBrown = new Color(100, 42, 42);
        Color colorGreen = new Color(0, 128, 0);
        Color colorDGreen = new Color(0, 70, 0);

        // draws object(s)
        g.setColor(colorBrown);
        g.fillRect(x, y, 30, 100);
        g.setColor(colorDGreen);
        g.fillOval(x - 40, y - 55, 110, 110);
        g.setColor(colorGreen);
        g.fillOval(x - 35, y - 50, 100, 100);

    }

    /*
     * This method runs in parallel with the other methods.
     * That is why a try catch exception handler is needed.
     * Copy this code exactly as is. You will add calls to your methods
     * that move your objects.
     */
    public void animate() {

        while (true) {

            if (cloudx == 800) {
                cloudx = 0;
            } else {
                cloudx += 2;
            }

            if (animalx == 800) {
                animalx = 0;
            } else {
                animalx += 1;
            }

            if (suny == 0) {
                suny = 160;
            } else {
                suny--;
            }

            // wait for .01 second
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }

            // You add code here. moveRectangle is called continously to simulate movement

            /*
             * Repaint the graphics drawn. You MUST have this in your code
             * because each time an object is moved, the panel needs to
             * be updated.
             */
            repaint();
        }
    }
}
