
/*
 The difference between a while loop and a do while loop is when they check if the condition
 has been completed, while does it before it runs, do while does it after.
 */
import java.util.Scanner;
public class Factorial {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("what number would you like to use?");
        int topfactorial = scan.nextInt();
        int factorial = 1;
        while (topfactorial > 0){
            factorial = topfactorial * factorial;
            topfactorial--;
        }
        System.out.print("factorial = " + factorial);
    }
}
