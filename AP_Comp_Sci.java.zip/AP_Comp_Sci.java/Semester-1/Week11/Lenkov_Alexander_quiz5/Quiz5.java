public class Quiz5 {
    // constructor
    public Quiz5() {
        /** void **/
    }

    // counts down from number passed in to 0
    public void countDownBy3(int topnum) {
        int currentnum = topnum;
        while (currentnum >= 3) {
            // prints number then lowers it by 3
            System.out.print(currentnum + "\t");
            currentnum -= 3;
        }
        // adding space
        System.out.print(" \n ");
    }

    // calculates sum between number passed in and 0
    public int getSummation(int topnum) {
        int currentnum = topnum, addednum = 0;
        do {
            // adds currentnum to addednum then sutracts current num and repeats.
            addednum += currentnum;
            currentnum--;
        } while (currentnum >= 1);
        // returns addednum
        return addednum;
    }

}
