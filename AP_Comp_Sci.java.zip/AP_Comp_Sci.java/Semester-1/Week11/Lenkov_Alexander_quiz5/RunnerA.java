public class RunnerA {
    public static void main(String[] args) {
        // Instantaite Quiz5
        Quiz5 obj = new Quiz5();

        // Call countDownBy3(15).
        obj.countDownBy3(15);

        // Call getSummation(6) and print
        int Summation = obj.getSummation(6);
        System.out.print("Summination passing in 6 is " + Summation);
    }
}
