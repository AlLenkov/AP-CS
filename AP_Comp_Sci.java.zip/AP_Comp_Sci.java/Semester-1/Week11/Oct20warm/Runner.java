
public class Runner {
    public static void main(String[] args) {
        Count obj = new Count(50);
        System.out.println(obj.getSum(5));
        System.out.println(obj.getSum(9));
    }
}
