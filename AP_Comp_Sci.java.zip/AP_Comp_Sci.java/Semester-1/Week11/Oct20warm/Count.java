public class Count {
    private int value;

    // Constructor
    public Count(int value) {
        this.value = value;
    }

    // Method to get sum
    public int getSum(int countBy) {
        int sum = 0;
        int current = 0;
        while (current <= this.value) {
            sum += current;
            current += countBy;
        }
        return sum;
    }
}





