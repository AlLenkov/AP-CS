
public class Loop {
   public static void main(String[] args) {
        // while loop
        int sumWhile = 0;
        int whileCounter = 2;
        while (whileCounter <= 19) {
            sumWhile += whileCounter;
            whileCounter++;
        }
        System.out.println("Sum using while loop " + sumWhile);

        // do while loop
        int sumDoWhile = 0;
        int doWhileCounter = 2;
        do {
            sumDoWhile += doWhileCounter;
            doWhileCounter++;
        } while (doWhileCounter <= 19);
        System.out.println("Sum using do-while loop: " + sumDoWhile);

        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Please enter a number: ");
        int userNumber = scanner.nextInt();

        if (userNumber > 0) {
            // Count up from 1 to the number
            int countUp = 1;
            do {
                System.out.print(countUp + " ");
                countUp++;
            } while (countUp <= userNumber);
        } else if (userNumber < 0) {
            // Count down from the number to 1
            int countDown = userNumber;
            do {
                System.out.print(countDown + " ");
                countDown++;
            } while (countDown <= 1);
        }

    }
}
