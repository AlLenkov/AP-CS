import java.util.Scanner;

public class Runner {

  public static void main(String[] args) {

	  double score1, score2, score3;

	  boolean pass;

	  Scanner scan= new Scanner(System.in);

    System.out.print("Give me a score --> ");

	  score1=scan.nextInt();

	      System.out.print("Give me a score --> ");

		    score2=scan.nextInt();

	      System.out.print("Give me a score --> ");

		    score3=scan.nextInt();

	  Grade g=new Grade(score1, score2, score3);

	 pass= g.checkPass();

	  if (pass==true){

		  System.out.println("You passed!");

	  }else{

		  System.out.println("You failed");

	  }

  }

}