
/*
 - int num1, num2, num3 :  3 numbers that will generated randomly during game play
- int winnings: this is used to display how much the user wins after a game play
- int balance: keeps track of the balance 
+SlotMachine(int)   The constructor takes the balance as a parameter and initializes it.
+drawMachine(Graphics):void - Draw the machine (this can be just a box or you can import an image) with the 3 numbers, current balance, and winnings.  In addition, call drawPayOut(Graphics)

-drawPayOut(Graphics):void - Draw a payout table. This is informational for the user.
	7 7 7 = 100 points.
	3 of a kind = 5 points.  
	2 of a kind = 2 points.
+play():void -  Generate 3 new random numbers for num1, num2 and num3.  Calculate the winnings.  Updates the balance and winnings.

 */
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Color;
import java.net.URL;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SlotMachine {
    public int num1, num2, num3, winnings, balance;

    public SlotMachine(int balance) {
        this.balance = balance;

    }

    public void drawMachine(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(100, 100, 600, 400);
        g.setColor(Color.BLACK);
        Font font2 = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font2);
        g.drawString("balance = " + balance, 200, 310);
        g.drawString("winnings = " + winnings, 200, 330);
        Font font1 = new Font("Arial", Font.PLAIN, 50);
        g.setFont(font1);
        g.drawString(num1 + " " + num2 + " " + num3, 350, 100);
        drawPayOut(g);

    }

    public void playSoundbad() {

        try {
            URL url = this.getClass().getClassLoader().getResource("ominous.wav");
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(url));
            clip.start();
        } catch (Exception exc) {
            exc.printStackTrace(System.out);
        }
    }

        public void playSoundgood() {

        try {
            URL url = this.getClass().getClassLoader().getResource("bloop_x.wav");
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(url));
            clip.start();
        } catch (Exception exc) {
            exc.printStackTrace(System.out);
        }
    }

    public void drawPayOut(Graphics g) {
        Font font1 = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font1);
        g.drawString("7 7 7 = 100 points.\n3 of a kind = 5 points.\n2 of a kind = 2 points.", 100, 500);
    }

    public void play() {
        num1 = (int) (Math.random() * 9 + 1);
        num2 = (int) (Math.random() * 9 + 1);
        num3 = (int) (Math.random() * 9 + 1);

        // System.out.println("x is : " + num1 + ", y is : " + num2 + ", z is : " +
        // num3);
        calcBalance(calcWin(num1, num2, num3));
    }

    public int calcWin(int num1, int num2, int num3) {

        if (num1 == 7 && num2 == 7 && num3 == 7) {
            winnings = 100;
            playSoundgood();
        } else if (num1 == num2 && num1 == num3 && num2 == num3) {
            winnings = 5;
            playSoundgood();
        } else if (num1 == num2 || num1 == num3 || num2 == num3) {
            winnings = 2;
            playSoundgood();
        } else {
            winnings = 0;
            playSoundbad();
        }
        return (winnings);

    }

    public void calcBalance(int win) {
        balance = balance - 1 + winnings;

        if (balance == 0) {
            System.exit(0);
        }

    }
}
