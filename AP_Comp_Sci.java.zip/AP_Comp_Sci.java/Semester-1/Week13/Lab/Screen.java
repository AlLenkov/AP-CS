import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Screen extends JPanel implements ActionListener {
  // Instance Variables
  // create a button

  private JButton spinButton;

  // create a textbox

  private JTextField spinInput;



  // Initialization Constructor
  public Screen() {
    // instantiate button




    spinButton = new JButton("spin");
    // instantiate the textfield


    // instantiate a customer

    setLayout(null); // JPanel method that initializes the layout

    // set positions for the button and textfield

    spinButton.setBounds(350, 350, 100, 30);


    // add button and textfield to panel

    add(spinButton);

    // set up to listen for the button click

    spinButton.addActionListener(this);


  }





  // set the size of the JPanel container



    SlotMachine sm = new SlotMachine(100);

    @Override
    public Dimension getPreferredSize() {
      return new Dimension(800, 600);
    }
  
    @Override
    public void paintComponent(Graphics g) {

      super.paintComponent(g);
      sm.drawMachine(g);
    }

    public void actionPerformed(ActionEvent event){
    // action to be performed when a button is clicked
      if (event.getSource() == spinButton) {
        sm.play();

        
        //System.out.print("www");
        }
      
      // This line MUST be here refresh the screen
      repaint();

    }

}
