public class Quiz6 {
    //constructor
    int grade1, grade2;
    public Quiz6(int grade1, int grade2){
        this.grade1=grade1;
        this.grade2=grade2;
    }

    public String getGrade1() {
        if(grade1>=95 && grade2>=95){
            return "A" ;    //grade is a A
        }else if(grade1>=90 || grade2>=90){
            return "B" ;    //grade is a B
        }else{
            return "F" ;    //grade is a F
        }
    }

     public String getGrade2(){
        switch(grade2){
            case 95:
                return "A";    //grade is a A

            case 85:
                return "B";    //grade is a B

            case 75:
                return "C";    //grade is a C

            default:
                return "F";    //grade is a F

                                               
        }
     }
}
