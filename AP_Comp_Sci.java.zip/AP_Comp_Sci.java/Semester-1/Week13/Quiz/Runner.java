public class Runner {
    /*
     * Instantiate Quiz6 with the numbers 96 and 95 respectively with object name
     * q1.
     * Instantiate Quiz6 with the numbers 90 and 75 respectively with object name
     * q2.
     * Call getGrade1() from q1, store the result in a variable, and print it in a
     * complete sentence. For example, "You earned an A."
     * Call getGrade2() from q1, store the result in a variable, and print it in a
     * complete sentence.
     * Call getGrade1() from q2, store the result in a variable, and print it in a
     * complete sentence.
     * Call getGrade2() from q2, store the result in a variable, and print it in a
     * complete sentence.
     * 
     */
    public static void main(String[] args) {
        //inistiate object q1 and q2
        Quiz6 q1 = new Quiz6(96, 95);
        Quiz6 q2 = new Quiz6(90, 75);

        String grade1_1 = q1.getGrade1();//grade1
        String grade1_2 = q1.getGrade2();//grade2
        String grade2_1 = q2.getGrade1();//grade3
        String grade2_2 = q2.getGrade2();//grade4

        System.out.println("you earned a " + grade1_1);//grade1
        System.out.println("you earned a " + grade1_2);//grade2
        System.out.println("you earned a " + grade2_1);//grade3
        System.out.println("you earned a " + grade2_2);//grade4
    }
}
