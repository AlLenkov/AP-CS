public class Runner {
    public static void main(String[] args) {

        for (int i = 1; i < 26; i++) {
            System.out.print(i +",");
        }
        System.out.println("\n\n\n\n\n");
        for (int i = 25; i >0; i--) {
            System.out.print(i+",");
        }

    }

}
