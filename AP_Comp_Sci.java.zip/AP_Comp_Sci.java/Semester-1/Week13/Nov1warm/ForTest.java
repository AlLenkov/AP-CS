public class ForTest {

    public ForTest(){
        
    }
    
    public void printNums(int one, int two){
        for(int i = one;i<=two;i++){
            System.out.print(i+" ");
        }

    }
        public int getFactorial(int fac){
        int answer = 1;
        for (int i = fac;i>=1;i--){
            answer *= i;
        }
        return answer;
    }
}





