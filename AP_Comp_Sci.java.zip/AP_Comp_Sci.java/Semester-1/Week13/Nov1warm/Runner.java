public class Runner {
    public static void main(String[] args) {
        ForTest f = new ForTest();

        System.out.print( f.getFactorial(5));
    }
}
