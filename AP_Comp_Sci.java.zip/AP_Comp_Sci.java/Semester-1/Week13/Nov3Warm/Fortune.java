public class Fortune {


    public String getFortune(int luck){
        if(luck%2==0 && luck>8){
            return("you will have good luck");
        }else if(luck%5==0 || luck<9){
            return("you will have bad luck");
        }else{
            return("you will not have good or bad luck");
        }
    }
    public void tellFortune(int luck){
        switch(luck){
            case 2:
                System.out.println("you will have good luck");
                break;
            case 5:
                System.out.println("you will not have good or bad luck");
                break;
            default:
                System.out.println("you will have bad luck");
        }
    }

}
