public class Runner {
    public static void main(String[] args) {
        Fortune obj = new Fortune();

            System.out.println(obj.getFortune(10));
            System.out.println(obj.getFortune(8));
            System.out.println(obj.getFortune(17));
            obj.tellFortune(2);
            obj.tellFortune(5);
            obj.tellFortune(8);

    }
}
