import java.util.Scanner;
public class InputQuiz{
    public static void main(String[] args) {
    String name;
    // asks for and collects name to later use it in a print statement
    System.out.print("What is your first name? ");
    Scanner scan = new Scanner(System.in);
    name = scan.next();
    System.out.println("Hello " + name + ", this program will calculate the area and circumference of a circle.");
    //declares variables and asks for radius for calculation
    double radius, pi;
    pi = 3.14;
    System.out.print("Please enter a intiger or decimal for a radius ");
    radius = scan.nextDouble();
    //calculates area and circumference of the circle then prints it
    double area = pi * radius * radius;
    System.out.println("The area of a circle with the radius "+ radius +" is "+ area);
    double circumference = 2 * pi * radius;
    System.out.println("The circumference of a circle with the radius "+ radius +" is "+ circumference);
    }
}