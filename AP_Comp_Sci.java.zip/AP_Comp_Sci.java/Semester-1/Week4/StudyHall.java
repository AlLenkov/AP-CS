//Ishir, 
import java.util.Scanner;
public class StudyHall {
public static void main(String[] args) {
  Scanner Scan = new Scanner(System.in);
  //declaring variables
  System.out.println("Always answer with no capital letters\n");
  int Score = 0;

  
  //First Math Question

  
  String answer;
  //declaring rules
  System.out.println("Math" + '\n' + "What shape is this:\n  /\\   \n /  \\ \n/____\\ ");
  //Scanner Scan = newscanner(system.in);
  answer = Scan.nextLine();
  if(answer.equals("triangle")){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    //subtracts if Score awnser is incorrect
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
    }
  Scan.nextLine();

  
  //Second Math Question

  
  double ianswer;
  System.out.println("15x12=?");
  //Scanner Scan = newscanner(system.in);
  ianswer = Scan.nextInt();
  if(ianswer==180){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);;
  }
  Scan.nextLine();
  Scan.nextLine();
  
  //Third Math Question

  
  System.out.println("Is b in y=mx+b the y or x intercept \n answer like []-intercept");
  //Scanner Scan = newscanner(system.in);
  answer = Scan.nextLine();
  if(answer.equals("y")){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }else{
    System.out.print("incorrect\n");
    //subtracts if Score awnser is incorrect
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
    }
 //Forth Math Question
  Scan.nextLine();
  double danswer;
  System.out.println("What is the perpendicular slope of the line y=-(5/3)x-10 in decimal form");
  //Scanner Scan = newscanner(system.in);
  danswer = Scan.nextDouble();
  if(danswer==0.6){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
      }
Scan.nextLine();
Scan.nextLine();
  
  //History question 1
  //declaring rules
  System.out.println("History" + '\n' + "Who was the leader of the French Revolution: ");
  //Scanner Scan = newscanner(system.in);
  answer = Scan.nextLine();
  if(answer.equals("napolean")){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    //subtracts if Score awnser is incorrect
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
    }
  Scan.nextLine();

  
  //Second History Question


  System.out.println("When did the Civil War end: ");
  //Scanner Scan = newscanner(system.in);
  ianswer = Scan.nextInt();
  if(ianswer==1865){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);;
  }
  Scan.nextLine();
  Scan.nextLine();
  
  //Third History Question

  
  System.out.println("Who was the first president: ");
  //Scanner Scan = newscanner(system.in);
  answer = Scan.nextLine();
  if(answer.equals("george washington")){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }else{
    System.out.print("incorrect\n");
    //subtracts if Score awnser is incorrect
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
    }
 //Forth History Question
  Scan.nextLine();
  System.out.println("How many people died in World War 2 (best estimate)");
  //Scanner Scan = newscanner(system.in);
  ianswer = Scan.nextInt();
  if(ianswer<=80000000 && ianswer>=50000000){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
      }
  
  //First Coding Question
  System.out.println("What is the largest number that can be stored ");













  





  
  
  
  // // first art question
   System.out.println("Art" + '\n' + "What is this picture?");
   System.out.println("\n|  _  |\n| |_| |\n|_____|");
   answer = Scan.nextLine();
   // this will ask the user what the picture is
   if(answer.equals("box")) {
     System.out.print("correct\n");
     // adds to score if correct
     Score++;
     System.out.println("Your score is " + Score);
   }
   else{
     System.out.print("incorrect\n");
     //subtracts if Score awnser is incorrect
     Score--;
     //Prints score
     System.out.println("Your score is " + Score);
    }
  System.out.println("What is this picture?");
   System.out.println("¯\_(ツ)_/¯");
   answer = Scan.nextLine();
   // this will ask the user what the picture is
   if(answer.equals("shrug")) {
     System.out.print("correct\n");
     // adds to score if correct
     Score++;
     System.out.println("Your score is " + Score);
   }
   else{
     System.out.print("incorrect\n");
     //subtracts if Score awnser is incorrect
     Score--;
     //Prints score
     System.out.println("Your score is " + Score);
    }
    System.out.println("What is this picture?");
   System.out.println("");
   answer = Scan.nextLine();
   // this will ask the user what the picture is
   if(answer.equals("idk")) {
     System.out.print("correct\n");
     // adds to score if correct
     Score++;
     System.out.println("Your score is " + Score);
   }
   else{
     System.out.print("incorrect\n");
     //subtracts if Score awnser is incorrect
     Score--;
     //Prints score
     System.out.println("Your score is " + Score);
    }
  
  
  
  
  
  
  
  
  
  //Coding question 1

  
  Boolean banswer;
  //declaring rules
  System.out.println("Coding" + '\n' + "Does // turn code on the same line into a comment in java? ");
  //Scanner Scan = newscanner(system.in);
  banswer = Scan.nextLine();
  if(banswer == 1){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    //subtracts if Score awnser is incorrect
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
    }
  Scan.nextLine();

  
  //Coding question 2

  
  double ianswer;
  System.out.println("What is the largest number that can be stored in one byte? ");
  //Scanner Scan = newscanner(system.in);
  ianswer = Scan.nextInt();
  if(ianswer==255){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);;
  }
  Scan.nextLine();

  
  //Coding question 3

  
  System.out.println("What data type is used for decimals? ");
  //Scanner Scan = newscanner(system.in);
  answer = Scan.nextLine();
  if(answer.equals("Double")){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }else{
    System.out.print("incorrect\n");
    //subtracts if Score awnser is incorrect
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
    }
  
 //Forth Math Question

  
  Scan.nextLine();
  System.out.println("What is 0001 0101 (binary) in base-10 numbers: ");
  //Scanner Scan = newscanner(system.in);
  ianswer = Scan.nextInt();
  if(ianswer==21){
    System.out.print("correct\n");
    //adds to Score if correct
    Score++;
    System.out.println("Your score is " + Score);
  }
  else{
    System.out.print("incorrect\n");
    Score--;
    //Prints score
    System.out.println("Your score is " + Score);
      }
Scan.nextLine();
Scan.nextLine();
   }
}