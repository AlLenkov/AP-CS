
import java.util.Scanner;
public class MailingLabel {
public static void main(String[] args) {
   // String nameF;
   // String nameL;
   // String wSA;
  //  String cS;
  //  int zIP;
    System.out.print("What is the first name ");
    Scanner scan = new Scanner(System.in);
    String nameF = scan.next();

    System.out.print("What is the last name ");
    Scanner scan1 = new Scanner(System.in);
    String nameL = scan1.next();

    System.out.print("What is the Whole Street Address ");
    Scanner scan2 = new Scanner(System.in);
    String wSA = scan2.nextLine();

    System.out.print("What is your city and State ");
    Scanner scan3 = new Scanner(System.in);
    String cS = scan3.nextLine();
    // finds ZIP CODE
    System.out.print("zip code ");
    Scanner scan5 = new Scanner(System.in);
    int zIP = scan5.nextInt();

    System.out.print(nameF + " " + nameL+"\t"+nameF + " " + nameL +"\n"+ wSA +"\t"+ wSA +"\n"+ cS +" "+ zIP+"\t" +cS +" "+ zIP);






    };
}
