import java.util.Scanner;
public class QuizPractice {

public static void main(String[] args) {
    double length, width, area;
    String polyNam;
    System.out.print("Supply a length of a polygon ");
    Scanner scan = new Scanner(System.in);
    length = scan.nextInt();
    System.out.print("Supply a width of a polygon ");
    width = scan.nextInt();
    area = length*width;
    System.out.println("area=length*width = " + area);
    System.out.print("what is the name of the polygon ");
    polyNam = scan.next();
    if (polyNam.equals("rectangle")){
        System.out.print("good job");
    }
    else {
        System.out.print("bad job");
    }
    }
}
//void Scanner

