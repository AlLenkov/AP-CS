public class Runner {
    public static void main(String[] args) {
        
    
    ArreyTest arrObj = new ArreyTest(5);

    arrObj.print();
    System.out.println("average = " +arrObj.average());
    System.out.println("smallest = " +arrObj.getIndexOfSmallest());

    }
}
