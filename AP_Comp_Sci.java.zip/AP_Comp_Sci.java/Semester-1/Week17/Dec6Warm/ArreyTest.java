public class ArreyTest {

    private int[] numArray;
  

    public ArreyTest(int size){
        numArray = new int[size];
        for (int i = 0; i < numArray.length; i++){
            numArray[i] = (int) (Math.random()*9+1);
        }

    }

    public void print(){
        for (int each:numArray){
            System.out.print(each+", ");
        }
        System.out.println("\n\n");
    }

    public double average(){
        int average = 1;
        for (int each:numArray){
            average +=each;
        }
        return (average/numArray.length);
    }

    public int getIndexOfSmallest(){
        int index = 0;
        int smallest = numArray[0];
        for (int i=1;i<numArray.length;i++){
            if(smallest > numArray[i]){
                smallest = numArray[i];
                index = i;
            }
        }
        return index;

    }
}
