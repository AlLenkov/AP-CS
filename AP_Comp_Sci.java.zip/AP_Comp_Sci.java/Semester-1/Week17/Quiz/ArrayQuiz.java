public class ArrayQuiz {
    private int[] numArray;

    // Constuctor: uses inputed intiger in order to instantiate a array with that
    // amount of index's
    public ArrayQuiz(int size) {
        numArray = new int[size];
        // assignes every index of the array a random number from 1-10 inclusive
        for (int i = 0; i < size; i++) {
            numArray[i] = (int) (Math.random() * 10 + 1);
        }
    }

    // prints every element of a array followed by a space
    public void print() {
        // uses for each loop in order to print every element of array
        for (int each : numArray) {
            System.out.print(each + " ");
        }
        // adds space after printing full array
        System.out.println("");
    }

    // returns element at index passed in
    public int getNum(int index) {
        return numArray[index];
    }

    // finds largest element in array
    public int getLargest() {
        // largest gets set to index 0 so we dont have to check it.
        // if the other elements's are not largest, it will already be set to the element
        // at index 0
        int largest = numArray[0];
        // for loop to go through every index (other than 0) of array
        for (int i = 1; i < numArray.length; i++) {
            if (numArray[i] > largest) {
                // if element in index i is larger than int largest it gets set to the new
                // one
                largest = numArray[i];
            }
        }
        // returns largest after looking through every element
        return largest;
    }

}
