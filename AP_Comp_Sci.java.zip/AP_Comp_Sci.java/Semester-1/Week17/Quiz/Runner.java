public class Runner {
    public static void main(String[] args) {
        // integer for answers
        int answer;
        // instantiate arrayQuiz as obj
        ArrayQuiz obj = new ArrayQuiz(8);
        // call print
        obj.print();
        // set getNum(4) to answer
        answer = obj.getNum(4);
        // print it
        System.out.println("The element at index location 4 is " + answer);
        // set getLargest() to answer
        answer = obj.getLargest();
        // print it
        System.out.println("Largest is " + answer);
    }
}
