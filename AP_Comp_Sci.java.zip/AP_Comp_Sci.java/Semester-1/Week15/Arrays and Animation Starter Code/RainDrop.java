import java.awt.Color;
import java.awt.Graphics;

// This class creates and moves one raindrop
public class RainDrop{
	
	private int x, y;
	private Color blue;
	
	public RainDrop(){
		x=(int)(Math.random()*999);
		y=(int)(Math.random()*999);
		blue = new Color(0,0,255);
		
	}
	
	public void drawRainDrop(Graphics g) {

		g.setColor(blue);
		g.fillOval(x,y,5,9);
	}
	
	public void moveDown() {
		x--;		

		if(x>800){
			x = -5;
			y=(int)(Math.random()*599);
		}

	}
	
}