import java.util.Scanner;
class Runner {
  public static void main(String[] args) {
	  Scanner scan=new Scanner(System.in);
	  ForEach obj= new ForEach();
	  int intArray[]=new int[10];
	  for(int i=0;i<intArray.length;i++){
		  intArray[i]=(int)(Math.random()*100-1);
	  }
	  obj.printArray(intArray);
	  System.out.print("Give me a number:");
	  int a = scan.nextInt();
	  if(obj.search(a, intArray)==true){
		  System.out.println("The number was found");
	  }else{
		  System.out.println("The number was not found");
	  }
	  obj.FindLargestInt(intArray);
	  String strArray[]={"dog", "bird", "cat", "bear", "cow"};
	  obj.printArray(strArray);
	System.out.print("Give me an Animal name:");
	  String b=scan.next();
	  if(obj.search(b, strArray)==true){
		    System.out.println("The animal was found");
		}else{
		    System.out.println("The animal was not found");
	    }
  }
}