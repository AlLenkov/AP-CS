public class ForEach{
	public void printArray(int[]a){
		for(int each: a){
			System.out.println(each);
		}
	}
	public void printArray(String[]a){
		for(String each: a){
			System.out.println(each);
		}
	}
	public boolean search(int b, int[]a){
		for(int each: a){
			if(each==b){
				return true;
			}
		}
		return false;
	}
	public boolean search(String b, String[]a){
		for(String each: a){
			if(each.equals(b)){
				return true;
			}
		}
		return false;
	}
	public int FindLargestInt(int[]a){
		int largest=a[0];
		for(int each: a){
			if(each>largest){
				largest=each;
			}
		}
		return largest;
	}
} 
    

