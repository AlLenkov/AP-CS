
import java.util.Scanner;
class Runner {
  public static void main(String[] args) {
	  Scanner scan= new Scanner(System.in);
	  Item[] myItems = new Item[10];
	  myItems[0]= new Item("book", 9.99);
	  myItems[1] =new Item("cereal", 5.00);
	  myItems[2] =new Item("soda", 2.50);
	  myItems[3] =new Item("chips", 3.25);
	  myItems[4] =new Item("hoodie", 25.00);
	  myItems[5] =new Item("salsa", 2.00);
	  myItems[6] =new Item("chromebook", 200.00);
	  myItems[7] =new Item("bread", 5.00);
	  myItems[8] =new Item("steak", 25.00);
	  myItems[9] =new Item("cookie", 5.00);
	  int a=0;
	  while (a!=4){
		  System.out.print("1.Print all Items  \n2.Find Items by price  \n3.Find Items by name  \n4.Quit");
		    a=scan.nextInt();
	  	switch (a){
		  case 1:
			for(int i=0; i< myItems.length;i++){
				System.out.println(myItems[i].toString());
			}
				break;
		  case 2:
			System.out.print("Price: ");
			  int userinput=scan.nextInt();
			  for( int i=0;i<myItems.length;i++ ){
				  if(userinput == myItems[i].getPrice() ){
					System.out.println(myItems[i].toString());
			  }
			  }
			  break;
		  case 3:
			  System.out.print("Name: ");
			    String userinput2=scan.next();
			    for( int i=0;i<myItems.length;i++ ){
				    if( userinput2.equals( myItems[i].getName())){
					  System.out.println(myItems[i].toString());
			    }
			    }
			  break;
		  case 4:
			  break;
		  default:
			  System.out.println("That is not a valid entry, try again");
				break;
	  }
}
}
}