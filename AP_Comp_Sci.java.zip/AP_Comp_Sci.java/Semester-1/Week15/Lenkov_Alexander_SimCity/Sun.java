
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;
import java.util.Random;

// This code will move a rectangle across the screen, left to right
public class Sun extends JPanel {

	// Instance variables
	double sunx = 0;
	int suny = 299;
	int step = 1;

	// Constructor
	public Sun() {

	}

	// Set the dimension of the JPanel
	@Override
	public Dimension getPreferredSize() {
		// Sets the size of the panel
		return new Dimension(800, 600);
	}

	// Call methods that will draw on the JPanel
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		drawsun(g);

	}

	public void drawsun(Graphics g) {
		// instantiate colors
		Color colorSky = new Color(9, 113, 224);
		// set color depending where the sun is
		if (sunx > 800) {
			colorSky = new Color(9, 113, 224);
		} else {
			colorSky = new Color(173, 215, 230);
		}
		// set color and make a shape(s)
		g.setColor(colorSky);
		g.fillRect(0, 0, 800, 450);
		// set color and make a shape(s)
		Color colorYellow = new Color(255, 255, 10);
		g.setColor(colorYellow);
		g.fillOval((int) sunx, suny, 40, 40);
	}

	public void animate() {
		/*
		 * if the sun is about to fall off the top
		 * of the screen, reset y to a place where we cant see .
		 */

		// if (suny < 10) {
		// if(suny>300){
		// suny++;
		// }
		// } else {
		// suny--; // Move the sun one up(inverse grid)
		// System.out.println("greater than 10");
		// }

		if (suny == 299) {
			step = -1;
		}
		if (suny == 11) {
			step = 1;
		}
		suny += step;

		if (sunx >= 1600) {
			sunx = 0;
		} else {
			System.out.println(sunx);
			sunx += 1.35;
		}
	}

}
