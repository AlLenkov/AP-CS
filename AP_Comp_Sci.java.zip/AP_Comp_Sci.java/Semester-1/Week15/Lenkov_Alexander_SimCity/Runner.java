import javax.swing.JFrame;


public class Runner {
	//pvsm
    public static void main(String[] args) {

	//Create the frame.
	JFrame frame = new JFrame("Farm");

	//Create jpanel and add it to the frame
	SimCity objCity = new SimCity();
	frame.add(objCity);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Sun canvas = new Sun();


	//Fit the preferred size its subcomponents.
	frame.pack();

	//Show it.
	frame.setVisible(true);
	objCity.animate();


    }
}