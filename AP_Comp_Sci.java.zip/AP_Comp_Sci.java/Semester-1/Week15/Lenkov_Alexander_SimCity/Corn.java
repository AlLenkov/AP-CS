import java.awt.Graphics;
import java.awt.Color;

public class Corn {

	public void drawcorn(Graphics g, int recx, int recy) {
		// instantiate colors
		Color colorYellow = new Color(245, 207, 39);
		Color colorGreen = new Color(12, 173, 77);
		// set color and make a shape(s)
		g.setColor(colorYellow);
		g.fillOval(recx, recy+2, 10, 20);
		// set color and make a shape(s)
		g.setColor(colorGreen);
		g.fillOval(recx + 7, recy + 12, 7, 10);
		g.fillOval(recx - 5, recy + 12, 7, 10);
		g.fillOval(recx - 3, recy + 16, 7, 10);
		g.fillOval(recx + 5, recy + 16, 7, 10);
		g.fillOval(recx - 1, recy + 20, 7, 10);
		g.fillOval(recx + 3, recy + 20, 7, 10);

	}
}