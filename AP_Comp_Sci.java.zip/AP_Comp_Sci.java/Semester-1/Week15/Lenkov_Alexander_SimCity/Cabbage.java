import java.awt.Graphics;
import java.awt.Color;

public class Cabbage {

	public void drawcabbage(Graphics g, int ovalx, int ovaly) {
		// instantiate colors
		Color colorGreen = new Color(12, 173, 77);
		Color colorGreen2 = new Color(0, 102, 7);
		// set color and make a shape(s)
		g.setColor(colorGreen2);
		g.fillOval(ovalx+5, ovaly+5, 20, 20);
		g.fillOval(ovalx-5, ovaly+5, 20, 20);
		// set color and make a shape(s)
		g.setColor(colorGreen);
		g.fillOval(ovalx, ovaly, 20, 20);

	}

}