import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;


public class SimCity extends JPanel {
	Carrot carrot = new Carrot();
	Corn corn = new Corn();
	Cabbage cabbage = new Cabbage();
	Sun sun = new Sun();

	public Dimension getPreferredSize() {
		return new Dimension(800, 600);
	}

	// Create grass and sky
	public void drawGround(Graphics g, int gx, int gy) {

		Color green = new Color(0, 61, 0);

		g.setColor(green);
		g.fillRect(gx, gy, 800, 400);
	}

	public void paintComponent(Graphics g) {

		super.paintComponent(g);

		sun.drawsun(g);

		// draw the background

		drawGround(g, 0, 300);
		g.setColor(Color.black);
		g.fillRect(170, 300,10, 400);
		g.fillRect(490, 300,10, 400);
							/*** CARROT ***/
		// Change For (x, y)Pos-->(Next 2 Lines)
		int startX1 = 20;
		int startY1 = 320;
		for (int row1 = 0; row1 <= 6; row1++) {
			for (int columns1 = 0; columns1 <= 4; columns1++) {
				int x1 = columns1 * 30/* <--distance */ + startX1; // col
				int y1 = row1 * 40/* <--distance */ + startY1; // row
				// draws plant with variables inputed in (x(num), y(num))
				carrot.drawcarrot(g, x1, y1);

			}
		}
							/*** CORN ***/
		// Change For (x, y)Pos-->(Next 2 Lines)
		int startX2 = 200;
		int startY2 = 335;
		for (int row2 = 0; row2 <= 3; row2++) {
			for (int columns2 = 0; columns2 <= 4; columns2++) {
				int x2 = columns2 * 65/* <--distance */ + startX2; // col
				int y2 = row2 * 60/* <--distance */ + startY2; // row
				// Change For (x, y)Pos-->(Next 2 Lines)
				corn.drawcorn(g, x2, y2);

			}
		}
								/*** CABBAGE ***/
		// Change For (x, y)Pos-->(Next 2 Lines)
		int startX = 520;
		int startY = 320;
		for (int row = 0; row <= 7; row++) {
			for (int columns = 0; columns <= 7; columns++) {
				int x = columns * 35/* <--distance */ + startX; // col
				int y = row * 35/* <--distance */ + startY; // row
				// Change For (x, y)Pos-->(Next 2 Lines)
				cabbage.drawcabbage(g, x, y);

			}
		}

	}

	// makes it possible for animation to happen.
	public void animate() {
		// always running
		while (true) {
			// wait for .01 second(10mills)
			try {
				Thread.sleep(10);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}

			// method for animating sun
			sun.animate();

			// Repaint the graphics drawn.
			repaint();
		}


	}

}