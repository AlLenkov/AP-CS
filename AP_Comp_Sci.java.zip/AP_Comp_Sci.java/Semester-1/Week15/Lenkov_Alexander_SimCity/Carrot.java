import java.awt.Graphics;
import java.awt.Color;

public class Carrot {

	public void drawcarrot(Graphics g, int recx, int recy) {
		// instantiate colors
		Color colorOrange = new Color(247, 137, 10);
		Color colorGreen = new Color(14, 169, 82);

		// set color and make a shape(s)
		g.setColor(colorOrange);
		g.fillOval(recx, recy, 10, 20);

		// set color and make a shape(s)
		g.setColor(colorGreen);
		g.fillRect(recx + 3, recy - 5, 5, 10);
		g.fillRect(recx, recy, 10, 7);
	}
}