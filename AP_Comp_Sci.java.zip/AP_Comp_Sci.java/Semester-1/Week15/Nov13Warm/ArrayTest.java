public class ArrayTest {

    private int[] numArr;

    public ArrayTest(int len){
        numArr = new int [len];
        for(int i=0; i<len; i++){
            numArr[i] = (int)(Math.random()*5 + 1);
        }
    }

    public void print(){
        for(int index=0; index<numArr.length; index++){
            System.out.print(numArr[index]+" ");   	
       }
       System.out.println(" ");
       
    }

    public int getSum(){
    int total = 0;
        for(int i=0; i<numArr.length; i++){
            total += numArr[i];

        }
    return total;
    }
}
