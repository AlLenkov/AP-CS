public class Runner {
    public static void main(String[] args) {
        ArrayTest obj= new ArrayTest(5);
        obj.print();
        int b=obj.getSum();
        System.out.print(b);

    }
}
