import java.awt.Color;
import java.awt.Graphics;

public class Enemy {
    // pos and dimentions of enemy
    private int x, y, width, height;
    // realx is double version of x that can be smaller thatn one
    // speed is starting speed
    private double realx, speed;
    // size gets passed in; determines if it is boss or regular
    private String size;
    // visible makes killed enemys disapear
    // bossspawned determines if boss is spawned
    private boolean visible, bossspawned;
    // used for levels and amount of enemies dead
    int livesdown;
    // size diff for boss
    private int mult;

    // Constructor
    public Enemy(int x, int y, String size) {
        this.size = size;
        int scoredown = 1;
        this.x = x;
        this.y = y;
        realx = x;
        visible = true;
        width = 30;
        height = 30;
        speed = .4;
        mult = 2;
        bossspawned = false;

    }

    // draw enemy
    public void draw(Graphics g) {
        if (visible) {
            if (size == "small") {
                g.setColor(Color.BLUE);
                g.fillOval(x, y, width, height);
                g.setColor(Color.GRAY);
                g.fillRoundRect(x - 5, y + 15, 40, 15, 10, 10);
            }
            if (size == "big") {
                g.setColor(Color.RED);
                g.fillOval(x, y, width * mult, height * mult);
                g.setColor(Color.GRAY);
                g.fillRoundRect(x - 5 * mult, y + 15 * mult, 40 * mult, 15 * mult, 10 * mult, 10 * mult);
            }
        }
    }

    // returns X
    public int getX() {
        return x;
    }

    // returns y
    public int getY() {
        return y;
    }

    // returns width
    public int getWidth() {
        if (size == "small") {
            return width;
        } else {
            return (width * mult);
        }
    }

    // returns height
    public int getHeight() {
        if (size == "small") {
            return height;
        } else {
            return (height * mult);
        }
    }

    // returns size
    public String size() {
        return size;
    }

    // returns visible
    public boolean getVisible() {
        return visible;
    }




    // makes enemy invisible
    public void disapear() {
        visible = false;
    }

    // makes enemies faster
    public void faster() {
        speed += .2;
    }

     // changes bossspawned to true
    public void bossspawned() {
        bossspawned = true;
    }

    // resets all variables if killed
    public void fullreset() {
        bossspawned = false;
        speed = .33;
        visible = true;
    }

    // moves enemies back
    public void livesdown() {
        if (realx < 900) {
            realx = Math.random() * 300 + 700;
        }
    }



    // restarts enemies if they are small or if boss has been spawned
    public void restart() {
        if (bossspawned == true || size == "small") {
            visible = true;
            realx = (int) (Math.random() * 100 + 800);
            y = (int) (Math.random() * 600);
        }
    }

    // moves enemies left and up and down randomly
    public void moveLeftE() {

        realx -= speed;
        x = (int) Math.round(realx);
        if (y > 20) {
            if (y < 580) {
                int random = (int) (Math.random() * 3);
                switch (random) {
                    case 0:
                        y -= 2;
                        break;
                    case 1:
                        y += 2;
                        break;
                    default:
                        y += 0;
                }
            } else {
                y -= 10;
            }

        } else {
            y += 10;
        }

    }
}
