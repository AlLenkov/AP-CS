import java.awt.Color;
import java.awt.Graphics;

// Code that implements a projectile
public class Projectile {

    // Instance variables
        private int x, y;
        private int width, height;
        private Color red;

    // Constructor
    public Projectile(int x, int y) {
        this.x = x+200;
        this.y = y;

        this.width = 40;
        this.height = 5;

        this.red = new Color(255, 0, 0);
    }
    
    public void draw (Graphics g){
        g.setColor(red);
        g.fillOval(x,y-2,width,height);
    }

    //move proectile up
    public void moveUp(){
        y-=10;
    }

    //move proectile down
    public void moveDown(){
        y+=10;
    }
//move to right
    public void move(){
        x+=30;
    }
//reset
    public void reset(int x, int y){
        this.x = x;
        this.y = y;
    }
//return Y
    public int getY(){
        return y;
    }
//return X
    public int getX(){
        return x;
    }
//return Width
    public int getWidth(){
        return width;
    }
//return Height
    public int getHeight(){
        return height;
    }
}