import java.awt.Color;
import java.awt.Graphics;

// This class makes a illusion of a moving spaceship by moving the background back
public class Background {
	// astroid x and y
	private int x, y;
	// star and red astroids x and y
	private int x2, y2;
	private Color spaceBlue, red;

	// starts astroids
	private boolean level2;
	// makes some stars into red planets
	private boolean star;

	// Constructor
	public Background() {
		level2 = false;
		x = (int) (Math.random() * 999);
		y = (int) (Math.random() * 999);
		x2 = (int) (Math.random() * 999);
		y2 = (int) (Math.random() * 999);
		spaceBlue = new Color(24, 48, 120);
		red = new Color(144, 0, 0);
		star = true;
	}

	// draws bluebackground
	public void background(Graphics g) {
		g.setColor(spaceBlue);
		g.fillRect(0, 0, 800, 600);
	}

	// draws astroid at x and y
	public void drawAstroid(Graphics g) {

		g.setColor(Color.darkGray);
		g.fillOval(x, y, 30, 30);
	}

	// draws star or red planet at x2 and y2
	public void drawStar(Graphics g) {
		if (level2) {
			if (star) {
				g.setColor(Color.white);
				g.fillOval(x2, y2, 7, 7);
			} else {
				g.setColor(red);
				g.fillOval(x2, y2, 14, 14);
			}

		}

	}

	// changes is star is visible
	public void level2() {
		level2 = true;
	}

	// stops stars incase of reset
	public void stopstars() {
		level2 = false;
	}

	// makes some stars into red plannets
	public void level3() {
		star = false;
	}

	// stops red stars
	public void stopredstars() {
		star = true;
	}

	// moves x and y left and resets them
	public void moveLeft() {
		x--;

		if (x < -5) {
			x = 800;
			y = (int) (Math.random() * 599);
		}

	}

	// moves x2 and y2 left and resets them
	public void moveLeft2() {
		if (star) {
			x2 -= 30;
		} else {
			x2 -= 10;
		}

		if (x2 < -5) {
			x2 = 800;
			y2 = (int) (Math.random() * 599);
		}

	}

}
