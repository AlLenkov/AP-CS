import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
// import KeyListener classes
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

public class GamePanel extends JPanel implements KeyListener {

	// ship
	private Ship ship;

	// array of enemies
	private Enemy[] enemies;

	// fonts
	private Font font, fontend;

	// color of text
	private Color textColor;

	// background obj
	private Background bObj;
	// background array
	private Background[] back;
	private Background[] back2;

	// prup ==> propulsion for ship(fire)
	private int prup, prup2, score, lifes;
	// endgame bool
	private boolean gameover;
	//level
	private int level;
	// Constructor

	public GamePanel() {

		gameover = false;
		bObj = new Background();
		// instantiate ship
		ship = new Ship(50, 300);
		// instantiate enemies
		enemies = new Enemy[7];
		enemies[0] = new Enemy(1000, 50, "small");
		enemies[1] = new Enemy(960, 250, "small");
		enemies[2] = new Enemy(900, 450, "small");
		enemies[3] = new Enemy(100000, 50, "small");
		enemies[4] = new Enemy(100000, 250, "small");
		enemies[5] = new Enemy(100000, 450, "small");
		enemies[6] = new Enemy(100000, 450, "big");

		setFocusable(true);
		// makes obj array
		back = new Background[20];
		back2 = new Background[30];
		for (int i = 0; i < back.length; i++) {
			back[i] = new Background();
		}
		for (int i = 0; i < back2.length; i++) {
			back2[i] = new Background();
		}

		// instance var
		font = new Font("Arial", Font.PLAIN, 25);
		fontend = new Font("Arial", Font.PLAIN, 80);
		textColor = new Color(255, 255, 255);
		score = 0;
		lifes = 3;
		level = 1;
		// set up listening to key clicks
		addKeyListener(this);


	}

	@Override
	public Dimension getPreferredSize() {
		// Sets the size of the panel
		return new Dimension(800, 600);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		// draw background
		bObj.background(g);

		// draw astroids and stars
		for (Background each : back2) {
			each.drawStar(g);
		}
		for (Background each : back) {
			each.drawAstroid(g);
		}

		for (Enemy each : enemies) {
			each.draw(g);
		}

		// draw ship
		ship.draw(g, prup, prup2);
		g.setFont(font);
		g.setColor(textColor);
		// draws score and lives text
		g.drawString("Score: " + score, 0, 20);
		g.drawString("Level: " + level, 700, 20);
		g.drawString("Lives: " + lifes, 0, 45);

		// makes game over screen
		if (gameover) {
			g.setColor(Color.BLACK);
			g.clearRect(0, 0, 1000, 1000);
			g.setFont(fontend);
			g.drawString("Game over", 200, 300);
		}
	}

	public void keyPressed(KeyEvent e) {

		if (e.getKeyCode() == 38) { // up arrow pressed == 38
			ship.moveUp();
		}

		if (e.getKeyCode() == 40) { // down arrow pressed == 40
			ship.moveDown();
		}
		if (e.getKeyCode() == 32) { // space pressed == 32
			ship.fire();
		}

		// skip level code (next 3 blocks of code)
		if (ship.enemiesdied() >= 20) {
			if (e.getKeyCode() == 79) { // o pressed == 79
				gameover = true;
			}
		}

		if (ship.enemiesdied() <= 16 && ship.enemiesdied() >= 10) {
			if (e.getKeyCode() == 79) { // o pressed == 79

				for (int i = 0; i < 20; i++) {
					back2[i].level3();

				}
				for (Enemy each : enemies) {
					each.bossspawned();
					each.restart();
					each.faster();
					ship.level3();
					level = 3;
				}
			}
		}

		if (ship.enemiesdied() <= 6) {
			if (e.getKeyCode() == 79) { // space pressed == 79
				for (Enemy each : enemies) {
					each.restart();
					each.faster();
					ship.level2();
					level = 2;
				}

			}
		}
	}

	// Run continuously to simulate animation
	public void animate() {
		// simulate propulsion
		while (true) {
			if (prup == 0) {
				prup = 30;
			} else {
				prup -= 5;
			}
			if (prup2 == 0) {
				prup2 = 30;
			} else {
				prup2 -= 5;
			}

			// wait for .01 second
			try {
				Thread.sleep(10);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}

			// check for collision
			for (Enemy each : enemies) {
				if (ship.checkProjectileCollision(each)) {
					score++;
					break;
				}
			}

			for (Enemy each : enemies) {
				if (ship.enemyshipcollision(each)) {
					lifes--;
					ship.lifedown();
					for (Enemy each1 : enemies) {
						each1.livesdown();
					}
					break;
				}

			}

			for (Enemy each : enemies) {
				if (each.getX() < 20) {
					lifes--;
					for (Enemy each1 : enemies) {
						each1.livesdown();
					}
					ship.lifedown();
					break;
				}
			}

			// gameover if win
			if (ship.enemiesdied >= 29) {

				gameover = true;
			}
			// sets new background
			if (ship.enemiesdied >= 10) {
				for (Background each : back2) {
					each.level2();
				}
			}
			// reset if dead
			if (lifes <= 0) {
				lifes = 3;
				ship.level1();
				level = 1;
				score = 0;
				for (Enemy each : enemies) {
					each.fullreset();
				}
				for (Background each : back2) {
					each.stopstars();
					each.stopredstars();
				}
				enemies[3].disapear();
				enemies[4].disapear();
				enemies[5].disapear();
				enemies[6].disapear();
			}
			// moves projectile
			ship.moveProjectile(800);

			// moves background
			for (int i = 0; i < 20; i++) {
				back[i].moveLeft();
			}

			for (int i = 0; i < 30; i++) {
				back2[i].moveLeft2();
			}
			// level 2 reset
			if (ship.enemiesdied == 3) {
				for (Enemy each : enemies) {
					each.restart();
					each.faster();
					ship.level2();
					level = 2;
				}
			}
			// level 3 reset
			if (ship.enemiesdied == 16) {
				for (int i = 0; i < 20; i++) {
					back2[i].level3();
					level = 3;
				}
				for (Enemy each : enemies) {
					each.bossspawned();
					each.restart();
					each.faster();
					ship.level3();
					level = 3;
				}

			}

			// repaint the graphics
			repaint();
		}

	}

	// You must have method signatures for all methods that are
	// part of an interface.
	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

}
