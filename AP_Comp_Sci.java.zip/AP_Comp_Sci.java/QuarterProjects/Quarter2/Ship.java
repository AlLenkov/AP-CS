import java.awt.Color;
import java.awt.Graphics;

public class Ship {

	// x and y for ship
	private int x, y;
	public int enemiesdied;
	// grey light and dark
	private Color greyl, greyd;
	// Projectile Obj
	private Projectile pObj;
	// determines if firing
	private boolean fire;
	// amount of lifes boss has
	private int bosslives;

	/// Constructer
	public Ship(int x, int y) {
		this.x = x;
		this.y = y;
		enemiesdied = 0;

		pObj = new Projectile(x, y);
		greyl = new Color(78, 78, 78);
		greyd = new Color(30, 30, 30);

		bosslives = 3;
	}

	// draws ship
	public void draw(Graphics g, int prup, int prup2) {
		// check if projectile needs to be drawn
		if (fire) {
			pObj.draw(g);
		}

		// blaster
		g.setColor(greyd);
		g.fillRect(x, y - 5, 215, 10);
		// ship outline
		g.setColor(greyl);
		int[] xpoints = { x - 40, x - 35, x - 35, x - 20, x + 60, x + 80, x + 100, x + 140, x + 150, x + 200, x + 150,
				x + 140, x + 100, x + 80, x + 60, x - 20, x - 35, x - 35 };
		int[] ypoints = { y, y - 5, y - 60, y - 80, y - 20, y - 40, y - 20, y - 20, y - 30, y, y + 30, y + 20, y + 20,
				y + 40, y + 20, y + 80, y + 60, y + 5 };
		g.fillPolygon(xpoints, ypoints, 18);
		// windsheild
		g.setColor(Color.BLACK);
		g.fillOval(x + 80, y - 15, 100, 30);
		g.setColor(greyl);
		g.fillRect(x + 80, y - 15, 70, 30);
		g.setColor(Color.BLACK);
		g.fillOval(x + 132, y - 14, 30, 28);
		// fire
		g.setColor(Color.RED);
		g.fillOval(prup, y - 15, 30, 30);

		g.setColor(Color.ORANGE);
		g.fillOval(prup2 + 20, y - 10, 20, 20);
		// rocket
		g.setColor(greyd);
		g.fillOval(x - 10, y - 15, 100, 30);
		g.fillRect(x - 10, y - 15, 50, 30);

	}

	public void moveUp() {// moves ship up when called
		y -= 10;
		if (!fire) {
			pObj.moveUp();
		}
	}

	public void moveDown() {// moves ship down when called
		y += 10;
		if (!fire) {
			pObj.moveDown();
		}
	}

	// moves projectile when fire is true
	public void moveProjectile(int limit) {
		if (fire) {
			pObj.move();
		}
		// if the projectile went to the end of the JPanel
		if (pObj.getX() > (limit)) {
			pObj.reset(x, y);
			fire = false;
		}
	}

	// Check to see if the projectile has hit an enemy
	public boolean checkProjectileCollision(Enemy eObj) {

		if (eObj.getVisible()) { // checkCollision only when the enemy is visible
			eObj.moveLeftE();
			//info for calculating hitboxes relative to (0,0)
			int pX = pObj.getX();
			int pY = pObj.getY();
			int pWidth = pObj.getWidth();
			int pHeight = pObj.getHeight();

			int eX = eObj.getX();
			int eY = eObj.getY();
			int eWidth = eObj.getWidth();
			int eHeight = eObj.getHeight();
			//chech if hitboxes touch using dimentions of projectile and enemy reletive to 0,0
			if (pX + pWidth >= eX && pX <= eX + eWidth &&
					pY + pHeight >= eY && pY <= eY + eHeight) {
				enemiesdied++;

				pObj.reset(x, y);
				if (eObj.size().equals("small")) {
					eObj.disapear();
					return true;

				}
				if (eObj.size().equals("big")) {
					bosslives--;
				}
				if (bosslives <= 0) {
					eObj.disapear();
					return true;
				}

			}

		}
		return false;
	}

	// checks for a enemy and ship collision using 2 hitboxes
	public boolean enemyshipcollision(Enemy eObj) {

		if (eObj.getVisible()) { // checkCollision only when the enemy is visible
			eObj.moveLeftE();
			//info for calculating hitboxes relative to (0,0)
			int sX = x;
			int sY = y - 20;
			int sWidth = 200;
			int sHeight = 40;

			int sX2 = x - 80;
			int sY2 = y;
			int sWidth2 = 50;
			int sHeight2 = 160;

			int eX = eObj.getX();
			int eY = eObj.getY();
			int eWidth = eObj.getWidth();
			int eHeight = eObj.getHeight();
			//chech if hitboxes touch using dimentions of ship and enemy reletive to 0,0
			//checks using 2 hit boxes
			if (sX + sWidth >= eX && sX <= eX + eWidth &&
					sY + sHeight >= eY && sY <= eY + eHeight
					|| sX2 + sWidth2 >= eX && sX2 <= eX + eWidth &&
							sY2 + sHeight2 >= eY && sY2 <= eY + eHeight) {
				//depending on size changes way it subtracts points
				//
				if (eObj.size() == "small") {
					return true;
				}
				if (eObj.size() == "big") {
					bosslives--;
				}
				if (bosslives == 0) {
					return true;
				}
			}

		}
		return false;
	}

	// fires projectile when called
	public void fire() {
		fire = true;
	}

	// returns enemies dead
	public int enemiesdied() {
		return enemiesdied;
	}

	// enemies dead is used to indicate levels in order to spare another variable
	// hence, we change amount of enemies dead on each level and can determin what-
	// level we are on by enemies dead variable
	public void level1() {
		enemiesdied = 0;
	}

	// check above
	public void level2() {
		enemiesdied = 10;
	}

	// check above
	public void level3() {
		enemiesdied = 20;
		bosslives = 3;
	}

	// restarts ship when it loses a life
	public void lifedown() {
		y = 300;
	}

}
