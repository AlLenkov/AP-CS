import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;
import java.util.Random;

public class Scenery extends JPanel {

	private String season, time;

	public Scenery(String season, String time) {
		int x, y;
		this.season=season;
		this.time = time;
	}

	@Override
	public Dimension getPreferredSize() {
		// Sets the size of the panel
		return new Dimension(800, 600);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		// Create a method for each item that you draw
		daytime(g, time, season);

		TreeGen(g, season);

		//draws all objects
		flower(g, season, 300, 500);
		flower(g, season, 200, 540);
		House(g, season, 500, 400);
		dog(g, 200, 400);
		snake(g, 300, 400);

	}

	private void grass(Graphics g, String time, String season) {

		this.season = season;
		this.time = time;
		//sets colors
		Color colorGreen = new Color(0, 0, 0);
		Color colorWhite = new Color(255, 255, 255);
		Color colorBrown = new Color(102, 51, 0);
		//changes on season or day
		if (time.equals("day")) {
			colorGreen = new Color(20, 98, 30);
		} else if (time.equals("night")) {
			colorGreen = new Color(20, 98, 30);
		}
		for (int i = 200; i < 600; i++) {
			//changes on season or day
			for (int ii = 0; ii < 800; ii = ii + ((int) Math.round(Math.random() * 25))) {
				if (season.equals("spring")) {
					g.setColor(colorGreen);
				}
				if (season.equals("fall")) {
					g.setColor(colorBrown);
				}
				if (season.equals("winter")) {
					g.setColor(colorWhite);
				}
				//draws object(s)
				g.fillOval(ii, i, 4, 6);
			}
		}
	}

	private void TreeGen(Graphics g, String season) {

		this.season = season;
		int treex = 0;
		int treey = 0;
		int numCoordinates = 5;
		 // Number of trees to generate
		Random Random = new Random();
		// Generate and print 20 random coordinates
		for (int i = 0; i < numCoordinates; i++) {
			treex = Random.nextInt(800);
			treey = Random.nextInt(200);


			drawTree(g, treex, treey + 200, season);
		}
	}

	private void daytime(Graphics g, String time, String season) {
		this.time = time;
				//changes on season or day
		if (time.equals("day")) {
			//sets colors
			Color colorBrown = new Color(179, 132, 85);
			Color colorBlue = new Color(155, 229, 255);
			//draws object(s)
			g.setColor(colorBlue);
			g.fillRect(0, 0, 800, 200);
			g.setColor(colorBrown);
			g.fillRect(0, 200, 800, 400);
			grass(g, "day", season);
		} else if (time.equals("night")) {
			//sets colors
			Color colorBrown = new Color(149, 102, 55);
			Color colorBlue = new Color(7, 70, 92);
			//draws object(s)
			g.setColor(colorBlue);
			g.fillRect(0, 0, 800, 200);
			g.setColor(colorBrown);
			g.fillRect(0, 200, 800, 400);
			grass(g, "night", season);
		}

	}

	private void drawTree(Graphics g, int x, int y, String season) {
				//changes on season or day
		if (season.equals("spring")) {
			//sets colors
			Color colorBrown = new Color(100, 42, 42);
			Color colorGreen = new Color(0, 128, 0);
			Color colorDGreen = new Color(0, 70, 0);
			
					//draws object(s)
			g.setColor(colorBrown);
			g.fillRect(x, y, 30, 100);
			g.setColor(colorDGreen);
			g.fillOval(x - 40, y - 55, 110, 110);
			g.setColor(colorGreen);
			g.fillOval(x - 35, y - 50, 100, 100);
		} else if (season.equals("winter")) {
			//sets colors
			Color colorBrown = new Color(100, 42, 42);
			Color colorGreen = new Color(0, 128, 0);
					//draws object(s)
			g.setColor(colorBrown);
			g.fillRect(x, y, 30, 100);
		} else if (season.equals("fall")) {
					//sets colors
			Color colorOrange = new Color(255, 165, 1);
			Color colorBrown = new Color(100, 42, 42);
					//draws object(s)
			g.setColor(colorBrown);
			g.fillRect(x, y, 30, 100);
			g.setColor(colorOrange);
			g.fillOval(x - 35, y - 50, 100, 100);
		}
	}

	private void flower(Graphics g, String season, int x, int y) {
		this.season = season;
		//changes on season or day
		if (season.equals("spring")) {
					//sets colors
			Color colorRed = new Color(200, 0, 0);
			Color colorGreen = new Color(1, 50, 1);
			Color colorYellow = new Color(255, 255, 10);
					//draws object(s)
			g.setColor(colorGreen);
			g.fillRect(x, y, 10, 30);
			g.setColor(colorRed);
			g.fillOval(x - 5, y - 5, 20, 20);
			g.setColor(colorYellow);
			g.fillOval(x, y, 10, 10);
		} else if (season.equals("winter")) {
					//sets colors
			Color colorGreen = new Color(20, 98, 30);
					//draws object(s)
			g.setColor(colorGreen);
			g.fillRect(x, y, 10, 30);
		}

	}

	private void House(Graphics g, String season, int x, int y) {
		this.season = season;
				//sets colors
		Color colorRed = new Color(158, 46, 46);
		Color colorBlue = new Color(150, 225, 228);
		Color colorRoof = new Color(0, 0, 0);
				//changes on season or day
		if (season.equals("spring")) {

			colorRoof = new Color(128, 0, 0);

		} else if (season.equals("winter")) {
			colorRoof = new Color(255, 255, 255);

		} else if (season.equals("fall")) {
			colorRoof = new Color(215, 143, 30);
		}
				//draws object(s)
		g.setColor(colorRed);
		g.fillRect(x, y, 200, 150);
		g.setColor(colorBlue);
		g.fillRect(x + 75, y + 25, 50, 50);
		g.setColor(colorRoof);
		// g.fillRect(x, y-30, 200, 30);
		int[] xpoints = { (x), (x + 200), (x + 100) };
		int[] ypoints = { (y), (y), (y - 30) };
		int npoints = 3;
		g.fillPolygon(xpoints, ypoints, npoints);
		// body

	}

	public void dog(Graphics g, int x, int y) {
		//sets colors
		Color colorBrown = new Color(73, 52, 12);
		g.setColor(colorBrown);
				//draws object(s)
		int[] xPoints = { x + 2, x + 2, x + 13, x + 23, x + 31, x + 71, x + 88, x + 100, x + 107, x + 115, x + 116,
				x + 111, x + 104, x + 96, x + 90, x + 88, x + 85, x + 83, x + 83, x + 87, x + 79, x + 75, x + 74,
				x + 72, x + 72, x + 73, x + 67, x + 63, x + 64, x + 65, x + 65, x + 55, x + 45, x + 40, x + 36, x + 24,
				x + 29, x + 19, x + 19, x + 14, x + 14, x + 7, x + 8, x + 22, x + 5 };
		int[] yPoints = { y + 59, y + 53, y + 48, y + 28, y + 21, y + 20, y + 4, y + 2, y + 7, y + 8, y + 14, y + 19,
				y + 19, y + 24, y + 31, y + 40, y + 48, y + 56, y + 67, y + 76, y + 77, y + 71, y + 57, y + 64, y + 71,
				y + 77, y + 77, y + 71, y + 63, y + 55, y + 50, y + 50, y + 47, y + 44, y + 58, y + 71, y + 75, y + 77,
				y + 67, y + 72, y + 76, y + 77, y + 65, y + 50, y + 60 };
		int npoints = 45;
		g.fillPolygon(xPoints, yPoints, npoints);
		g.setColor(Color.WHITE);
		g.fillOval(x + 93, y + 3, 7, 7);
		g.setColor(Color.BLACK);
		g.fillOval(x + 95, y + 5, 3, 3);

	}

	public void snake(Graphics g, int x, int y) {
				//sets colors
		Color colorBrown = new Color(100, 73, 19);

		g.setColor(colorBrown);
		//draws object(s)
		int[] xPoints = { x + 141, x + 151, x + 161, x + 152, x + 134, x + 117, x + 89, x + 66, x + 53, x + 58, x + 76,
				x + 109, x + 162, x + 186, x + 191, x + 195, x + 195, x + 190, x + 187, x + 190, x + 184, x + 181,
				x + 175, x + 172, x + 166, x + 162, x + 162, x + 155, x + 154, x + 156, x + 161, x + 169, x + 172,
				x + 172, x + 148, x + 132, x + 116, x + 100, x + 93, x + 109, x + 123, x + 134 };
		int[] yPoints = { y + 116, y + 116, y + 114, y + 104, y + 100, y + 98, y + 98, y + 99, y + 108, y + 122,
				y + 131, y + 134, y + 132, y + 121, y + 94, y + 72, y + 47, y + 33, y + 26, y + 18, y + 14, y + 14,
				y + 10, y + 15, y + 18, y + 23, y + 29, y + 38, y + 49, y + 63, y + 77, y + 93, y + 107, y + 116,
				y + 120, y + 120, y + 119, y + 116, y + 111, y + 111, y + 112, y + 113 };
		int npoints = 42;
		g.fillPolygon(xPoints, yPoints, npoints);
		g.setColor(Color.WHITE);
		g.fillOval(x + 172, y + 13, 7, 7);
		g.setColor(Color.BLACK);
		g.fillOval(x + 174, y + 15, 3, 3);
	}

}
