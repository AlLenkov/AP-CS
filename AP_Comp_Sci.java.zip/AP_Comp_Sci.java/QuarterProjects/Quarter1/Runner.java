import javax.swing.JFrame;
import java.util.Scanner;

// Runner that can be used with JPanel Graphics
public class Runner {
    public static void main(String args[]) {
        // CLASS DIAGRAM
        /*
         ***** Scenery
         * -int -- x, y
         * -string -- season, time.
         * 
         * Constructor - only one
         * +scenery()
         * 
         * methods
         * -house(int Time)
         * -grass(int Time)
         * -trees(string season)
         * -animal()
         * -animal2()
         * -flowers(string season)
         * 
         * 
         * 
         * 
         * Runner
         * 
         * initiateion of canvas
         * Running
         */

        Scanner scan = new Scanner(System.in);

        String season = "";
        while (true) {
            System.out.print("pick a season; winter, spring or fall(no caps)--> ");
            season = scan.next();
            if (season.equals("winter")) {
                break;
            }
            if (season.equals("spring")) {
                break;
            }
            if (season.equals("fall")) {
                break;
            }
            System.out.print("you didn't pick a valid option:");

        }
        String time = "";
        while (true) {
            System.out.print("pick a time; day or night (no caps)--> ");
            time = scan.next();
            if (time.equals("day")) {
                break;
            }
            if (time.equals("night")) {
                break;
            }
            System.out.print("you didn't pick a valid option:");
        }
        // Create the frame object. Give it a title appropriate to the application
        JFrame frame = new JFrame("");

        // Create the JPanel object and add it to the frame
        Scenery canvas = new Scenery(season, time);
        frame.add(canvas);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
}