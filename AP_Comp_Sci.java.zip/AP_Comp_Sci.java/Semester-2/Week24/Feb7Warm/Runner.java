import java.util.ArrayList;

public class Runner {
  public static void main(String[] args) {
    ArrayList<Student> stuObjs = new ArrayList<>();
    stuObjs.add(new Student("Henry", 34));
    stuObjs.add(new Student("Jose", 21));
    stuObjs.add(new Student("Carla", 21));
    stuObjs.add(new Student("Nancy", 19));

    for (Student each : stuObjs) {
        if (each.getAge() == 21) {
            System.out.println(each);
        }
    }
  }
}