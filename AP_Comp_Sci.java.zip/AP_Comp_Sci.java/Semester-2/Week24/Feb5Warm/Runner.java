import java.util.ArrayList;
public class Runner {
    public static void main(String[] args) {
        ArrayList<Card> cardList = new ArrayList<Card>();

        for( int i=0; i<10; i++){
	        cardList.add(new Card((int)(Math.random()*15)));
        }
        System.out.print("Array List:\n");
        for (Card each : cardList){
            System.out.println("\t"+each);
        }

        for(int i=0;i<cardList.size();i++){
            if (cardList.get(i).getValue()%2!=0){
                cardList.remove(i);
                i--;
            }
        }
        System.out.print("odd Removed:\n");
        
        for (Card each : cardList){
            System.out.println("\t"+each);
        }
    }
}
