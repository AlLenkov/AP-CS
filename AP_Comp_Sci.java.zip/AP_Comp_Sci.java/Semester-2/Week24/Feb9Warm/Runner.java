

import java.util.ArrayList;
import java.util.Random;

public class Runner {
  public static void main(String[] args) {
    ArrayListRef refListObj = new ArrayListRef();
    ArrayList<Integer> intList = new ArrayList<>();
    Random rand = new Random();
    for (int i = 0; i < 10; i++) {
      intList.add(rand.nextInt(15) + 1);
    }
    refListObj.printArray(intList);
    System.out.println("scramble: ");
    refListObj.scramble(intList);
    refListObj.printArray(intList);
  }
}

