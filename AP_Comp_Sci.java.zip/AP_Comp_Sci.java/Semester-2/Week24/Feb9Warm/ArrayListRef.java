import java.util.ArrayList;
import java.util.Random;

public class ArrayListRef {
  public void printArray(ArrayList<Integer> arr) {
    for (int num : arr) {
      System.out.print(num + " ");
    }
    System.out.println();
  }

  public void scramble(ArrayList<Integer> arr) {
    Random rand = new Random();
    int temp, j;
    for (int i = 0; i < arr.size(); i++) {
      j = rand.nextInt(arr.size());
      temp = arr.get(j);
      arr.set(j, arr.get(i));
      arr.set(i, temp);
    }
  }
}