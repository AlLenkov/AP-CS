import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Table extends JPanel implements ActionListener {
    int playertotalcardvalue = 0;
    int tiex = 1000;
    int winx = 1000;
    int hitx = 1000;
    int standx = 1000;
    int dealerbustx = 1000;
    int lossx = 1000;
    int coverx = 100;
    int dealercoverx = 1000;
    int dealercoverxx = 20;
    int bustx = 2000;
    int wins = 0;
    int loss = 0;
    Color cardback;
    Color background;

    private ArrayList<Card> deck;
    private ArrayList<Card> player;
    private ArrayList<Card> dealer;
    private JButton Hit;
    private JButton Advice;
    private JButton Stand;
    private JButton NewGame;

    public Table() {
        setLayout(null);
        deck = new ArrayList<Card>();

        deck.add(new Card(2, "2", "hearts"));
        deck.add(new Card(3, "3", "hearts"));
        deck.add(new Card(4, "4", "hearts"));
        deck.add(new Card(5, "5", "hearts"));
        deck.add(new Card(6, "6", "hearts"));
        deck.add(new Card(7, "7", "hearts"));
        deck.add(new Card(8, "8", "hearts"));
        deck.add(new Card(9, "9", "hearts"));
        deck.add(new Card(10, "10", "hearts"));
        deck.add(new Card(10, "J", "hearts"));
        deck.add(new Card(10, "Q", "hearts"));
        deck.add(new Card(10, "K", "hearts"));
        deck.add(new Card(11, "A", "hearts"));
        deck.add(new Card(2, "2", "diamonds"));
        deck.add(new Card(3, "3", "diamonds"));
        deck.add(new Card(4, "4", "diamonds"));
        deck.add(new Card(5, "5", "diamonds"));
        deck.add(new Card(6, "6", "diamonds"));
        deck.add(new Card(7, "7", "diamonds"));
        deck.add(new Card(8, "8", "diamonds"));
        deck.add(new Card(9, "9", "diamonds"));
        deck.add(new Card(10, "10", "diamonds"));
        deck.add(new Card(10, "J", "diamonds"));
        deck.add(new Card(10, "Q", "diamonds"));
        deck.add(new Card(10, "K", "diamonds"));
        deck.add(new Card(11, "A", "diamonds"));
        deck.add(new Card(2, "2", "clubs"));
        deck.add(new Card(3, "3", "clubs"));
        deck.add(new Card(4, "4", "clubs"));
        deck.add(new Card(5, "5", "clubs"));
        deck.add(new Card(6, "6", "clubs"));
        deck.add(new Card(7, "7", "clubs"));
        deck.add(new Card(8, "8", "clubs"));
        deck.add(new Card(9, "9", "clubs"));
        deck.add(new Card(10, "10", "clubs"));
        deck.add(new Card(10, "J", "clubs"));
        deck.add(new Card(10, "J", "clubs"));
        deck.add(new Card(10, "Q", "clubs"));
        deck.add(new Card(10, "K", "clubs"));
        deck.add(new Card(11, "A", "clubs"));
        deck.add(new Card(2, "2", "spades"));
        deck.add(new Card(3, "3", "spades"));
        deck.add(new Card(4, "4", "spades"));
        deck.add(new Card(5, "5", "spades"));
        deck.add(new Card(6, "6", "spades"));
        deck.add(new Card(7, "7", "spades"));
        deck.add(new Card(8, "8", "spades"));
        deck.add(new Card(9, "9", "spades"));
        deck.add(new Card(10, "10", "spades"));
        deck.add(new Card(10, "J", "spades"));
        deck.add(new Card(10, "J", "spades"));
        deck.add(new Card(10, "Q", "spades"));
        deck.add(new Card(10, "K", "spades"));
        deck.add(new Card(11, "A", "spades"));
        shuffle(deck);

        Hit = new JButton("Hit");
        Hit.setBounds(20, 70, 100, 30);
        add(Hit);
        Hit.addActionListener(this);

        Advice = new JButton("Advice");
        Advice.setBounds(20, 40, 100, 30);
        add(Advice);
        Advice.addActionListener(this);

        Stand = new JButton("Stand");
        Stand.setBounds(20, 105, 100, 30);
        add(Stand);
        Stand.addActionListener(this);

        NewGame = new JButton("New Game");
        NewGame.setBounds(400, 100, 100, 30);
        add(NewGame);
        NewGame.addActionListener(this);
        NewGame.setVisible(false);

        player = new ArrayList<Card>();
        dealer = new ArrayList<Card>();

        player.add(deck.get(0));
        deck.remove(0);
        player.add(deck.get(0));
        deck.remove(0);

        dealer.add(deck.get(0));
        deck.remove(0);
        dealer.add(deck.get(0));
        deck.remove(0);

        cardback = new Color(186, 164, 158);
        background = new Color(232, 208, 197);

    }

    public int findTotal(ArrayList<Card> player) {
        int playertotalcardvalue = 0;
        for (Card card : player) {
            playertotalcardvalue += card.getValue();
        }
        return playertotalcardvalue;
    }

    public int findDealerTotal(ArrayList<Card> dealer) {
        int dealertotalcardvalue = 0;
        for (Card card : dealer) {
            dealertotalcardvalue += card.getValue();
        }
        return dealertotalcardvalue;
    }

    public int findDealerTotalCovered(ArrayList<Card> dealer) {
        int dealertotalcardvaluecovered = 0;
        if (!dealer.isEmpty()) {
            dealertotalcardvaluecovered = dealer.get(0).getValue();
        }
        return dealertotalcardvaluecovered;
    }

    public Dimension getPreferredSize() {
        // Sets the size of the panel
        return new Dimension(800, 600);

    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(background);
        g.fillRect(0, 0, 800, 600);
        // Draw Boxes

        int x = 20;
        int xd = 20;

        int y = 400;
        int yd = 180;

        for (int i = 0; i < player.size(); i++) {
            player.get(i).drawMe(g, x, y);
            x = x + 80;

        }
        for (int i = 0; i < dealer.size(); i++) {
            dealer.get(i).drawMe(g, xd, yd);
            xd = xd + 80;
        }
        g.setColor(cardback);

        g.fillRect(coverx, 180, 120, 150);
        g.setColor(Color.WHITE);
        g.drawLine(coverx, 180, coverx + 120, 330);
        g.drawLine(coverx + 120, 180, coverx, 330);
        g.drawLine(coverx + 60, 180, coverx + 60, 330);

        int fontSize = 15;
        g.setFont(g.getFont().deriveFont((float) fontSize));
        g.setColor(Color.black);
        g.drawString("PlayerTotalCardValue: " + findTotal(player), 20, 390);
        g.drawString("DealerTotalCardValue: " + findDealerTotal(dealer), dealercoverx, 175);
        g.drawString("DealerTotalCardValue: " + findDealerTotalCovered(dealer), dealercoverxx, 175);
        // prints the dealer
        fontSize = 20;
        g.setFont(g.getFont().deriveFont((float) fontSize));
        g.drawString("You Busted! You Lost! ", bustx, 300);
        g.drawString("You Won! ", winx, 400);
        g.drawString("You Won, Dealer Busted! ", dealerbustx, 400);
        g.drawString("You Lose! ", lossx, 400);
        g.drawString("You Should Hit ", hitx, 380);
        g.drawString("You Should Stand ", standx, 380);
        g.drawString("You Tied with the Dealer, nobody Wins!", tiex, 400);
        g.drawString("Wins: " + wins + " Losses: " + loss, 550, 40);

        // prints all the wins and if you lose or tie
        g.setColor(Color.black);
        fontSize = 14;

    }

    public void shuffle(ArrayList<Card> array) {
        // this code will shuffle the cards

        for (int i = 0; i < array.size(); i++) {
            int i2 = (int) (Math.random() * array.size());

            Card temp1 = array.get(i);
            Card temp2 = array.get(i2);
            array.set(i2, temp1);
            array.set(i, temp2);

        }

        System.out.println("");
    }

    public void actionPerformed(ActionEvent e) {
        // all this code below will print gameplay
        Hit.setVisible(true);
        Stand.setVisible(true);

        if (findTotal(player) == 21) {
            Hit.setVisible(false);
        }

        if(e.getSource() == Advice){
            if(findTotal(player)<18){
                hitx=300;
            }else{
                standx=300;
            }
        }


        if (e.getSource() == Hit) {

            System.out.println("Hit Button Has Been Pressed");
            hitx=1000;
            standx=1000;
            if (findTotal(player) == 21) {
                Hit.setVisible(false);
            }
            if (findTotal(player) >= 21) {
                Hit.setVisible(false);
                System.out.println("bust");
                Stand.setVisible(false);
                bustx = 500;
                loss = loss + 1;
                NewGame.setVisible(true);
            } else {
                player.add(deck.get(0));
                deck.remove(0);
                if (findTotal(player) > 21) {
                    Hit.setVisible(false);
                    System.out.println("bust");
                    Stand.setVisible(false);
                    bustx = 500;
                    loss = loss + 1;
                    NewGame.setVisible(true);
                    repaint();
                }

            }
            repaint();
        } else if (e.getSource() == Stand) {
            hitx=1000;
            standx=1000;
            System.out.println("Stand Button Has Been Pressed");
            Hit.setVisible(false);
            Stand.setVisible(false);
            try {
                Thread.sleep(250);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
            coverx = 1000;
            try {
                Thread.sleep(250);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
            dealercoverx = 20;
            dealercoverxx = 1000;

            while (findDealerTotal(dealer) < 17) {
                System.out.println("");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
                dealer.add(deck.get(0));
                deck.remove(0);
            }
            if (findDealerTotal(dealer) > 21) { // if dealer busts
                wins = wins + 1;
                dealerbustx = 400;
                NewGame.setVisible(true);
            }
            // if dealer under 22 and greater than player, you lose
            if (findDealerTotal(dealer) < 22 && findDealerTotal(dealer) > findTotal(player)) {
                lossx = 500;
                loss = loss + 1;
                NewGame.setVisible(true);
            } else if (findDealerTotal(dealer) < 22 && findDealerTotal(dealer) < findTotal(player)) {
                winx = 500;
                wins = wins + 1;
                NewGame.setVisible(true);
            } else if (findDealerTotal(dealer) < 22 && findDealerTotal(dealer) == findTotal(player)) {
                System.out.println("It was a tie");
                NewGame.setVisible(true);
                tiex = 200;
            }
            // if dealer under 22 and less than player, you win
            repaint();
        } else if (e.getSource() == NewGame) {
            hitx=1000;
            standx=1000;

            // next to for loops are important, they 'refill' the deck (as previously you
            // took cards out of the deck to put them into player and dealer arraylists)
            for (int i = 0; i < player.size(); i++) {
                deck.add(player.get(i));
            }
            player.clear();

            for (int i = 0; i < dealer.size(); i++) {
                deck.add(dealer.get(i));
            }
            dealer.clear();


            // for player and dealer, give 2 cards
            player.add(deck.get(0));
            deck.remove(0);
            player.add(deck.get(0));
            deck.remove(0);

            dealer.add(deck.get(0));
            deck.remove(0);
            dealer.add(deck.get(0));
            deck.remove(0);

            playertotalcardvalue = 0; // card value count
            winx = 1000; // next 3 are variables for text (its offscreen by putting it to 1000)
            lossx = 1000;
            tiex = 1000;
            coverx = 100; // the 'cover' on the second dealer card is back on
            dealercoverxx = 20; // not sure
            dealercoverx = 1000; // not sure
            bustx = 2000;// bust text offscreen
            dealerbustx = 1000;// dealer bust text offscreen
            System.out.println("");// for testing purposes
            // make other buttons visible, this new game button invisible
            Hit.setVisible(true);
            Stand.setVisible(true);
            NewGame.setVisible(false);

            repaint();
        }

        repaint();
    }
}
