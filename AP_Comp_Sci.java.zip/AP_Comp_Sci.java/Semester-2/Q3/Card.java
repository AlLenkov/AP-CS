import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Card {

    private int value;
    private String name;
    private String suit;
    private BufferedImage suitImage;
    public Color card;

   public Card(int value, String name, String suit){
    card =  new Color(227, 216, 213);
    this.value = value;
    this. name = name;
    this.suit = suit;

  }

    public int getValue() {
        return this.value;
    }

    public void drawMe(Graphics g, int x, int y) {

        g.setColor(card);
        g.fillRect(x, y, 120, 150);
        g.setColor(Color.black);
        g.drawRect(x, y, 120, 150);

        // Set Font to use with drawString
        Font font = new Font("Arial", Font.ITALIC, 25);
        g.setFont(font);

        if (suit.equals("hearts"))
            g.setColor(Color.RED);
        if (suit.equals("clubs"))
            g.setColor(Color.BLACK);
        if (suit.equals("diamonds"))
            g.setColor(Color.RED);
        if (suit.equals("spades"))
            g.setColor(Color.BLACK);

        g.drawString(this.name + "", x + 5, y + 22);

    }

}
