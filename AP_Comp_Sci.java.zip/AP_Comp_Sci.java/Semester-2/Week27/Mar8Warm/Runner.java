public class Runner {
    public static void main(String[] args) {
        // Create a 2D array of size 6x4 and fill it with random numbers
        int[][] randomMatrix = new int[6][4];
        for (int i = 0; i < randomMatrix.length; i++) {
            for (int j = 0; j < randomMatrix[i].length; j++) {
                randomMatrix[i][j] = (int) (Math.random() * 10) + 1; // Random number between 1 and 10
            }
        }

        // Instantiate NumMatrix3 passing in the 2D array created
        NumMatrix3 matrix3 = new NumMatrix3(randomMatrix);

        // Call print()
        System.out.println("NumMatrix3:");
        matrix3.print();

        // Call sumRow(2) and print the result
        int sumOfRow2 = matrix3.sumRow(2);
        System.out.println("\nSum of row 2: " + sumOfRow2);

    }
}