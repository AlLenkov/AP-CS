import java.util.Arrays;

public class NumMatrix3 {
    private int[][] numMatrix;

    // Constructor
    public NumMatrix3(int[][] matrix) {
        this.numMatrix = matrix;
    }

    // Method to print the matrix
    public void print() {
        for (int[] row : numMatrix) {
            for (int num : row) {
                System.out.print(num + "\t");
            }
            System.out.println();
        }
    }

    // Method to calculate the sum of a row
    public int sumRow(int rowIndex) {
        if (rowIndex < 0 || rowIndex >= numMatrix.length) {
            return 0; // Handle invalid index
        }
        int sum = 0;
        for (int num : numMatrix[rowIndex]) {
            sum += num;
        }
        return sum;
    }

}