public class Runner {
    public static void main(String[] args) {
        int[][] myArr = new int[4][5];
        //makes assigns random numbers from 1-5 to array
        for (int i = 0; i < myArr.length; i++) {
            for (int j = 0; j < myArr[i].length; j++) {
                myArr[i][j] = (int) (Math.random() * 5) + 1;
            }
        }
        //calls wanted methods
        Array2D obj = new Array2D(myArr);
        obj.print();
        obj.searchReplace(5, -5);
        obj.print();
        System.out.println("The sum is " + obj.sumColumn(4));

    }
}
