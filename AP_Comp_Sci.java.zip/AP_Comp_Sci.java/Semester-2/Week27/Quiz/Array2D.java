public class Array2D {
    //instance variables
    private int[][] numArr;

    //Takes in a 2D array and assigns it to the instance
    public Array2D(int[][] arr) {
        numArr = arr;
    }

    //Print numArr in table format.
    public void print() {
        for (int[] row : numArr) {
            for (int num : row) {
                System.out.print(num + "  ");
            }
            System.out.println();
        }
        System.out.println();
    }


    //search for the first parameter and replace it with the second parameter.
    public void searchReplace(int replacefrom, int replaceto) {
        for (int i = 0; i < numArr.length; i++) {
            for (int j = 0; j < numArr[i].length; j++) {
                if (numArr[i][j] == replacefrom) {
                    numArr[i][j] = replaceto;
                }
            }
        }
    }

    
    // Returns the sum of all of the elements in the indicated column.
    public int sumColumn(int col) {
        int sum = 0;
        for (int i = 0; i < numArr.length; i++) {
            sum += numArr[i][col];
        }
        return sum;
    }

}
