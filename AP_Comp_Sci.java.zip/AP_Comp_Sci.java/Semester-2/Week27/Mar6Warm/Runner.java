public class Runner {
    public static void main(String[] args) {
        NumMatrix2 matrix = new NumMatrix2(3, 4);
        
        System.out.println("Matrix:");
        matrix.print();
        
        System.out.println("\nMatrix in Reverse Order:");
        matrix.printReverse();
        
        int value1 = matrix.getValue(1, 3);
        System.out.println("\nValue at (1, 3): " + value1);
        
        int value2 = matrix.getValue(0, 2);
        System.out.println("Value at (0, 2): " + value2);
    }
}
