public class NumMatrix2 {
    private int[][] matrix;

    // Constructor
    public NumMatrix2(int row, int column) {
        matrix = new int[row][column];
        int value = 1;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                matrix[i][j] = value++;
            }
        }
    }

    // Method to print the matrix
    public void print() {
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.print(num + "\t");
            }
            System.out.println();
        }
    }

    // Method to print the matrix in reverse order
    public void printReverse() {
        for (int i = matrix.length - 1; i >= 0; i--) {
            for (int j = matrix[i].length - 1; j >= 0; j--) {
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }
    }

    // Method to get the value at the given location
    public int getValue(int row, int column) {
        return matrix[row][column];
    }
}