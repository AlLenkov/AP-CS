public class Runner {
    public static void main(String[] args) {
        StringTest2 obj = new StringTest2("potato");
        obj.printWordGame();
    }
}
