public class StringTest2 {
    String word;

    public StringTest2(String word){
        this.word = word;
    }

    private char getfirstletter(){
        return word.charAt(0);
    }

    private char getlastletter(){
        return word.charAt(word.length()-1);
    }

    public void printWordGame(){
        System.out.print(getfirstletter());
        for (int i=0; i<word.length()-1; i++){
            System.out.print("*");
        }
        System.out.print(getlastletter());
    }
}
