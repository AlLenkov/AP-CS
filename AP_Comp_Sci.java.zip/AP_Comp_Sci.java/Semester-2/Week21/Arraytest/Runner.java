public class Runner{
    public static void main(String[] args){
        ArrayTest at= new ArrayTest();
        at.printNumArray();
        at.printStringArray();
        at.swapNumArray(0,9);
        at.printNumArray();
        at.swapStringArray(1,2);
        at.printStringArray();
        System.out.println("The word dog is found at index "+at.SearchString("dog"));
        System.out.println("The word balloon is found at index "+at.SearchString("ballon"));
    }
}

