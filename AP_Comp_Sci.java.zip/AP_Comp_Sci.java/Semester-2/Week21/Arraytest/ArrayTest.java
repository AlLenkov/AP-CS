public class ArrayTest{
    int[] numArray;
    String[] stringArray;
    public ArrayTest(){
        numArray= new int[10];
        for(int i=0;i<numArray.length;i++){
            numArray[i]=(int)(Math.random()*21-1);
        }
        stringArray= new String[5];
        stringArray[0]="dog";
        stringArray[1]="cat";
        stringArray[2]="pigeon";
        stringArray[3]="horse";
        stringArray[4]="cow";
    }

    public void printNumArray(){
        for(int each : numArray){
        System.out.print(each+" ");
        }
        System.out.println();
    }

   public void printStringArray(){
        for(String each : stringArray){
        System.out.print(each+" ");
        }
        System.out.println();
    }

    public void swapNumArray(int a, int b){
        int avalue=numArray[a];
        int bvalue=numArray[b];
        numArray[a]=bvalue;
        numArray[b]=avalue;
        }

     public void swapStringArray(int a, int b){
        String avalue=stringArray[a];
        String bvalue=stringArray[b];
        stringArray[a]=bvalue;
        stringArray[b]=avalue;
        }

    public int SearchString(String s){
        for(int i=0; i<stringArray.length;i++){
            if(stringArray[i].equals(s)){
                return i;
            }
        }
        return -1;
    }
}

