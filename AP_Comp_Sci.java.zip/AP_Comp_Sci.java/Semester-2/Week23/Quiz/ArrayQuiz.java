public class ArrayQuiz {

    private int intArray[];
    // allocating memory to array

    public ArrayQuiz() {
        intArray = new int[] { 2, 4, 6, 8, 10, 12 };
    }
    //prints array
    public void printArray(){
        System.out.println("printArray:");
        //prints every element in array
        for (int each : intArray){
            System.out.print(each+" ");
        }
        System.out.println();
    }
    //searches array for passed in number
    public int search(int num) {
        System.out.println("search:");
        for (int i=0; i<intArray.length; i++) {

            if (intArray[i] == num) {
                return i;
            }
        }
        return -1;
    }
    //scrambles array
    public void scramble() {
        for(int i=0; i<intArray.length; i++){
            //genertates a random number
            int a=(int)(Math.random()*intArray.length-1);
            //saves the value of index i
            int temp0=intArray[i];
            //changes index i to the value of a random index
            intArray[i]=intArray[a];
            //sets the value of the random index to that of index i
            intArray[a]=temp0;
        }
    }
    //sorts array
    public void sort(){
        for(int n=0; n<intArray.length-1;n++){
            for(int i=0;i<intArray.length-1;i++){
                //if the number is greater than the next index it swaps them
                if(intArray[i]>intArray[i+1]){
                    int temp=intArray[i];
                    intArray[i]=intArray[i+1];
                    intArray[i+1]=temp;
                }
            }
        }
    }
}