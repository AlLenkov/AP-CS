public class Runner
{
    public static void main(String[] args){
        //creates object aq of ArrayQuiz class
        ArrayQuiz obj= new ArrayQuiz();
        //prints the array
        obj.printArray();
        //searches for the number 6 in the array and prints the index
        System.out.println(obj.search(6));
        //scrambles the array
        obj.scramble();
        obj.printArray();
        //calls on method sort to sort the array to least to greatest
        obj.sort();
        obj.printArray();

   }
}