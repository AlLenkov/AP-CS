class Sort{
    String[] strArray;
    public Sort(){
        strArray= new String[10];
        strArray[0]="pig";
        strArray[1]="cow";
        strArray[2]="horse";
        strArray[3]="mouse";
        strArray[4]="moose";
        strArray[5]="elephant";
        strArray[6]="dog";
        strArray[7]="ape";
        strArray[8]="sheep";
        strArray[9]="kangaroo";
    }

    public void printArray(){
        for (String each: strArray){
            System.out.println(each);
        }
    }

    public void sortArray(){
        for(int i=0; i < strArray.length-1; i++ ){
            // Array is traversed from index 0 through index sArr.length-i-1
            for(int j=0; j < strArray.length-i-1; j++){
                //If item at j is greater than j+1,then swap
                int result=strArray[j].compareTo(strArray[j+1]);
                if(result > 0){
                    //swap
                    String temp = strArray[j];
                    strArray[j] = strArray[j+1];
                    strArray[j+1] = temp;
                }
            }
        }
    }
}


