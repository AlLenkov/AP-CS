import java.util.ArrayList;

public class ArrayListTest {
    private ArrayList<Integer> numlist;


    public ArrayListTest(int elements) {
        numlist = new ArrayList<>();
        for (int i = 0; i < elements; i++) {
            numlist.add((int) (Math.random() * 14 + 1));
        }
    }

    public void print() {
        System.out.print("ArrayList (Forward): ");
        for (int element : numlist) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    public void printBackwards() {
        System.out.print("ArrayList (backwards): ");
        for (int i = numlist.size() - 1; i >= 0; i--) {
            System.out.print(numlist.get(i) + " ");
        }
        System.out.println();
    }

}
