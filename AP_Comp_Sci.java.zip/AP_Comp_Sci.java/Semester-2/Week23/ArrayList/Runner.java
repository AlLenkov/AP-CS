public class Runner {
    public static void main(String[] args) {
        ArrayListTest obj = new ArrayListTest(10);
        obj.print();
        obj.printBackwards();
    }
}
