public class AnimalArray {

    private String[] animals;

    public AnimalArray() {
        this.animals = new String[]{"Lion", "Elephant", "Giraffe", "Zebra", "Kangaroo"};
    }

    public void printAnimals() {
        for (String animal : animals) {
            System.out.print(animal + " ");
        }
        System.out.println(); 
    }

    public void swapAnimals(int index1, int index2) {
            String temp = animals[index1];
            animals[index1] = animals[index2];
            animals[index2] = temp;
    }
}
