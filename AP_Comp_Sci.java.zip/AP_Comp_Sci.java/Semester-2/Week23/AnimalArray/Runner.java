public class Runner {
    public static void main(String[] args) {
        AnimalArray animalArray = new AnimalArray();

        System.out.println("Original Animals:");
        animalArray.printAnimals();

        animalArray.swapAnimals(0, 4);

        System.out.println("Animals after swapping indices 0 and 4:");
        animalArray.printAnimals();
    }
}
