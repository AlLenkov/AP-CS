import java.util.ArrayList;

public class ArrList{

    private ArrayList<Integer> numList;

    public ArrList(){
        numList = new ArrayList<>();
        for(int i=0; i<=10; i++){
            numList.add((int)(Math.random()*10-1));
        }
    }

    public void printList(){
        for(int each : numList){
            System.out.print(each+" ");
        }
        System.out.println();
    }

    public int searchLargest(){
        int largest=0;
        for(int j=0;j<numList.size()-1;j++){
           if(numList.get(j)>largest){
            largest=numList.get(j);
           }
        }
        return largest;
    }

    public void searchAndReplace(int a){
        for(int i=0; i<numList.size();i++){
            if(numList.get(i)==a){
                numList.set(i, 1000);
            }
        }
    }

    public void searchAndRemove(int a){
        for(int i=0; i<numList.size();i++){
            if(numList.get(i)==a){
                numList.remove(i);
            }
        }
    }

    public void scramble(){
        for(int i=0; i<numList.size(); i++){
            int a=(int)(Math.random()*numList.size()-1);
            int temp=numList.get(i);
            numList.set(i,numList.get(a));
            numList.set(a,temp);
        }
    }
}