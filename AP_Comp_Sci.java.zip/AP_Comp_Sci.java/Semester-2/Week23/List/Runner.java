public class Runner {
    public static void main(String[] args) {
        ArrList obj = new ArrList();
        obj.printList();
        int largest= obj.searchLargest();
        System.out.println("The largest int in the array is "+largest);
        obj.searchAndReplace(largest);
        obj.printList();
        obj.searchAndRemove(1000);
        obj.printList();
        obj.scramble();
        obj.printList();
    }
}


