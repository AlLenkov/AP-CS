import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class Table extends JPanel {


	private ArrayList<Card> deck;
	private ArrayList<Card> pCards;
	private ArrayList<Card> dCards;

	private JButton hit;
	private JButton stand;

	private int playerX;
	private int playerY;

	public Table() {
	 deck = new ArrayList<Card>();
	 pCards = new ArrayList<Card>();
	 dCards = new ArrayList<Card>();

	 deck.add(new Card(2, "2", "hearts"));
	 deck.add(new Card(2, "2", "hearts"));
	 deck.add(new Card(2, "2", "hearts"));
	 deck.add(new Card(2, "2", "hearts"));

	}
	
	public Dimension getPreferredSize() {
		//Sets the size of the panel
		return new Dimension(800,600);
	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		g.setColor(Color.blue);
		//getWidth() and getHeight() are Dimension methods
		g.fillRect(0, 0, getWidth(), getHeight());
	}
	


	public void shuffle(){
		//write code to shuffle your deck
	}


}