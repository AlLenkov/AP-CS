
public class Hailstone
{
	/** Returns the length of a hailstone sequence that starts with n,
	* as described in part (a).
	* Precondition: n>0
	*/
	public static int hailstoneLength(int n)
	{ /* to be implemented in part (a) */
        int count = 0;
        if (n>1){
            if(n%2==0){
                hailstoneLength(n/2);
            }
            else{
                hailstoneLength(3n+1);
            }
            return count;
        }
	}
	
	
	/** Returns true if the hailstone sequence that starts with n is considered long
	* and false otherwise, as described in part (b).
	* Precondition: n>0
	*/
	public static boolean isLongSeq(int n)
	{ /* to be implemented in part (b) */
		if (hailstoneLength(n) > n){
            return true;
        }
        return false;
	}
	
	
	/** Returns the proportion of the first n hailstone sequences that are considered long,
	* as described in part (c).
	* Precondition: n>0
	*/
	public static double propLong(int n)
	{ /* to be implemented in part (c) */ 
        int loong;
        loong = 0;
        for(int x = n; x++;x>0){
            if (isLongSeq(n)){
                loong++;
            }
        }
        return loong/n;
	}
	// There may be instance variables, constructors, and methods not shown.
}