
public class Runner {
	public static void main(String[] args){
		System.out.println("Part A: ");
		int n = 1;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 2;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 3;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 4;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 5;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 6;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 7;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 8;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 9;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		n = 10;
		System.out.println("Number: "+n+", " + "hailstoneLength: " + Hailstone.hailstoneLength(n));
		
		
		System.out.println("\nPart B: ");
		n = 1;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 2;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 3;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 4;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 5;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 6;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 7;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 8;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 9;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
		n = 10;
		System.out.println("Number: "+n+", " + "isLongSeq: " + Hailstone.isLongSeq(n));
	
		System.out.println("\nPart C: ");
		System.out.println("Number: 10, " + "propLong: " + Hailstone.propLong(10));
	}
}