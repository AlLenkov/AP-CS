public class Runner {
    public static void main(String[] args) {
        Vampire dracula = new Vampire("Dracula");
        dracula.addCoins(50);

        Mummy ramses = new Mummy("Ramses");
        ramses.addCoins(30);

        Witch maleficent = new Witch("Maleficent");
        maleficent.addCoins(20);

        dracula.getInfo();
        System.out.println("Coins: " + dracula.getCoins());

        ramses.getInfo();
        System.out.println("Coins: " + ramses.getCoins());

        maleficent.getInfo();
        System.out.println("Coins: " + maleficent.getCoins());

        System.out.println("Total monster count: " + Monster.getCount());
        System.out.println("Total coins collected: " + (dracula.getCoins() + ramses.getCoins() + maleficent.getCoins()));
    }
}
/*
1. Do you need to instantiate an object of a class to access its public static instance variables and methods?

2. Identify a built-in class in Java with static methods and instance variables that you have used. Identify the class name and the method/instance variable that you used.

3. How are static methods and instance variables useful? 
    because they all point to the same memory address
4. What is the advantage of making count a static instance variable?
    because they all count and add to the same variable

 */