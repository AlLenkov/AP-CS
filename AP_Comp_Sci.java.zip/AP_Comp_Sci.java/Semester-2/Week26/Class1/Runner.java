public class Runner {
    public static void main(String[] args) {
        // Instantiate Array2DString
        Array2DString array2DString = new Array2DString();

        // Create a 3x3 array called animalArr of strings and fill with different animals
        String[][] animalArr = {
                {"Dog", "Cat", "Rabbit"},
                {"Lion", "Tiger", "Bear"},
                {"Elephant", "Monkey", "Giraffe"}
        };

        // Call printStr(animalArr)
        array2DString.printStr(animalArr);

        // Call findAnimal(animalArr, String) and pass an animal name that you know is in the array
        Boolean foundAnimal1 = array2DString.findAnimal(animalArr, "Cat");
        System.out.println("Result for Cat: " + foundAnimal1);

        // Call findAnimal(animalArr, String) with an animal name that is not in the array
        Boolean foundAnimal2 = array2DString.findAnimal(animalArr, "Snake");
        System.out.println("Result for Snake: " + foundAnimal2);
    }
}

