public class Array2DString {
    
    public void printStr(String[][] arr){
        for (int i=0;i<arr.length;i++){
            for (int j=0; j<arr[i].length;j++){
                System.out.print(arr[i][j]+"\t");
            }
            System.out.println("");
        }
    }

    public boolean findAnimal(String[][] arr, String Animal){
        for (int i=0;i<arr.length;i++){
            for (int j=0; j<arr[i].length;j++){
                if(arr[i][j] == Animal){
                    return true;
                }
            } 
        }
        return false;
    }
}
