import java.awt.Graphics;

public class Game {

    private int[][] table;
    private int turn;

    public Game() {
        turn = 1;
        table = new int[3][3];
    }

    public void insertXO(int row, int column) {
        System.out.println("row: "+ row + "col: "+ column);
        if (table[row][column] == 0) {
            table[row][column] = turn;
        } else {
            System.out.println("Invalid move.");
        }
        if (turn == 1) {
            turn = 2;
        } else {
            turn = 1;
        }

    }

    public int getTurn(){
        return turn;
    }
    
    public boolean checkFull(){
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                if (table [i][j] == 0){
                    return false;
                }
            }
        }
        return true;
    }

    public int checkTicTacToe(){
        for (int i = 0; i < 3; i++){
            if (table[i][0] == table[i][1] && table[i][1] == table[i][2]){
                if (table[i][0] == 1){
                    return 1;
                } 
                else {
                    if (table[i][0] == 2) {
                        return 2;
                } 
                    else {
                        return 0;
                }
                }
                
            }
        }

        for (int i = 0; i < 3; i++){
            if (table[0][i] == table[1][i] && table[1][i] == table[2][i]){
                if (table[0][i] == 1){
                    return 1;
                }
                if (table[0][i] == 2) {
                    return 2;
                }
            }
        }

        if (table[0][0] == table[1][1] && table[1][1] == table[2][2]){
            if (table[0][0] == 1){
                return 1;
            }
            if (table[0][0] == 2) {
                return 2;
            }
        }

        if (table[0][2] == table[1][1] && table[1][1] == table[2][0]){
            if (table[0][2] == 1){
                return 1;
            }
            if (table[0][2] == 2) {
                return 2;
            }
        }
        return 0;

    } 

    public void printTable() {
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                System.out.print(table[i][j] + "  "); 
            }
            System.out.println(); 
        }
    }

    public void drawGrid(Graphics g){
        g.drawRect(200, 0, 5, 800);
        g.drawRect(400, 0, 5, 800);
        g.drawRect(0, 200, 800, 5);
        g.drawRect(0, 400, 800, 5);
        

        String a = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                if (table[i][j] == 1){
                    a = "X";
                    //System.out.println(i + "=i,  j" + j+"turn = "+ a);
                }
                if (table[i][j] == 2){
                    //System.out.println(i + "=i,  j=" + j+"turn = "+ a);
                    a = "O";
                }

                if (table[i][j] == 0){

                }
                else{
                    g.drawString(a + " ", 100 + (200 * j), 100 + (200 * i));
                }
            }
            
        }

    }

}
