import java.util.Scanner;
import javax.swing.JFrame;
public class Runner {
    public static void main(String[] args){
        JFrame frame = new JFrame("TicTacToe");

        Screen g = new Screen();
        frame.add(g);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}