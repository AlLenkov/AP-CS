import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;


public class Screen extends JPanel implements MouseListener{
    private int rep;

    public Screen(){
        addMouseListener(this);
    }

    Game obj = new Game();

    @Override
    public Dimension getPreferredSize() {
        
        return new Dimension(800, 600);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        obj.drawGrid(g);
    }

    public void mousePressed(MouseEvent e) {
        System.out.println(e.getX() + "," + e.getY());

        if (e.getX() >= 10 && e.getX() <= 260 && e.getY() >= 10 && e.getY() <= 200) {
            obj.insertXO(0,0);
            
        } else if (e.getX() >= 270 && e.getX() <= 540 && e.getY() >= 10 && e.getY() <= 200) {
            obj.insertXO(0,1);
            
        } else if (e.getX() >= 550 && e.getX() <= 790 && e.getY() >= 10 && e.getY() <= 200) {
            obj.insertXO(0,2);
            
        } else if (e.getX() >= 10 && e.getX() <= 260 && e.getY() >= 210 && e.getY() <= 400) {
            obj.insertXO(1,0);
            
        } else if (e.getX() >= 270 && e.getX() <= 540 && e.getY() >= 210 && e.getY() <= 400) {
            obj.insertXO(1,1);
            
        } else if (e.getX() >= 550 && e.getX() <= 790 && e.getY() >= 210 && e.getY() <= 400) {
            obj.insertXO(1,2);
            
        } else if (e.getX() >= 10 && e.getX() <= 260 && e.getY() >= 410 && e.getY() <= 590) {
            obj.insertXO(2,0);
            
        } else if (e.getX() >= 270 && e.getX() <= 540 && e.getY() >= 410 && e.getY() <= 590) {
            obj.insertXO(2,1);
            
        } else if (e.getX() >= 550 && e.getX() <= 790 && e.getY() >= 410 && e.getY() <= 700) {
            obj.insertXO(2,2);
            
        }

            
            if (obj.checkTicTacToe() == 0){
                repaint();
            }
            
    }
    

    public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    public void mouseClicked(MouseEvent e) {}

}
/*
 
        Game obj = new Game();
        boolean game = true;
        Scanner keyboard = new Scanner(System.in);
        
            while(game == true){
                
                System.out.println("Player" + obj.getTurn() + ", chose a row: " );
                int choiceX = keyboard.nextInt();

                System.out.println("Choose a column: ");
                int choiceY = keyboard.nextInt();
                obj.insertXO(choiceX, choiceY);
                obj.printTable();
                int check = obj.checkTicTacToe();
                
                if(check  == 1){
                    System.out.println("Player 1 Wins");
                    game = false;
                } else if(check == 2){
                    System.out.println("Player 2 Wins");
                    game = false;
                }

                if(obj.checkFull()){
                    game = false;
                }

            }

        keyboard.close();

 */