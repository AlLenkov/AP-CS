import java.util.Scanner;
public class Runner {
    public static void main(String[] args) {
        Game obj = new Game();
        int col, row;
        Scanner scan = new Scanner(System.in);
        while (true){
            System.out.println("Player 1, what collum would you like to fill?(0, 1, 2)");
            col = scan.nextInt();
            System.out.println("Player 1, what row would you like to fill?(0, 1, 2)");
            row = scan.nextInt();
            obj.insertXO(row, col);
            System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n");
            obj.printTable();
            if (obj.checkTicTacToe()>0){
                System.out.println("player" + obj.checkTicTacToe()+" is the winner");
                break;
            }
            if(obj.checkFull()){
                break;
            }
            System.out.println("Player 2, what collum would you like to fill?(0, 1, 2)");
            col = scan.nextInt();
            System.out.println("Player 2, what row would you like to fill?(0, 1, 2)");
            row = scan.nextInt();
            obj.insertXO(row, col);
            System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n");
            obj.printTable();
            if (obj.checkTicTacToe()>0){
                System.out.println("player" + obj.checkTicTacToe()+" is the winner");
                break;
            }
            if(obj.checkFull()){
                break;
            }

        }

    }

}
