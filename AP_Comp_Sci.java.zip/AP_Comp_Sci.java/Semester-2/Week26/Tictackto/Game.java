public class Game {

    private int[][] table;
    private int turn;

    public Game() {
        turn = 1;
        table = new int[3][3];
    }

    public void insertXO(int row, int column) {
        if (table[row][column] == 0) {
            table[row][column] = turn;
        } else {
            System.out.println("Invalid move.");
        }
        if (turn == 1) {
            turn = 2;
        } else {
            turn = 1;
        }

    }
    
    public boolean checkFull(){
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                if (table [i][j] == 0){
                    return false;
                }
            }
        }
        return true;
    }

    public int checkTicTacToe(){
        for (int i = 0; i < 3; i++){
            if (table[i][0] == table[i][1] && table[i][1] == table[i][2]){
                if (table[i][0] == 1){
                    return 1;
                }
                if (table[i][0] == 2) {
                    return 2;
                }
            }
        }

        for (int i = 0; i < 3; i++){
            if (table[0][i] == table[1][i] && table[1][i] == table[2][i]){
                if (table[0][i] == 1){
                    return 1;
                }
                if (table[0][i] == 2) {
                    return 2;
                }
            }
        }

        if (table[0][0] == table[1][1] && table[1][1] == table[2][2]){
            if (table[0][0] == 1){
                return 1;
            }
            if (table[0][0] == 2) {
                return 2;
            }
        }

        if (table[0][2] == table[1][1] && table[1][1] == table[2][0]){
            if (table[0][2] == 1){
                return 1;
            }
            if (table[0][2] == 2) {
                return 2;
            }
        }
        return 0;

    }

    public void printTable() {
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                System.out.print(table[i][j] + "  "); 
            }
            System.out.println(); 
        }
    }

}
/*
 * ● + checkTicTacToe(): int - Return 1 if there’s a tic-tac-toe for player 1,
 * return 2 if there’s a tic-tac-toe for player 2, or return 0 if there is no
 * tic-tac-toe.
 * 
 * ● + printTable() : void - Print the 3x3 with each row having its own line.
 * For each array location: if there's a 1 print an X, if there's a 2 print an
 * O, and if there's a 0 print an * as a placeholder.
 */
