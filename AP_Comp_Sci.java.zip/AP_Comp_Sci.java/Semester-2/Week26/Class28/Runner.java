public class Runner {
    public static void main(String[] args) {
        Array2DInt array = new Array2DInt(5, 5);

        System.out.println("Array of Random Integers:");
        array.printInts();

        array.findLargest();
    }
}
