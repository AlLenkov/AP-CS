
public class Array2DInt {
    private int[][] intArray;

    // Constructor
    public Array2DInt(int rows, int columns) {
        intArray = new int[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                intArray[i][j] = (int)(Math.random()*9 + 1); 
            }
        }
    }

    public void printInts() {
        for (int i = 0; i < intArray.length; i++) {
            for (int j = 0; j < intArray[i].length; j++) {
                System.out.print(intArray[i][j] + "\t"); 
            }
            System.out.println(); 
        }
    }

    public void findLargest() {
        int largest = intArray[0][0];
        int row = 0;
        int column = 0;

        for (int i = 0; i < intArray.length; i++) {
            for (int j = 0; j < intArray[i].length; j++) {
                if (intArray[i][j] > largest) {
                    largest = intArray[i][j];
                    row = i;
                    column = j;
                }
            }
        }

        System.out.println("largest number is " + largest + " at row " + (row + 1) + " at column " + (column + 1) + ".");
    }
}