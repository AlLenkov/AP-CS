import java.util.ArrayList;

public class PetRunner {
    public static void main(String[] args) {
        // create a Kennel Object
        Kennel kObj = new Kennel();
        kObj.allSpeak();
    }
}

//---------------------------------------------------------------
    // Pet Class
    abstract class Pet {
        private String myName;
        
        // constructor
        public Pet(String name) {
            myName = name;
        }



        public abstract String speak();
        
    }

//----------------------------------------------------------------

    // Dog class
    class Dog extends Pet {

        // constructor
        public Dog(String name) {
            super(name);
        }
 
        // speak method
        @Override
        public String speak() {
            return("WOOF");
        }
    }
// Complete class declaration for the class Cat
class Cat extends Pet {
    // Constructor
    public Cat(String name) {
        super(name);
    }

    // Method to speak
    @Override
    public String speak() {
        return "meow";
    }
}

// Complete class declaration for the class LoudDog
class LoudDog extends Dog {
    // Constructor
    public LoudDog(String name) {
        super(name);
    }

    // Method to speak loudly
    @Override
    public String speak() {
        return "WOOF! WOOF!";
    }
}
    class Kennel {
        private ArrayList<Pet> petList;

        public Kennel() {
            petList = new ArrayList<Pet>();
            petList.add(new Cat("Princess"));
            petList.add(new Dog("Fido"));
            petList.add(new LoudDog("Rufus"));

        }

        /* For each Pet in the kennel, allSpeak prints a line with the 
        name of the Pet followed by the result of a call to its speak 
        method. */
        public void allSpeak() {
            for (Pet each: petList){
                System.out.println(each.speak() );
            }
        }
    }