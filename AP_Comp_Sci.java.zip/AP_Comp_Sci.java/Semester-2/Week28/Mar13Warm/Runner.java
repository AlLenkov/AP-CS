public class Runner {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9}; 
        
        OneToTwo obj = new OneToTwo(); 
        
        System.out.println("Original array:");
        obj.print(); 
        
        obj.insert(array);
        
        System.out.println("\nArray after insertion:");
        obj.print(); 
    }
}
