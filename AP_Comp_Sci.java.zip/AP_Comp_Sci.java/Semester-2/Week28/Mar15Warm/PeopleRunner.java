public class PeopleRunner {
	public static void main(String args[]) {
		Student s = new Student("John");
        Teacher t = new Teacher("Jose");
        s.printInfo();
        t.printInfo();
	}
}

class People {
    private String name;

    public People(String name){
        this.name=name;
    }

    public String getName(){
        return name;
    }

    public void printInfo(){
        System.out.println("I go to MVHS");
    }
}

class Teacher extends People {
	public Teacher(String name){
        super(name);
    }
    @Override
    public void printInfo(){
        super.printInfo();
        System.out.println("my name i    s "+ getName()+ " I am a Teacher");
    }
}

class Student extends People {  
	public Student(String name){
        super(name);
    }

    public void printInfo(){
        super.printInfo();
        System.out.println("my name is "+ getName()+ " I am a Student");
    }
		
}
		