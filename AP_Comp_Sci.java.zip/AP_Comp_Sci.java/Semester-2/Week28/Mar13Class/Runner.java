class Animal {
    private String name;

    public Animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void speak() {
        System.out.println("Hello, my name is " + name);
    }
}

class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }

    public void printInfo() {
        super.speak();
        System.out.println("I make the sound woof");
    }

    @Override
    public void speak() {
        System.out.println("woof");
    }
}

class Bird extends Animal {
    public Bird(String name) {
        super(name);
    }

    public void printInfo() {
        super.speak();
        System.out.println("I make the sound tweet");
    }

    @Override
    public void speak() {
        System.out.println("tweet");
    }
}

public class Runner {
    public static void main(String[] args) {
        Dog fido = new Dog("Fido");
        fido.printInfo();

        Bird tweety = new Bird("Tweety");
        tweety.printInfo();
    }
}
