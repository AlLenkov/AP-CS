public class Runner {
    public static void main(String[] args) {
        int[] arr = {3, 5, 6, 8, 10, 13, 14};

        BinarySearch binarySearch = new BinarySearch();

        // Call resetPass
        binarySearch.resetPass();

        // Call binarySearch for search number 5
        int index = binarySearch.binarySearch(arr, 5, 0, arr.length - 1);
        System.out.println("Index of 5: " + index);
        System.out.println("Passes: " + binarySearch.getPass());

        // Call resetPass
        binarySearch.resetPass();

        // Call binarySearch for search number 14
        index = binarySearch.binarySearch(arr, 14, 0, arr.length - 1);
        System.out.println("Index of 14: " + index);
        System.out.println("Passes: " + binarySearch.getPass());

        // Call resetPass
        binarySearch.resetPass();

        // Call binarySearch for search number 99
        index = binarySearch.binarySearch(arr, 99, 0, arr.length - 1);
        System.out.println("Index of 99: " + index);
        System.out.println("Passes: " + binarySearch.getPass());
    }
}
