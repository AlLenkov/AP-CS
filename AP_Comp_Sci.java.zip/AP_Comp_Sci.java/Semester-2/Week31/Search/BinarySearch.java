class BinarySearch {
    private int pass;

    public BinarySearch() {
        this.pass = 0;
    }

    public void resetPass() {
        this.pass = 0;
    }

    public int getPass() {
        return this.pass;
    }

    public int binarySearch(int[] arr, int searchNum, int start, int end) {
        pass++;
        if (end >= start) {
            int mid = start + (end - start) / 2;

            if (arr[mid] == searchNum)
                return mid;

            if (arr[mid] > searchNum)
                return binarySearch(arr, searchNum, start, mid - 1);

            return binarySearch(arr, searchNum, mid + 1, end);
        }

        return -1;
    }
}

