
public class Runner {
    public static void main(String[] args) {
        int[] arr = {3, 5, 6, 8, 10, 13, 14};
        BinarySearch binarySearch = new BinarySearch();

        binarySearch.resetPass();
        int result1 = binarySearch.binarySearch(arr, 5, 0, 6);
        System.out.println("Index of 5: " + result1);
        System.out.println("Passes: " + binarySearch.getPass());

        binarySearch.resetPass();
        int result2 = binarySearch.binarySearch(arr, 14, 0, 6);
        System.out.println("Index of 14: " + result2);
        System.out.println("Passes: " + binarySearch.getPass());

        binarySearch.resetPass();
        int result3 = binarySearch.binarySearch(arr, 99, 0, 6);
        System.out.println("Index of 99: " + result3);
        System.out.println("Passes: " + binarySearch.getPass());
    }
}
