class MyMath {
    public void countDown(int num) {
        if (num < 0) return;
        System.out.println(num);
        countDown(num - 1);
    }

    public void countUp(int num) {
        if (num < 1) return;
        countUp(num - 1);
        System.out.println(num);
    }

    public int factorial(int num) {
        if (num == 0 || num == 1) return 1;
        return num * factorial(num - 1);
    }

    public int summation(int num) {
        if (num == 1) return 1;
        return num + summation(num - 1);
    }
}

