public class Runner {
    public static void main(String[] args) {
        MyMath math = new MyMath();

        // Call countDown
        System.out.println("Counting down from 5:");
        math.countDown(5);

        // Call countUp
        System.out.println("\nCounting up to 10:");
        math.countUp(10);

        // Call factorial
        int factorialResult = math.factorial(5);
        System.out.println("\nFactorial of 5: " + factorialResult);

        // Call summation
        int summationResult = math.summation(5);
        System.out.println("\nSummation of numbers from 5 down to 1: " + summationResult);
    }
}
