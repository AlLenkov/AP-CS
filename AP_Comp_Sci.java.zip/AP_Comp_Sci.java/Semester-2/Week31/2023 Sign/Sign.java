public class Sign {
    private String message;
    private int width;

    public Sign(String message, int width) {
        this.message = message;
        this.width = width;
    }

    public int numberOfLines() {
        if (message.isEmpty()) {
            return 0;
        } else {
            int numLines = message.length() / width;
            if (message.length() % width != 0) {
                numLines++; // Account for the last line with fewer characters
            }
            return numLines;
        }
    }

    public String getLines() {
        if (message.isEmpty()) {
            return null;
        } else {
            StringBuilder lines = new StringBuilder();
            for (int i = 0; i < message.length(); i += width) {
                int end = Math.min(i + width, message.length());
                lines.append(message.substring(i, end));
                if (end < message.length()) {
                    lines.append(";");
                }
            }
            return lines.toString();
        }
    }
}
