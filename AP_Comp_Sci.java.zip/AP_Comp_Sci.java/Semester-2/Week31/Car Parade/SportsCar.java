import java.awt.Graphics;
import java.awt.Color;

public class SportsCar extends MediumCar{
	
    public SportsCar (Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
    }

    @Override
    public void drawFrame(Graphics g) {
        super.drawFrame(g);

        g.setColor(Color.black);
        g.drawLine(super.getX()+20, super.getY(), super.getX()+18, super.getY()+15);
        g.drawLine(super.getX()+44, super.getY()-15, super.getX()+44, super.getY()+20);
    }
}
