import java.awt.Graphics;
import java.awt.Color;

public class Sedan extends MediumCar{
	
    public Sedan (Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
    }

    @Override
    public void drawFrame(Graphics g) {
        super.drawFrame(g);

        g.setColor(Color.black);
        g.drawLine(super.getX()+20, super.getY(), super.getX()+18, super.getY()+15);
        g.drawLine(super.getX()+44, super.getY()-15, super.getX()+44, super.getY()+20);
        g.drawLine(super.getX()+70, super.getY(), super.getX()+72, super.getY()+15);
    }
}
