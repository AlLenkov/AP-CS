import java.awt.Graphics;
import java.awt.Color;

public class Truck extends BigCar {
    
    public Truck (Color bodyColor, int x, int y, int speed) {
        super (bodyColor, x, y, speed);
    }

    @Override 
    public void drawFrame(Graphics g) {
        super.drawFrame(g);

        super.changeWidth(33);
        g.setColor(Color.black);
        g.drawLine(super.getX()+20, super.getY(), super.getX()+18, super.getY()+15);
        g.drawLine(super.getX()+53, super.getY()-20, super.getX()+53, super.getY()+25);
        
    }
}
