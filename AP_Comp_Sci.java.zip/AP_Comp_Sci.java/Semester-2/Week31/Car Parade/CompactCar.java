import java.awt.Graphics;
import java.awt.Color;

public class CompactCar extends SmallCar{
	
    public CompactCar (Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
    }

    @Override
    public void drawFrame(Graphics g) {
        super.drawFrame(g);

        g.setColor(Color.black);
        g.drawLine(super.getX()+15, super.getY(), super.getX()+18, super.getY()+15);
        g.drawLine(super.getX()+35, super.getY()-15, super.getX()+35, super.getY()+20);
        g.drawLine(super.getX()+55, super.getY(), super.getX()+52, super.getY()+15);

    }
}
