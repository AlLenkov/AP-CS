import java.awt.Graphics;
import java.awt.Color;

public class SmallSportsCar extends SmallCar{
	
    public SmallSportsCar (Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
    }

    @Override
    public void drawFrame(Graphics g) {
        super.drawFrame(g);

        g.setColor(Color.black);
        g.drawLine(super.getX()+15, super.getY(), super.getX()+18, super.getY()+15);
        g.drawLine(super.getX()+35, super.getY()-15, super.getX()+35, super.getY()+20);
        g.drawLine(super.getX()+65, super.getY()-10, super.getX()+80, super.getY()-10);
        g.drawLine(super.getX()+65, super.getY(), super.getX()+72, super.getY()-10);
    }

    
}
