import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;


public class Screen extends JPanel{
	
	private ArrayList<Automobile> carList;
	
	public Screen(){
		// Instantiate the ArrayList
		carList = new ArrayList<Automobile>();

		// add cars
		//Color, x, y, speed
		carList.add(new SmallSportsCar(Color.GREEN,250, 280, 4));
		carList.add(new CompactCar(Color.LIGHT_GRAY, 50, 230, 3));
		carList.add(new SportsCar(Color.ORANGE, 450, 370, 5));
		carList.add(new Sedan(Color.BLUE, 350, 245, 3));
		carList.add(new SUV(Color.PINK, 350, 300, 2));
		carList.add(new Truck(Color.DARK_GRAY, 500, 320, 2));
		

		setLayout(null);
		setFocusable(true);
	}
	
	@Override
	public Dimension getPreferredSize(){
		return new Dimension(800,600);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		drawBackground(g);

		//draw cars
		for (Automobile each : carList) {
			each.drawCar(g);
		}
	}

	public void drawBackground(Graphics g){
		g.setColor(Color.green);
		g.fillRect(0, 0, 800, 800);
		g.setColor(Color.gray);
		g.fillRect(0, 200, 800, 200);
	}
	// move the cars on the roads
	public void animate(){
		while (true) {
            // wait for 10 milliseconds
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }

            // move cars
            for (Automobile car : carList) {
                car.setX(car.getX() - car.getSpeed());
                if (car.getX() < -200){
                    car.setX(1200); 
                }
            }

            repaint();
	}
	
}
}