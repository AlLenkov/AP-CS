import java.awt.Graphics;
import java.awt.Color;

public class MediumCar extends Automobile{

    private int frameW;
    private int frameH;

    public MediumCar(Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
        frameW = 90;
        frameH = 20;
    }

    @Override
    public void drawFrame(Graphics g) {
        g.setColor(super.getBodyColor());

        g.fillRect(super.getX(), super.getY(), frameW, frameH);
        g.fillRect(super.getX()+20, super.getY()-15, frameW-40, frameH-5);
        
        g.setColor(Color.BLACK);
        g.drawRect(super.getX(), super.getY(), frameW, frameH);
        g.drawRect(super.getX()+20, super.getY()-15, frameW-40, frameH-5);

        //highlight
        g.setColor(Color.yellow);
        g.fillOval(super.getX()-3, super.getY(), 8, 8);

        //windows
        g.setColor(Color.cyan);
        g.fillRect(super.getX()+23, super.getY()-14, 18, 12);
        g.fillRect(super.getX()+48, super.getY()-14, 18, 12);
    }

    @Override
    public void drawWheels(Graphics g) {
        g.setColor(Color.BLACK);

        g.fillOval(super.getX()+5, super.getY()+10, 20, 20);
        g.fillOval(super.getX()+60, super.getY()+10, 20, 20);
    }

    public int getWidth() {
        return frameW;
    }

    public int getHeight() {
        return frameH;
    }
}