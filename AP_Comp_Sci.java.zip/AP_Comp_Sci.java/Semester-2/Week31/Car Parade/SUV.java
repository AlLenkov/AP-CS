import java.awt.Graphics;
import java.awt.Color;

public class SUV extends BigCar{
	
    public SUV (Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
    }

    @Override
    public void drawFrame(Graphics g) {
        super.drawFrame(g);
        
        g.setColor(Color.black);
        g.drawLine(super.getX()+20, super.getY(), super.getX()+18, super.getY()+15);
        g.drawLine(super.getX()+53, super.getY()-20, super.getX()+53, super.getY()+25);
        g.drawLine(super.getX()+90, super.getY(), super.getX()+92, super.getY()+15);
    }
}
