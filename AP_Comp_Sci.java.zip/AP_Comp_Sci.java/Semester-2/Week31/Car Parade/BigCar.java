import java.awt.Graphics;
import java.awt.Color;

public class BigCar extends Automobile{

    private int frameW;
    private int frameH;
    private int frame2W;
    private boolean window;

    public BigCar(Color bodyColor, int x, int y, int speed) {
        super(bodyColor, x, y, speed);
        frameW = 110;
        frame2W= 70;
        frameH = 25;
        window = true;
    }

    @Override
    public void drawFrame(Graphics g) {
        g.setColor(super.getBodyColor());

        g.fillRect(super.getX(), super.getY(), frameW, frameH);
        g.fillRect(super.getX()+20, super.getY()-20, frame2W, frameH-5);
        
        g.setColor(Color.BLACK);
        g.drawRect(super.getX(), super.getY(), frameW, frameH);
        g.drawRect(super.getX()+20, super.getY()-20, frame2W, frameH-5);

        //highlight
        g.setColor(Color.yellow);
        g.fillOval(super.getX()-3, super.getY(), 8, 8);

        //windows
        g.setColor(Color.cyan);
        g.fillRect(super.getX()+23, super.getY()-17, 25, 15);
        if(window==true){
            g.fillRect(super.getX()+60, super.getY()-17, 25, 15);
        }
    }

    @Override
    public void drawWheels(Graphics g) {
        g.setColor(Color.BLACK);

        g.fillOval(super.getX()+5, super.getY()+13, 20, 20);
        g.fillOval(super.getX()+80, super.getY()+13, 20, 20);
        
    }

    public int getWidth() {
        return frameW;
    }
    public void changeWidth(int frame2W) {
        this.frame2W = frame2W;
        window = false;
    }

    public int getHeight() {
        return frameH;
    }
}