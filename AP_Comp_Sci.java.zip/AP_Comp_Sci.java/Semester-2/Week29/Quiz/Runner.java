import java.util.ArrayList;

public class Runner {
    public static void main(String[] args) {
        //makes ArrayList
        ArrayList<Polygon> Polygons = new ArrayList<Polygon>();
        //Adds Rectange
        Polygons.add(new Rectangle("Rectangle", 8, 13));
        //Adds Triangle
        Polygons.add(new Triangle("Triangle", 5, 7));
        //runs needed methods
        for (Polygon each : Polygons) {
            each.printInfo();
            each.calcArea();
        }
    }
}

abstract class Polygon{
    private String name;
    //constructor
    public Polygon(String name){
        this.name = name;
    }

    abstract public void calcArea();
    //method to be called in order to get name of polygon assigned to polygon calling it
    public void printInfo(){
        System.out.println("The name of the polygon is: "+ name);
    }
    //returns Name
    public String getName(){
        return name;
    }
}

class Rectangle extends Polygon{
    private int width, length;
    //Constructor
    public Rectangle(String name, int width, int length){
        super(name);
        this.width = width;
        this.length = length;
    }
    //calculates Area and prints it in a sentance
    public void calcArea(){
        System.out.println("Area of " + super.getName() +" is: " + width*length);
    }
    //prints dimensions of Polygon aswell as name
    public void printInfo(){
        super.printInfo();
        System.out.println("length is: " + length + " width is: " +width);
    }

}

class Triangle extends Polygon{
    private double base, height;
    //Constructor
    public Triangle(String name, double base, double height){
        super(name);
        this.base = base;
        this.height = height;
    }
    //calculates Area and prints it in a sentance
    public void calcArea(){
        System.out.println("Area of " + super.getName() +" is: " + height*base/2);
    }
    //prints dimensions of Polygon aswell as name
    public void printInfo(){
        super.printInfo();
        System.out.println("base is: " + base + " height is: " +height);
    }

}
