import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;


public class Screen extends JPanel{
	
	private ArrayList<Automobile> carList;
	
	public Screen(){
		// Instantiate the ArrayList
		carList = new ArrayList<Automobile>();

		// add cars
		carList.add( new SmallCar(Color.BLUE, 150, 400));
		carList.add( new SmallSportsCar(Color.RED, 50, 400));

		setLayout(null);
		setFocusable(true);
	}
	
	@Override
	public Dimension getPreferredSize(){
		return new Dimension(800,600);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		//draw background
		g.setColor( Color.white );
		g.fillRect(0,0,800,600);
		
		//draw cars
		for (Automobile each : carList) {
			each.drawCar(g);
		}
	}

	// move the cars on the roads
	public void animate(){
		while(true){
			//wait for .01 second
			try {
			    Thread.sleep(10);
			} catch(InterruptedException ex) {
			    Thread.currentThread().interrupt();
			}
		
			
		    // put your animate code here
		
		
		    repaint();
		}
	}
	
}
