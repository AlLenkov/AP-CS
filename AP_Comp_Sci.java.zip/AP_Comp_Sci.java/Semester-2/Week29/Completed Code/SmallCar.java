import java.awt.Graphics;
import java.awt.Color;

public class SmallCar extends Automobile{

    private int frameW, frameH;

    // constructor
    public SmallCar(Color bodyColor, int x, int y){
        super(bodyColor, x, y);
        frameW = 70;
        frameH = 20;
    }

    // draw frame
    @Override
    public void drawFrame(Graphics g) {
        g.setColor(super.getColor());
        g.fillRect(super.getX(), super.getY(), frameW, frameH);
    }

    // draw the wheels
    @Override
    public void drawWheels(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillOval(super.getX()+5, super.getY() +10, 20, 20);
        g.fillOval(super.getX()+50, super.getY()+10, 20, 20);
    }

    // return the width
    public int getWidth() {
        return frameW;
    }
    
}