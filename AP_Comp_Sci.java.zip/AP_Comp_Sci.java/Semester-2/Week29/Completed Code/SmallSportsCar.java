import java.awt.Graphics;
import java.awt.Color;

public class SmallSportsCar extends SmallCar {
	
    // Constructor
    public SmallSportsCar(Color bodyColor, int x, int y) {
        super(bodyColor, x, y);
    }

    // draw a grill on the frame
    @Override
    public void drawFrame(Graphics g) {
        super.drawFrame(g);

        int width = super.getWidth();

        int[] xArray = new int[3];
        int[] yArray = new int[3];

        xArray[0] = super.getX() + width;
        yArray[0] = super.getY();

        xArray[1] = super.getX() + width;
        yArray[1] = super.getY() + 25;

        xArray[2] = super.getX() + width + 15;
        yArray[2] = super.getY() +25;

        g.fillPolygon(xArray, yArray, 3);
    }
}