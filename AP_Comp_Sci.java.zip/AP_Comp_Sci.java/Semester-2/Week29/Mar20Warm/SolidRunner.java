import java.util.ArrayList;

public class SolidRunner {
    public static void main(String[] args) {
        ArrayList<Solid> solids = new ArrayList<Solid>();

        solids.add(new RectangularPrism("RecPrism", 10.3, 7, 3));
        solids.add(new Sphere("Sphere", 4));

        for (Solid each : solids) {
            each.printInfo();
            each.calcVolume();
        }
    }
}

abstract class Solid{
    private String name;

    public Solid(String name){
        this.name = name;
    }

    public abstract void calcVolume();
    
    public void printInfo(){
        System.out.println("the name is" + name);
    }
}

class RectangularPrism extends Solid{
    private double length, width, height;

    public RectangularPrism(String name, double length, double width, double height){
        super(name);
        length = this.length;
        width = this.width;
        height = this. height;
    }

    public void calcVolume(){
        double volume = length * width * height;

        System.out.println("volume is " + volume);
    }

    public void printInfo(){
        super.printInfo();
        System.out.println("length is: "+ length +" width is: "+ width + " height is: "+ height);
    }
}


class Sphere extends Solid{
    private double radius;

    public Sphere(String name, double radius){
        super(name);
        radius = this.radius;
    }

    public void calcVolume(){
        double volume = (4/3) * Math.pow(radius, 3) * Math.PI;

        System.out.println("volume is " + volume);
    }

    public void printInfo(){
        super.printInfo();
        System.out.println("radius is: "+ Math.round(radius*100)/100);
    }
}


