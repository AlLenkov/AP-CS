import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Table extends JPanel implements MouseListener{

	private Card[] deck;
	private int playerCount;
	private int status = -1;
	int points = 20;
	private BufferedImage buttonImage;
	private int win = 0;
	private JLabel pts;
	private JLabel totalValue;
	private boolean state = true;
	private int value = 0;
	//constrctor
	public Table(){
		setLayout(null);
		addMouseListener(this);
		
		pts = new JLabel();
		pts.setBounds(300, 15, 300, 15);
		this.add(pts);
		
		playerCount = 2;

		totalValue = new JLabel();
		totalValue.setBounds(100, 100, 300, 15);
		this.add(totalValue);
		//makes array "Deck" of Card class
		deck = new Card[52];
		String suit = "hearts";
		for(int i = 0; i < 4; i++){
			deck[i*12 + 0] = new Card(2,"2",suit);
			deck[i*12 + 1] = new Card(3,"3",suit);
			deck[i*12 + 2] = new Card(4,"4",suit);
			deck[i*12 + 3] = new Card(5,"5",suit);
			deck[i*12 + 4] = new Card(6,"6",suit);
			deck[i*12 + 5] = new Card(7,"7",suit);
			deck[i*12 + 6] = new Card(8,"8",suit);
			deck[i*12 + 7] = new Card(9,"9",suit);
			deck[i*12 + 8] = new Card(10,"10",suit);
			deck[i*12 + 9] = new Card(10,"J",suit);
			deck[i*12 + 10] = new Card(10,"Q",suit);
			deck[i*12 + 11] = new Card(10,"K",suit);
			deck[i*12 + 12] = new Card(11,"A",suit);
			if(i == 0){
				suit = "diamonds";
			}else if(i == 1){
				suit = "clubs";
			}else if(i == 2){
				suit = "spades";
			}
		}
		shuffle();
	}
	
	public Dimension getPreferredSize() {
		//Sets the size of the panel
		return new Dimension(800,600);
	}

	public void paintComponent(Graphics g){	
		super.paintComponent(g);
		//background
		g.setColor(Color.WHITE);
		g.fillRect(0,0,1000,600);
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0,400,1000,200);
		
		
		//"prints" points
		pts.setText("Points: " + points);
		
		for(int i = 0; i < playerCount; i++){
			if(deck[i] != null){
				value += deck[i].getValue();
			}
		}
		
		totalValue.setText("Total: " + value);
		value = 0;
		
		int x = 25;
		int y = 200;
		for(int i = 0; i<playerCount; i++){
			if(deck[i] != null){ 
				deck[i].drawMe(g, x ,y);
				x+=80;
			}
		}
		
		if(endGame() == -1){
			win = 2;
			state = false;
		}
		if(endGame() == 5){
			win = 1;
			if(state == true){
				points += 5;
			}
			state = false;
			
		}
		//add picture buttons button
		try{
			buttonImage = ImageIO.read(new File("hit.png"));
		} catch (IOException e){
			System.out.println(e);
		}
		g.drawImage(buttonImage,100,50,null);
		
		try{
			buttonImage = ImageIO.read(new File("stand.png"));
		} catch (IOException e){
			System.out.println(e);
		}
		g.drawImage(buttonImage,225,50,null);
		
		try{
			buttonImage = ImageIO.read(new File("reset.png"));
		} catch (IOException e){
			System.out.println(e);
		}
		g.drawImage(buttonImage,350,50,null);
		if(win == 1){
			try{
				buttonImage = ImageIO.read(new File("win.png"));
			} catch (IOException e){
				System.out.println(e);
			}
			g.drawImage(buttonImage,475,50,null);
		}else if(win == 2){
			try{
				buttonImage = ImageIO.read(new File("bust.png"));
			} catch (IOException e){
				System.out.println(e);
			}
			g.drawImage(buttonImage,475,50,null);
		}
		
	}
	
	//shuffles deck(changes card class array index randomly)
	private void shuffle(){
		for(int i = 0; i < deck.length; i++){
			Card temp = deck[i];
			int y = (int)(Math.random() * 51 + 1);
			deck[i] = deck[y];
			deck[y] = temp;
		}
	}
	
	//determines outcome based on deck value of player
	private int endGame(){
		int total = 0;
		for(int i = 0; i < playerCount; i++){
			if(deck[i] != null){
				total += deck[i].getValue();
			}
		}
		if(total > 21){
			return -1;
		}else if(total == 16 || total == 17){
			return 1;
		}else if(total == 18 || total == 19){
			return 2;
		}else if(total == 20){
			return 3;
		}else if(total == 21){
			return 5;
		}
		return 0;
	}
	
	//determines individual result
	private void result(){
		int total = 0;
		for(int i = 0; i < playerCount; i++){
			if(deck[i] != null){
				total += deck[i].getValue();
			}
		}
		if(total > 21 || total < 16){
			win = 1;
		}else if(total <= 21 && total >= 16){
			win = 2;
		}
		state = false;
	}
	//for buttons
	public void mouseClicked(MouseEvent e) {  
        if(e.getX() > 80 && e.getX() < 200 && e.getY() > 50 && e.getY() <110 && state == true){
        	playerCount++;
        	repaint();
        }else if(e.getX() > 225 && e.getX() < 325 && e.getY() > 50 && e.getY() <110 && state == true){
        	if(endGame() == 0){
        		win = 2;
        		
        	}else{
        		win = 1;
        		points += endGame();
        	}
        	state = false;
        	repaint();
        }else if(e.getX() > 350 && e.getX() < 450 && e.getY() > 50 && e.getY() <110 && state == false){
        	points--;
        	playerCount = 2;
        	shuffle();
        	repaint();
        	win = 0;
        	state = true;
        }
    }  
    public void mouseEntered(MouseEvent e) {  
         
    }  
    public void mouseExited(MouseEvent e) {  
         
    }  
    public void mousePressed(MouseEvent e) {  
        
    }  
    public void mouseReleased(MouseEvent e) {  
          
    }  
	
	
}