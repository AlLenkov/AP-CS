import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Card {

	private int value;
	private String name;
	private String suit;
	private BufferedImage suitImage;
	//constructor
	public Card(int value, String name, String suit){
		//set values
		this.value = value;
		this.name = name;
		this.suit = suit;
		//add images
		if(suit.equals("hearts") ){
			try{
				suitImage = ImageIO.read(new File("hearts.png"));
			} catch (IOException e){
				System.out.println(e);
			}
		}else if(suit.equals("diamonds") ){
			try{
				suitImage = ImageIO.read(new File("diamonds.png"));
			} catch (IOException e){
				System.out.println(e);
			}
		}else if(suit.equals("clubs") ){
			try{
				suitImage = ImageIO.read(new File("clubs.png"));
			} catch (IOException e){
				System.out.println(e);
			}
		}else {
			try{
				suitImage = ImageIO.read(new File("spades.png"));
			} catch (IOException e){
				System.out.println(e);
			}
		}
	}
	//draw card
	public void drawMe(Graphics g, int x, int y){
		
		g.setColor(Color.WHITE);
		g.fillRect(x,y,100,150);
		g.setColor(Color.BLACK);
		g.drawRect(x,y,100,150);
		
		Font font = new Font("Arial", Font.PLAIN, 50);
		g.setFont(font);
		
		if(suit.equals("hearts") || suit.equals("diamonds")){
			g.setColor(Color.RED);
		}
		g.drawString(name, x+33, y+100);
		
		g.drawImage(suitImage,x+2,y,null);
		
	}
	
	public int getValue(){
		return value;
	}
}