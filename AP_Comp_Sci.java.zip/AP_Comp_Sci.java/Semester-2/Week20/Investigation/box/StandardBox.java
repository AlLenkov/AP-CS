package box;

public class StandardBox{
	private int password = 1234;
	public String companyName = "ABC Co.";
	protected String streetAddress = "1232 Java Dr.";
	String city = "Mountain View";
}