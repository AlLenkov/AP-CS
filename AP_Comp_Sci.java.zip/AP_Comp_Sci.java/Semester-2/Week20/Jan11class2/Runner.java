public class Runner {
    public static void main(String[] args) {
        StringTest testInstance = new StringTest("The quick brown fox jumps over the lazy dog");
        testInstance.printInfo();
        testInstance.printChar(0);
        testInstance.printChar(5);
        testInstance.printChar(10);
        testInstance.printChar(15);
        testInstance.printLocation("h");
        testInstance.printLocation("e");
        testInstance.printLocation("jumps");
        testInstance.printLocation("dog");
        int count = testInstance.countChar('o');
        System.out.println("Count of 'o': " + count);
    }
}