public class StringTest {
    // Instance variable
    private String myText;

    // Constructor
    public StringTest(String text) {
        // Instantiate myText with the passed-in String parameter
        myText = text;
    }

    // Method to get the length of myText
    public int getLength() {
        return myText.length();
    }

    // Method to print myText and its length
    public void printInfo() {
        System.out.println(myText);
        System.out.println("Length: " + getLength());
    }

    // Method to print the character at a specific index
    public void printChar(int index) {
        System.out.println("Character at index " + index + ": " + myText.charAt(index));
    }

    // Method to print the index of a given substring in myText
    public void printLocation(String substring) {
        System.out.println("Index of '" + substring + "': " + myText.indexOf(substring));
    }

    // Method to count occurrences of a specific character in myText
    public int countChar(char character) {
        int count = 0;
        for (int i = 0; i < myText.length(); i++) {
            if (myText.charAt(i) == character) {
                count++;
            }
        }
        return count;
    }
}
