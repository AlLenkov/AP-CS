import bank.*;


public class Runner {
    public static void main(String[] args) {
        AccountManager obj = new AccountManager();
        obj.printInfo();
    }
}