package bank;

public class AccountManager {
    private int pin;
    private Account[] account;

    public AccountManager() {
        account = new Account[3];
        account[0] = new Account(1234, 10.10, "John");
        account[1] = new Account(1111, 99.99, "Jen");
        account[2] = new Account(4321, 11.11, "Jay");
    }

    public void printInfo() {

        for (int i = 0; i < account.length; i++) {
            System.out.println(account[i].name);
            System.out.println(account[i].balance);
            System.out.println(account[i].getPin());
            System.out.println("hello??");
        }
    }

}
