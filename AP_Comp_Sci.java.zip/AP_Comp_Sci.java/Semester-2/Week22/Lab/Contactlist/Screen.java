package Contactlist;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Screen extends JPanel implements ActionListener {
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JButton b8;
    private JTextField t1;
    private String name = "";
    private Contact[] myList;
    private int[] visible;
    private int x, x2, y, y2;
    private boolean search = false;

    public Screen() {
        this.setLayout(null);
        visible = new int[10];
        for (int i = 0; i < visible.length; i++) {
            visible[i] = -2;
        }
        myList = new Contact[10];
        myList[0] = new Contact("Emma", "Smith", "emma.smith@yahoo.com");
        myList[1] = new Contact("John", "Johnson", "jjohnson@gmail.com");
        myList[2] = new Contact("Michael", "Williams", "michaelW10@outlook.com");
        myList[3] = new Contact("Olivia", "Jones", "852724384@gmail.com");
        myList[4] = new Contact("Sophia", "Brown", "sophieB321@hotmail.com");
        myList[5] = new Contact("William", "Davis", "willdavis01@outlook.com");
        myList[6] = new Contact("James", "Garcia", "jgarcia24@gmail.com");
        myList[7] = new Contact("Ava", "Miller", "miller.ava@gmail.com");
        myList[8] = new Contact("Daniel", "Smith", "hotdog391@yahoo.com");
        myList[9] = new Contact("Isabella", "Taylor", "dfhfhehdslwu@hotmail.com");

        // Buttons
        b1 = new JButton("First Name");
        b1.setBounds(25, 100, 150, 30);
        b1.addActionListener(this);
        this.add(b1);
        b2 = new JButton("Last Name");
        b2.setBounds(175, 100, 150, 30);
        b2.addActionListener(this);
        this.add(b2);
        b3 = new JButton("Username");
        b3.setBounds(325, 100, 150, 30);
        b3.addActionListener(this);
        this.add(b3);
        b4 = new JButton("Domain Name");
        b4.setBounds(475, 100, 150, 30);
        b4.addActionListener(this);
        this.add(b4);
        b5 = new JButton("Domain Extension");
        b5.setBounds(625, 100, 150, 30);
        b5.addActionListener(this);
        this.add(b5);
        b6 = new JButton("Sort: First");
        b6.setBounds(175, 130, 150, 30);
        b6.addActionListener(this);
        this.add(b6);
        b7 = new JButton("Sort: Last");
        b7.setBounds(325, 130, 150, 30);
        b7.addActionListener(this);
        this.add(b7);
        b8 = new JButton("Sort: Username");
        b8.setBounds(475, 130, 150, 30);
        b8.addActionListener(this);
        this.add(b8);

        // TextField
        t1 = new JTextField(20);
        t1.setBounds(100, 50, 80, 30);
        this.add(t1);

        this.setFocusable(true);

    }

    public Dimension getPreferredSize() {
        // Sets the size of the panel
        return new Dimension(800, 600);
    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 800, 600);
        // draw instructions
        g.setColor(Color.RED);
        g.drawString("Enter in a name: ", 100, 20);
        Font font = new Font("Arial", Font.PLAIN, 10);
        g.setFont(font);
        x = 450;
        y = 230;
        for (int i = 0; i < myList.length; i++) {
            g.drawString(myList[i].toString(), x, y);
            y += 30;
        }
        x2 = 50;
        y2 = 230;
        g.drawString("Search Results", 50, 200);
        for (int i = 0; i < myList.length; i++) {
            if (visible[i] != -2) {
                g.drawString(myList[i].toString(), x2, y2);
                y2 += 30;
            }
        }

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            search = true;
            String input = t1.getText();
            for (int i = 0; i < myList.length; i++) {
                if (input.equals(myList[i].getFirstname())) {
                    visible[i] = i;
                    y2 += 30;
                } else {
                    visible[i] = -2;
                }
            }
            repaint();
        }
        if (e.getSource() == b2) {
            search = true;
            String input = t1.getText();
            for (int i = 0; i < myList.length; i++) {
                if (input.equals(myList[i].getLastname())) {
                    visible[i] = i;
                    y2 += 30;
                } else {
                    visible[i] = -2;
                }

            }
            repaint();
        }
        if (e.getSource() == b3) {
            search = true;
            String input = t1.getText();
            for (int i = 0; i < myList.length; i++) {
                if (input.equals(myList[i].getUsername())) {
                    visible[i] = i;
                    y2 += 30;
                } else {
                    visible[i] = -2;
                }

            }
            repaint();
        }
        if (e.getSource() == b4) {
            search = true;
            String input = t1.getText();
            for (int i = 0; i < myList.length; i++) {
                if (input.equals(myList[i].getDomainName())) {
                    visible[i] = i;
                    y2 += 30;
                } else {
                    visible[i] = -2;
                }
            }
            repaint();
        }
        if (e.getSource() == b5) {
            search = true;
            String input = t1.getText();
            for (int i = 0; i < myList.length; i++) {
                if (input.equals(myList[i].getDomainExtension())) {
                    visible[i] = i;
                    y2 += 30;
                } else {
                    visible[i] = -2;
                }

            }
            repaint();
        }
        if (e.getSource() == b6) {
            for (int i = 0; i < myList.length; i++) {
                for (int j = 0; j < myList.length - i - 1; j++) {
                    if (myList[j].getFirstname().compareTo(myList[j + 1].getFirstname()) > 0) {
                        Contact temp = myList[j];
                        myList[j] = myList[j + 1];
                        myList[j + 1] = temp;
                    }
                }
                visible[i] = -2;

            }
            repaint();

        }
        if (e.getSource() == b7) {

            for (int i = 0; i < myList.length; i++) {
                for (int j = 0; j < myList.length - i - 1; j++) {
                    if (myList[j].getLastname().compareTo(myList[j + 1].getLastname()) > 0) {
                        Contact temp = myList[j];
                        myList[j] = myList[j + 1];
                        myList[j + 1] = temp;
                    }
                }
                visible[i] = -2;
            }
            repaint();

        }
        if (e.getSource() == b8) {

            for (int i = 0; i < myList.length; i++) {
                for (int j = 0; j < myList.length - i - 1; j++) {
                    if (myList[j].getUsername().compareTo(myList[j + 1].getUsername()) > 0) {
                        Contact temp = myList[j];
                        myList[j] = myList[j + 1];
                        myList[j + 1] = temp;
                    }
                }
                visible[i] = -2;
            }
            repaint();

        }
    }
}
