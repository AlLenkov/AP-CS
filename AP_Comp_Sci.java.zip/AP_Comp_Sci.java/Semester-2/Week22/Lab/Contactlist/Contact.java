package Contactlist;
import java.awt.Graphics;
import java.awt.Color;
public class Contact{
    private String firstname;
    private String lastname;
    private String email;
    public Contact(String f, String l, String e){
        firstname=f;
        lastname=l;
        email=e;
    }
    public String toString(){
        String address = firstname + " " + lastname + " - " + email;
        return address;
    }
    public String getFirstname(){
        return firstname;
    }
    public String getLastname(){
        return lastname;
    }
    public String getUsername(){
        int end = email.indexOf("@");
        String username = email.substring(0,end);
        return username;
    }
    public String getDomainName(){
        int start = email.indexOf("@");
        int end = email.indexOf(".",start);
        String domain = email.substring(start+1,end);
        return domain;
    }
    public String getDomainExtension(){
        int start = email.indexOf("@");
        int start2 = email.indexOf(".",start);
        String extension = email.substring(start2+1);
        return extension;
    }
}