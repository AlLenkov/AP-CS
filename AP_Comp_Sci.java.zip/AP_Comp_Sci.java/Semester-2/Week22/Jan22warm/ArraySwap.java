import java.util.Random;

public class ArraySwap {

    private int[] nums;

    // Constructor
    public ArraySwap() {
        nums = new int[]{5, };
        for (int i = 0; i < nums.length; i++) {
            nums[i] = (int) (Math.random()*98+1);
        }
    }


    public void print() {
        System.out.print("Array: ");
        for (int each : nums) {
            System.out.print(each + " ");
        }
        System.out.println(); 
    }

    public void swap(int index1, int index2) {
            int temp = nums[index1];
            nums[index1] = nums[index2];
            nums[index2] = temp;
    }
}
