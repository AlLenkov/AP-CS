public class Runner {
    public static void main(String[] args) {
        ArraySwap obj = new ArraySwap();
        obj.print();
        obj.swap(0,9);
        obj.print();
    }

}
