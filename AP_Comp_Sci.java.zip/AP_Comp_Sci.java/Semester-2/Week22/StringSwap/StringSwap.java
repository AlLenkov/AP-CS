public class StringSwap {

    private String[] words= new String[5];

    public StringSwap() {

        words[0] = "Rabbit";
        words[1] = "Cat";
        words[2] = "Dog";
        words[3] = "Chicken";
        words[4] = "Mouse";
    }

    public void printWords() {

        for(String animals: words) {
            System.out.println(animals);
        }

        System.out.println();
    }

    public void swapWords(int num1, int num2) {

        int x = num1;
        int y = num2;

        String c = words[x];
        words[x] = words[y];
        words[y] = c;
        

    }
}