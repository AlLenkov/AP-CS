public class Runner {

    public static void main(String [] args) {

        StringSwap sw = new StringSwap();

        sw.printWords();
        sw.swapWords(0,4);
        sw.printWords();
        sw.swapWords(2,3);
        sw.printWords();
    }
}