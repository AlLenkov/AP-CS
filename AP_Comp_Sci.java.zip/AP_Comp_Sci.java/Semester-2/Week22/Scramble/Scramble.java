class Scramble{
    public void printArray(int[] array){
        for(int each : array){
            System.out.print(each+" ");
        }
        System.out.println();
    }
    public void printArray(String[] array){
        for(String each : array){
            System.out.print(each+" ");
        }
        System.out.println();
    }
    public int search(int a, int[] array){
        for(int i=0;i<array.length;i++){
            if(array[i]==a){
                return i;
            }
        }
        return -1;
    }
    public void scramble(int[] array){
        for(int i=0; i<array.length;i++){
            int b=(int)(Math.random()*array.length-1);
            int c= array[i];
            array[i]=array[b];
            array[b]=c;
        }
    }
    public void scramble(String[] array){
      for(int i=0; i<array.length;i++){
            int b=(int)(Math.random()*array.length-1);
            String c= array[i];
            array[i]=array[b];
            array[b]=c;
        }
    }
}
