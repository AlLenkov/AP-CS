import java.util.Scanner;
public class Runner{
    public static void main(String[] args){
        Scanner scan= new Scanner(System.in);
        int a,b;
        Scramble scramObj= new Scramble();
        int[] numArr= new int[6];
        for(int i=0;i<5; i++){
            numArr[i]=(int)(Math.random()*11-1);
        }
        scramObj.printArray(numArr);
        scramObj.scramble(numArr);
        scramObj.printArray(numArr);
        System.out.println("Give me an index 1-10: ");
        a=scan.nextInt();
        b=scramObj.search(a, numArr);
        if(b!=-1){
            System.out.println(a+", was found at index "+b);
        }else{
            System.out.println(a+" was not found in the array");
        }
        scramObj.printArray(numArr);
        String[] wordArr= new String[6];
        wordArr[0]="no";
        wordArr[1]="yes";
        wordArr[2]="donkey";
        wordArr[3]="me";
        wordArr[4]="dog";
        wordArr[5]="cat";
        scramObj.printArray(wordArr);
        scramObj.scramble(wordArr);
        scramObj.printArray(wordArr);
    }
}

