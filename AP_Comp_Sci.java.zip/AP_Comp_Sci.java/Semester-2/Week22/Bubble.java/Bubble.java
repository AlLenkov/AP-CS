public class Bubble{
    public void printArray(int[] array){
        for(int each : array){
            System.out.print(each+" ");
        }
        System.out.println();
    }
    public void bubbleSort(int[] sArr){
        System.out.print("Original Array: ");
        printArray(sArr);
        for(int i=0; i < sArr.length-1; i++ ){
            // Array is traversed from index 0 through index sArr.length-i-1
            for(int j=0; j < sArr.length-i-1; j++){
                //If item at j is greater than j+1,then swap
                if( sArr[j] > sArr[j+1] ){
                    //swap
                    int temp = sArr[j];
                    sArr[j] = sArr[j+1];
                    sArr[j+1] = temp;
                    System.out.print("   Swapped index " + j + " and " + (int)(j+1) + ": ");
                    printArray(sArr);
                }
            }
        }
    }
}
