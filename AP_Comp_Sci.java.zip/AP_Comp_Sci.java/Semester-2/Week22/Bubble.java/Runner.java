class Runner{
    public static void main(String[] args){
        Bubble b=new Bubble();
        int[] array= new int[10];
        for(int i=0; i<array.length; i++){
            array[i]=(int)(Math.random()*26-1);
        }
        b.printArray(array);
        b.bubbleSort(array);
        b.printArray(array);
    }
}