public class Quiz {

    private String email;

    public Quiz(String set) {
        email = set;
    }

    public String getName() {
        int index = email.indexOf("@");
        return email.substring(0,index);
    }

    public int countChar(char c) {
        int total = 0;
        for(int i = 0; i<email.length(); i++) {
            if(email.charAt(i) == (c)){
                total++;
            }
        }
        return total;
    }

    public String toString() {
        return("address: " + email);
    }
}