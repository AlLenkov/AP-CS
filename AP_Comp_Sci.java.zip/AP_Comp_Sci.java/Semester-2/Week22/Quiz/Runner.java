public class Runner {

    public static void main (String[] args) {

        Quiz obj = new Quiz("tom.Johnson@gmail.com");

        System.out.println("The name is " + obj.getName());
        System.out.println("The letter is " + obj.countChar('m'));
        System.out.println(obj.toString());

    }
}