public class Runner {
    public static void main(String[] args) {
        int m = 1;
        int n = 5;
        for (int i = 0; i < m * n; i++){
            System.out.println("A");
        }
        System.out.println("---");
        for(int j= 1;j<= m; j++){
            for (int k = 1; k < n; k++){
                System. out.println ("B") ;
            }
        }
    }
}
